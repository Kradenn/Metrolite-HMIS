import { closestElement } from "@html_editor/utils/dom_traversal";
import { Component, onMounted, useEffect, useExternalListener, useRef } from "@orbinet/owl";
import { Dropdown } from "@web/core/dropdown/dropdown";
import { DropdownItem } from "@web/core/dropdown/dropdown_item";
import { _t } from "@web/core/l10n/translation";

export class TableMenu extends Component {
    static template = "html_editor.TableMenu";
    static props = {
        type: String, // column or row
        moveColumn: Function,
        addColumn: Function,
        removeColumn: Function,
        moveRow: Function,
        addRow: Function,
        removeRow: Function,
        turnIntoHeader: Function,
        turnIntoRow: Function,
        resetRowHeight: Function,
        resetColumnWidth: Function,
        resetTableSize: Function,
        clearColumnContent: Function,
        clearRowContent: Function,
        close: Function,
        dropdownState: Object,
        target: { validate: (el) => el.nodeType === Node.ELEMENT_NODE },
        document: { validate: (el) => el.nodeType === Node.DOCUMENT_NODE },
        direction: { type: String, optional: true },
    };
    static defaultProps = { direction: "ltr" };
    static components = { Dropdown, DropdownItem };

    setup() {
        this.dropdownRef = useRef("dropdown");
        onMounted(() => {
            this.overlayEl = this.dropdownRef.el;
        });
        useEffect(
            () => {
                if (this.props.type === "column") {
                    this.isFirst = this.props.target.cellIndex === 0;
                    this.isLast = !this.props.target.nextElementSibling;
                } else {
                    const tr = this.props.target.parentElement;
                    this.isFirst = !tr.previousElementSibling;
                    this.isLast = !tr.nextElementSibling;
                    this.isTableHeader = [...tr.children][0].nodeName === "TH";
                }
                this.items = this.props.type === "column" ? this.colItems() : this.rowItems();
                this.updatePosition();
            },
            () => [this.props.target]
        );
        if (this.props.document.defaultView.frameElement) {
            useExternalListener(this.props.document, "scroll", () => {
                this.updatePosition();
            });
            useExternalListener(this.props.document, "pointerdown", (ev) => {
                if (!this.overlayEl.contains(ev.target)) {
                    this.props.close();
                }
            });
        }
    }

    get hasCustomTableSize() {
        const table = closestElement(this.props.target, "table");
        if (!table) {
            return false;
        }
        const rows = [...table.rows];
        const firstRowCells = [...rows[0].cells];
        const rowHasHeight = rows.some((row) => row.style.height);
        const cellHasWidth = firstRowCells.some((cell) => cell.style.width);
        return rowHasHeight || cellHasWidth;
    }

    get hasCustomRowHeight() {
        return !!this.props.target.closest("tr").style.height;
    }

    get hasCustomColumnWidth() {
        return (
            !!this.props.target.closest("td")?.style?.width ||
            !!this.props.target.closest("th")?.style?.width
        );
    }

    updatePosition() {
        const { target, type, direction } = this.props;
        if (!this.overlayEl || !target) {
            return;
        }
        let frameRect = { top: 0, left: 0 };
        let frameElement;
        try {
            frameElement = this.props.document.defaultView.frameElement;
        } catch {
            // We don't access the frameElement if we don't have access to it.
            // (i.e. iframe origin or sandbox restriction)
        }
        if (frameElement) {
            frameRect = frameElement.getBoundingClientRect();
        }
        const targetRect = target.getBoundingClientRect();
        const container = this.overlayEl.parentElement;
        const containerRect = container.getBoundingClientRect();
        const top = frameRect.top + targetRect.top - containerRect.top;
        const left = frameRect.left + targetRect.left - containerRect.left;
        this.overlayEl.classList.remove("h-100", "w-100");
        if (type === "column") {
            Object.assign(this.overlayEl.style, {
                position: "absolute",
                top: `${top - this.overlayEl.offsetHeight}px`,
                left: `${left}px`,
                width: `${targetRect.width}px`,
            });
        } else {
            const isLTR = direction === "ltr";
            const inlineStartOffset = isLTR
                ? left
                : containerRect.right - (frameRect.left + targetRect.right);
            Object.assign(this.overlayEl.style, {
                position: "absolute",
                top: `${top}px`,
                insetInlineStart: `${inlineStartOffset - this.overlayEl.offsetWidth}px`,
                height: `${targetRect.height}px`,
            });
        }
    }
    onSelected(item) {
        item.action(this.props.target);
        this.props.close();
    }

    colItems() {
        const ltr = this.props.direction === "ltr";
        return [
            !this.isFirst && {
                name: "move_left",
                icon: "fa-chevron-left disabled",
                text: ltr ? _t("Move left") : _t("Move right"),
                action: this.props.moveColumn.bind(this, "left"),
            },
            !this.isLast && {
                name: "move_right",
                icon: "fa-chevron-right",
                text: ltr ? _t("Move right") : _t("Move left"),
                action: this.props.moveColumn.bind(this, "right"),
            },
            {
                name: "insert_left",
                icon: "fa-plus",
                text: ltr ? _t("Insert left") : _t("Insert right"),
                action: this.props.addColumn.bind(this, "before"),
            },
            {
                name: "insert_right",
                icon: "fa-plus",
                text: ltr ? _t("Insert right") : _t("Insert left"),
                action: this.props.addColumn.bind(this, "after"),
            },
            {
                name: "delete",
                icon: "fa-trash",
                text: _t("Delete"),
                action: this.props.removeColumn.bind(this),
            },
            this.hasCustomColumnWidth && {
                name: "reset_column_size",
                icon: "fa-table",
                text: _t("Reset column size"),
                action: (target) => this.props.resetColumnWidth(target.closest("td, th")),
            },
            this.hasCustomTableSize && {
                name: "reset_table_size",
                icon: "fa-table",
                text: _t("Reset table size"),
                action: (target) => this.props.resetTableSize(target.closest("table")),
            },
            {
                name: "clear_content",
                icon: "fa-times-circle",
                text: _t("Clear content"),
                action: this.props.clearColumnContent.bind(this),
            },
        ].filter(Boolean);
    }

    rowItems() {
        return [
            this.isFirst &&
                !this.isTableHeader && {
                    name: "make_header",
                    icon: "fa-th-large",
                    text: _t("Turn into header"),
                    action: (target) => this.props.turnIntoHeader(target.parentElement),
                },
            this.isFirst &&
                this.isTableHeader && {
                    name: "remove_header",
                    icon: "fa-table",
                    text: _t("Turn into row"),
                    action: (target) => this.props.turnIntoRow(target.parentElement),
                },
            !this.isFirst && {
                name: "move_up",
                icon: "fa-chevron-up",
                text: _t("Move up"),
                action: (target) => this.props.moveRow("up", target.parentElement),
            },
            !this.isLast && {
                name: "move_down",
                icon: "fa-chevron-down",
                text: _t("Move down"),
                action: (target) => this.props.moveRow("down", target.parentElement),
            },
            !this.isTableHeader && {
                name: "insert_above",
                icon: "fa-plus",
                text: _t("Insert above"),
                action: (target) => this.props.addRow("before", target.parentElement),
            },
            {
                name: "insert_below",
                icon: "fa-plus",
                text: _t("Insert below"),
                action: (target) => this.props.addRow("after", target.parentElement),
            },
            {
                name: "delete",
                icon: "fa-trash",
                text: _t("Delete"),
                action: (target) => this.props.removeRow(target.parentElement),
            },
            this.hasCustomRowHeight && {
                name: "reset_row_size",
                icon: "fa-table",
                text: _t("Reset row size"),
                action: (target) => this.props.resetRowHeight(target.closest("tr")),
            },
            this.hasCustomTableSize && {
                name: "reset_table_size",
                icon: "fa-table",
                text: _t("Reset table size"),
                action: (target) => this.props.resetTableSize(target.closest("table")),
            },
            {
                name: "clear_content",
                icon: "fa-times-circle",
                text: _t("Clear content"),
                action: (target) => this.props.clearRowContent(target.parentElement),
            },
        ].filter(Boolean);
    }
}
