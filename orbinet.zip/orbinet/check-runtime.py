#!/usr/bin/env python3
"""Preflight checks for an Orbinet source checkout."""

from __future__ import annotations

import ast
import importlib.util
import json
from pathlib import Path
import platform
import sys

ROOT = Path(__file__).resolve().parent

REQUIRED_FILES = (
    "orbinet/init.py",
    "orbinet/cli/__init__.py",
    "orbinet/tools/__init__.py",
    "orbinet/addons/base/__manifest__.py",
    "orbinet/addons/web/__manifest__.py",
    "orbinet/addons/website/__manifest__.py",
    "ORIGINAL_MODULES.json",
    "requirements.txt",
)

CRITICAL_IMPORTS = {
    "babel": "Babel",
    "dateutil": "python-dateutil",
    "lxml": "lxml",
    "lxml_html_clean": "lxml-html-clean",
    "markupsafe": "MarkupSafe",
    "PIL": "Pillow",
    "passlib": "passlib",
    "polib": "polib",
    "psutil": "psutil",
    "psycopg2": "psycopg2",
    "reportlab": "reportlab",
    "requests": "requests",
    "werkzeug": "Werkzeug",
    "openpyxl": "openpyxl",
    "odf": "odfpy",
}


def manifest(path: Path) -> dict:
    """Read a module manifest without executing it."""
    return ast.literal_eval(path.read_text())


def unresolved_package_registrations() -> list[str]:
    """Find relative modules registered by __init__.py files but absent on disk."""
    unresolved: list[str] = []
    for path in (ROOT / "orbinet").rglob("__init__.py"):
        source = path.read_text(encoding="utf-8")
        tree = ast.parse(source, filename=str(path))
        for node in ast.walk(tree):
            if not isinstance(node, ast.ImportFrom) or node.level != 1:
                continue
            modules = [node.module.split(".")[0]] if node.module else [
                alias.name.split(".")[0] for alias in node.names
            ]
            for module in modules:
                if not (
                    (path.parent / f"{module}.py").is_file()
                    or (path.parent / module / "__init__.py").is_file()
                ):
                    relative = path.relative_to(ROOT)
                    unresolved.append(f"{relative}:{node.lineno}: {module}")
    return sorted(unresolved)


def unresolved_base_xml_references() -> list[str]:
    """Return base-owned XML references missing from base's loaded data files."""
    from lxml import etree  # imported only after the package preflight

    base = ROOT / "orbinet" / "addons" / "base"
    base_manifest = manifest(base / "__manifest__.py")
    identifiers: set[str] = set()
    references: set[str] = set()

    for relative in base_manifest.get("data", []):
        path = base / relative
        if path.suffix != ".xml":
            continue
        tree = etree.parse(str(path))
        for element in tree.xpath("//*[@id]"):
            identifiers.add(element.get("id").split(".")[-1])
        for element in tree.xpath("//*[@ref]"):
            reference = element.get("ref")
            if "." not in reference or reference.startswith("base."):
                references.add(reference.split(".")[-1])

    generated_prefixes = ("model_", "field_", "selection__")
    return sorted(
        reference
        for reference in references - identifiers
        if not reference.startswith(generated_prefixes)
    )


def main() -> int:
    print(f"Python: {sys.version.split()[0]} ({platform.platform()})")
    print(f"Project: {ROOT}")

    missing_files = [name for name in REQUIRED_FILES if not (ROOT / name).is_file()]
    if missing_files:
        print("\nERROR: incomplete Orbinet source tree:")
        for name in missing_files:
            print(f"  missing: {name}")
        return 2

    registry = json.loads((ROOT / "ORIGINAL_MODULES.json").read_text())
    declared = set(registry["modules"])
    discovered = {
        path.parent.name
        for path in (ROOT / "orbinet" / "addons").glob("*/__manifest__.py")
    }
    if declared != discovered or len(discovered) != registry["module_count"]:
        print("\nERROR: retained module registry does not match the source tree.")
        print(f"  expected: {len(declared)}; discovered: {len(discovered)}")
        print(f"  missing modules: {sorted(declared - discovered)}")
        print(f"  unexpected modules: {sorted(discovered - declared)}")
        return 3

    if registry.get("product_version") != "2.0":
        print("\nERROR: ORIGINAL_MODULES.json does not identify Orbinet 2.0.")
        return 4

    policy_exclusions = set(
        registry.get("policy_exclusions", {}).get("online_payment_bridges", [])
    )
    if shipped_exclusions := policy_exclusions & discovered:
        print("\nERROR: policy-excluded online-payment bridges are present:")
        for module in sorted(shipped_exclusions):
            print(f"  {module}")
        return 5

    manifests = {
        module: manifest(ROOT / "orbinet" / "addons" / module / "__manifest__.py")
        for module in discovered
    }
    missing_data_files = []
    for module, module_manifest in manifests.items():
        module_root = ROOT / "orbinet" / "addons" / module
        for relative in module_manifest.get("data", []):
            if not (module_root / relative).is_file():
                missing_data_files.append(f"{module}/{relative}")
    if missing_data_files:
        print("\nERROR: manifest-loaded runtime data files are missing:")
        for name in sorted(missing_data_files):
            print(f"  {name}")
        return 6

    if unresolved_imports := unresolved_package_registrations():
        print("\nERROR: package initializers import source files that are absent:")
        for entry in unresolved_imports:
            print(f"  {entry}")
        return 7

    missing_packages = [
        distribution
        for module, distribution in CRITICAL_IMPORTS.items()
        if importlib.util.find_spec(module) is None
    ]
    if missing_packages:
        print("\nERROR: critical Python packages are missing:")
        for name in missing_packages:
            print(f"  {name}")
        print("\nInstall the declared environment with:")
        print(f'  "{sys.executable}" -m pip install -r "{ROOT / "requirements.txt"}"')
        return 8

    if unresolved := unresolved_base_xml_references():
        print("\nERROR: base has unresolved XML references:")
        for reference in unresolved:
            print(f"  base.{reference}")
        return 9

    missing_dependencies = {
        dependency
        for module_manifest in manifests.values()
        for dependency in module_manifest.get("depends", [])
        if dependency not in discovered
    }
    print(f"\nSource layout is complete: {len(discovered)} separate modules.")
    print("Package initializer and base XML reference checks passed; "
          f"unavailable add-ons: {len(missing_dependencies)}.")
    try:
        import orbinet.init  # noqa: F401, PLC0415
        import orbinet.release  # noqa: PLC0415
    except Exception as exc:
        print(f"\nERROR: Orbinet import failed: {type(exc).__name__}: {exc}")
        print(f'  "{sys.executable}" -c "import orbinet"')
        return 10

    if orbinet.release.version != registry["product_version"]:
        print(
            "\nERROR: runtime and inventory product versions differ: "
            f"{orbinet.release.version} != {registry['product_version']}"
        )
        return 11

    print(f"Orbinet {orbinet.release.version} bootstrap import succeeded.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
