# Priority prompts for additional Orbinet add-on packs

Use one prompt per new workspace, in order. Each pack is deliberately narrow so the persisted workspace contains only merge-ready add-ons, not another full framework copy. Do not create ZIP archives unless explicitly requested later.

Before sending a prompt, attach the six canonical files from `ORBINET_BRAND_ASSETS`: the SVG and PNG logo, SVG/512/192 icons, and favicon. Every prompt requires those exact assets and prohibits a newly invented replacement.

These prompts use the same public source baseline as Orbinet: branch `19.0`, commit `2a697031849f9bf33116834b90bc664d93d9034a`.

## Prompt 1 — foundational dependencies

```text
Build Priority Pack 1 for Orbinet 2.0: foundational, country-neutral dependencies.

Use only public source from branch 19.0 at commit 2a697031849f9bf33116834b90bc664d93d9034a. Clone or sparse-checkout upstream under /tmp, never under the persisted workspace. The final deliverable must be /home/user/orbinet-pack-p1-foundations and contain only merge-ready add-ons plus pack documentation.

Target modules:
- uom
- calendar
- project
- gamification
- survey
- rating
- portal_rating
- google_recaptcha

Compute the real manifest dependency closure. Treat Orbinet core modules such as base, web, web_tour, mail, account, analytic, product, resource, portal, base_setup, crm, website, and http_routing as already available; do not duplicate them. Add another dependency only if it is public, LGPL-compatible, country-neutral, and actually required. Never fabricate a module or remove a dependency merely to make a manifest look installable.

Africa suitability gate: skip and document any module that requires a country outside Africa, an upstream subscription, mandatory IAP, a region-limited carrier, or an unavailable hosted service. google_recaptcha may be retained only as a real administrator-configured integration: no key, endpoint, or network use may be forced by default.

Hard exclusions:
- every l10n_* localization, including African localizations;
- all payment*, account_payment, website_payment, payment_custom, and provider modules;
- tests, test assets, fixtures, tours used only for testing, demos, i18n translations, developer docs, and benchmarks;
- Enterprise/OEEL/OPL modules, advertisements, upgrade links, edition labels, and subscription checks;
- invented Orbinet services or URLs.

Perform a complete Orbinet framework conversion, not a source copy. Convert Python imports and package paths from odoo to orbinet, JavaScript module/runtime identity to Orbinet (including @orbinet-module and @orbinet/owl where applicable), and XML data roots from <odoo> to <orbinet>. Preserve only compatibility identifiers such as model names, XML IDs, routes, database fields, and o_ CSS classes when renaming them would break APIs.

Use the attached canonical `orbinet-logo.svg`, `orbinet-logo.png`, `orbinet-icon.svg`, `orbinet-icon-512.png`, `orbinet-icon-192.png`, and `orbinet-favicon.ico`. If they are not attached, stop and ask for them; do not invent a new logo. Audit every PNG/JPG/SVG/ICO, app icon, screenshot, email image, placeholder, manifest image, and metadata field. Replace every Odoo logo, wordmark, favicon, purple brand treatment, or product screenshot with the canonical Orbinet identity or neutral Orbinet-colored artwork. Neutral functional app icons may remain distinct but must contain no Odoo trademark or product branding.

Remove every Odoo product link and all `odoo.com`, `apps.odoo.com`, pricing, trial, upgrade, hosted-service, and marketing/documentation URLs. Do not redirect them to a fake Orbinet host. Remove visible Odoo product names from manifests, templates, emails, onboarding, image metadata, and UI strings. Set product-facing manifest author to `Orbinet` and website to empty. Preserve legally required plain-text attribution only in source headers, LICENSE, NOTICE, and third-party licence files; legal attribution must not appear as a product link or promotion. Do not create placeholders.

Validation required:
- parse every manifest and verify every manifest-loaded file exists;
- compile every retained Python file;
- parse every XML file;
- run node --check on changed JavaScript where supported;
- verify no forbidden module directory, test/demo/i18n tree, payment dependency, l10n module, or OEEL/OPL licence remains;
- scan text, manifests, templates, asset metadata, and filenames for Odoo product names, logos, linked URLs, and runtime namespaces; allow plain-text legal attribution only in the documented legal allowlist;
- visually inspect retained image assets and record every replacement in an asset inventory;
- report the exact dependency closure and anything skipped.

Create PACK_MANIFEST.json, README.md, MERGE_ORDER.md, and VALIDATION.md. PACK_MANIFEST.json must record the source branch/commit, selected modules, dependency closure, exclusions, and merge target orbinet/addons. Delete the temporary source checkout, caches, bytecode, build output, and downloaded archives before finishing. Present VALIDATION.md.
```

## Prompt 2 — inventory and procurement

```text
Build Priority Pack 2 for Orbinet 2.0: country-neutral inventory and procurement.

Use public branch 19.0 commit 2a697031849f9bf33116834b90bc664d93d9034a. Use /tmp for the upstream sparse checkout. Persist only /home/user/orbinet-pack-p2-inventory with merge-ready add-ons and documentation; do not duplicate the Orbinet framework or Priority Pack 1.

Target modules:
- stock
- barcodes
- purchase
- purchase_stock
- stock_account

Assume the current Orbinet core and Priority Pack 1 are merged, including base, web, mail, account, analytic, product, resource, uom, and calendar. Compute the exact dependency closure. Include an additional public operational dependency only when required and Africa-suitable. Do not include sale_stock, delivery, stock_delivery, event_sale, purchase-to-payment connectors, or any module that pulls the excluded online payment framework. Do not alter sale merely to bypass account_payment.

Hard exclusions:
- all l10n_* modules and country fiscal localizations;
- every payment module/provider/bridge, including account_payment and website_payment;
- tests, test bundles, fixtures, demos, translations, developer docs, and benchmarks;
- region-limited carriers such as delivery_mondialrelay and provider-specific commerce such as sale_gelato;
- IAP/subscription requirements, Enterprise/OEEL/OPL source, advertisements, upgrade links, and invented endpoints.

Perform a complete framework and asset conversion: Python runtime imports/package paths must use orbinet; JavaScript must use Orbinet module identity, `@orbinet-module`, and `@orbinet/owl` where applicable; XML roots must use <orbinet>. Preserve only API-critical model names, XML IDs, routes, fields, and o_ CSS classes.

Use the attached canonical Orbinet logo, icon, PNG sizes, and favicon. If those files are unavailable, request them rather than generating a substitute. Audit every PNG/JPG/SVG/ICO, `static/description/icon.png`, screenshot, placeholder, email/report image, and metadata field. Replace Odoo logos, wordmarks, favicons, screenshots, and purple product branding with the canonical Orbinet identity or distinct neutral artwork using the Orbinet navy/teal palette. Produce an asset replacement inventory.

Remove all links to Odoo, including `odoo.com`, apps, pricing, upgrade, trial, hosted-service, and marketing/documentation URLs. Remove visible Odoo product names from manifests and runtime UI. Set product-facing manifest author to `Orbinet` and website to empty. Do not invent Orbinet URLs. Retain legally required plain-text attribution only in source headers and legal files, never as product UI or a hyperlink.

Do not confuse the excluded account_payment add-on with the manual accounting payment model already inside the core account module; do not delete or rewrite core manual accounting payments.

Validate manifests, dependency closure, loaded file paths, Python syntax, XML, JSON/CSV, and changed JavaScript. Confirm no selected module has a payment, localization, provider-restricted, or hosted-subscription dependency. Scan text and asset metadata for Odoo names, linked URLs, logos, and runtime namespaces; visually inspect all retained images and record replacements. If a target cannot pass that gate, omit it and explain exactly why rather than creating a stub.

Create PACK_MANIFEST.json, README.md, MERGE_ORDER.md, and VALIDATION.md with source commit, module list, dependencies, exclusions, merge order, and validation results. Remove /tmp source, caches, bytecode, builds, and archives. Present VALIDATION.md.
```

## Prompt 3 — people and service operations

```text
Build Priority Pack 3 for Orbinet 2.0: people and service operations that are country-neutral and useful in African deployments.

Use public branch 19.0 at commit 2a697031849f9bf33116834b90bc664d93d9034a. Sparse-checkout under /tmp. The only persisted deliverable is /home/user/orbinet-pack-p3-people; do not copy the complete framework or earlier packs.

Target modules:
- hr_recruitment
- hr_timesheet
- hr_contract
- hr_holidays
- hr_attendance
- hr_expense

Assume Orbinet core and Priority Pack 1 are available, especially hr, project, calendar, analytic, account, mail, portal, resource, product, web, and base_setup. Compute the real dependency closure. A required support module may be included only if public, LGPL-compatible, country-neutral, non-payment, and non-hosted.

Do not include payroll, payroll localization, statutory filing, tax localization, bank/payment integration, or any l10n_* module. Even an African localization is out of scope unless separately requested in the future. Do not make country-specific labour-law claims or seed country-specific rules.

Also exclude tests, test assets, fixtures, demo records, i18n translations, developer docs, Enterprise/OEEL/OPL modules, edition promotions, subscriptions, and invented Orbinet services. If a target requires an excluded component, skip it and document the blocker; never create a fake dependency.

Perform a complete Orbinet framework conversion: Python runtime imports/package paths to orbinet, JavaScript module identity to Orbinet with `@orbinet-module` and `@orbinet/owl` where applicable, and <odoo> data roots to <orbinet>. Preserve model names, XML IDs, routes, fields, o_ classes, and other compatibility APIs only where required.

Use the attached canonical Orbinet logo/icon files and favicon; if missing, stop and request them instead of designing alternatives. Inspect every retained app icon, PNG/JPG/SVG/ICO, screenshot, placeholder, email/report image, and metadata field. Replace every Odoo product mark and branded visual with the canonical Orbinet identity or neutral navy/teal functional artwork. Remove every Odoo link, including product, apps, pricing, trial, upgrade, hosted, and marketing/documentation URLs. Set product-facing manifest author to `Orbinet` and website to empty. Do not invent Orbinet URLs. Preserve legal attribution only as plain text in source headers and legal files, not as UI or hyperlinks.

Validate all manifests and loaded paths, compile Python, parse XML, validate JSON/CSV, and syntax-check changed JavaScript. Verify the final pack contains no l10n, payroll, payment, tests, demo, i18n, Enterprise licence, hosted-service default, Odoo runtime namespace, linked Odoo URL, visible Odoo product label outside legal files, or Odoo-branded image. Include an asset replacement inventory.

Create PACK_MANIFEST.json, README.md, MERGE_ORDER.md, and VALIDATION.md. Record dependencies on Priority Pack 1 instead of duplicating its modules. Delete temporary source, caches, bytecode, build output, and archives. Present VALIDATION.md.
```

## Prompt 4 — collaboration and events

```text
Build Priority Pack 4 for Orbinet 2.0: collaboration and event dependencies that do not require online payments or region-limited services.

Use the exact public source baseline branch 19.0, commit 2a697031849f9bf33116834b90bc664d93d9034a. Keep the upstream checkout in /tmp. Persist only /home/user/orbinet-pack-p4-collaboration with selected add-ons and pack documentation.

Target modules:
- im_livechat
- event_booth
- event_crm
- partnership

Assume the Orbinet core and Priority Pack 1 are already present, including mail, website, website_event, event, crm, rating, portal_rating, calendar, utm, web, and portal. Compute the exact public dependency closure. Add a missing support module only if it is country-neutral, Africa-suitable, LGPL-compatible, non-payment, and not tied to a mandatory hosted subscription.

Explicitly exclude event_sale, event_booth_sale, website payment flows, payment providers, account_payment, website_payment, payment_custom, IAP lead mining, crm_iap_mine, iap_crm, region-specific delivery modules, all l10n_* modules, and any target that forces those dependencies.

Remove tests, test tours/assets, fixtures, demos, translations, developer docs, Enterprise/OEEL/OPL content, edition advertisements, upgrade links, and subscription reporting. No fake Orbinet endpoint may replace an upstream endpoint. Optional real external services must be administrator-configured and disabled when unconfigured.

Perform a complete Orbinet conversion: Python runtime imports/package paths to orbinet, JavaScript module identity to Orbinet with `@orbinet-module` and `@orbinet/owl` where applicable, and XML data roots to <orbinet>. Preserve API-critical technical identifiers only where renaming would break compatibility.

Use the attached canonical Orbinet logo, icon, PNG sizes, and favicon. If they are missing, request them and do not invent replacements. Audit all PNG/JPG/SVG/ICO files, app icons, screenshots, placeholders, email images, manifest imagery, and metadata. Replace Odoo logos, wordmarks, favicons, product screenshots, and purple branding with the canonical Orbinet identity or distinct neutral navy/teal functional art. Remove all Odoo links—product, apps, pricing, trials, upgrades, hosted services, and marketing/documentation—and remove visible Odoo product names from manifests and runtime UI. Set product-facing author to `Orbinet` and website to empty. Keep required legal attribution only as plain text in source headers and legal files, never as product UI or a hyperlink.

Validate manifests, full dependency closure, manifest paths, Python, XML, JSON/CSV, and changed JavaScript. Prove there are no payment/localization/test/demo/translation trees, prohibited licences, Odoo runtime namespaces, linked Odoo URLs, visible Odoo labels outside legal files, or Odoo-branded images. Include a visual asset replacement inventory. Skip and explain any target that fails the Africa suitability gate.

Create PACK_MANIFEST.json, README.md, MERGE_ORDER.md, and VALIDATION.md. Do not duplicate core or earlier-pack modules. Remove temporary checkouts, caches, bytecode, build output, and archives. Present VALIDATION.md.
```

## Prompt 5 — manufacturing and maintenance

```text
Build Priority Pack 5 for Orbinet 2.0: public manufacturing, maintenance, and repair without sales-payment coupling.

Use public branch 19.0 commit 2a697031849f9bf33116834b90bc664d93d9034a. Work from a sparse checkout in /tmp. Persist only /home/user/orbinet-pack-p5-manufacturing; do not copy the framework or previous packs.

Target modules, only where they exist publicly at the pinned commit under a compatible open-source licence:
- mrp
- mrp_account
- maintenance
- repair

Assume Orbinet core, Priority Pack 1, and Priority Pack 2 are merged, especially product, uom, stock, stock_account, purchase, purchase_stock, account, analytic, mail, hr, resource, and web. Compute the exact dependency closure and do not duplicate prior-pack modules.

Exclude sale_mrp and any sales extension that inherits the currently blocked online-payment-dependent sale chain. Also exclude quality, PLM, work-order, or other modules when the available source is Enterprise/OEEL/OPL or merely an advertisement. Exclude all payments, providers, l10n_*, payroll/statutory localization, region-limited carrier/provider modules, IAP subscriptions, tests, demos, translations, developer docs, and benchmarks.

Perform a complete Orbinet framework conversion: Python runtime imports/package paths to orbinet, JavaScript module identity to Orbinet with `@orbinet-module` and `@orbinet/owl` where applicable, and XML roots to <orbinet>. Retain compatibility model/XML identifiers only when required by APIs.

Use the attached canonical Orbinet logo/icon files, PNG sizes, and favicon; if unavailable, stop and request them. Inspect all PNG/JPG/SVG/ICO files, app icons, screenshots, placeholders, report/email images, and metadata. Replace every Odoo logo, wordmark, favicon, product screenshot, and purple brand asset with the canonical Orbinet identity or distinct neutral navy/teal functional artwork. Remove all Odoo links, including product, apps, pricing, trial, upgrade, hosted-service, and marketing/documentation URLs. Remove visible Odoo names from manifests and UI, set product-facing author to `Orbinet`, and clear website fields. Never invent a replacement endpoint or Orbinet URL. Preserve required legal attribution only as plain text in source headers and legal files, not as UI or hyperlinks.

If one target is absent, proprietary, or requires an excluded dependency, omit it and record the reason. Do not fabricate it and do not weaken another module's manifest without a complete source-level refactor and validation.

Validate every manifest and loaded path, compile Python, parse XML, validate JSON/CSV, syntax-check changed JavaScript, and report the complete closure. Confirm no prohibited payment, localization, test, demo, translation, proprietary, provider-restricted content, Odoo runtime namespace, linked Odoo URL, visible Odoo label outside legal files, or Odoo-branded image remains. Include an asset replacement inventory.

Create PACK_MANIFEST.json, README.md, MERGE_ORDER.md, and VALIDATION.md. Remove /tmp source, caches, bytecode, build artifacts, and archives. Present VALIDATION.md.
```

## Deliberately deferred

Do not create packs yet for these groups:

- online payments or payment providers;
- any `l10n_*` localization;
- sales extensions that require `account_payment` or `website_payment`;
- `delivery_mondialrelay`, `sale_gelato`, and other region/provider-specific commerce;
- IAP lead mining and upstream-hosted subscription services;
- automated tests, demo data, translations, or developer tooling.

The sales/eCommerce chain needs a separate, explicit payment-free refactor plan rather than a manifest-only dependency edit.
