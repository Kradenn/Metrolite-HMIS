# Amazon Connector for the platform

Technical name: `sale_amazon`  
Author: Ultra Demark Technologies Ltd.

## Scope

This addon provides an Amazon Seller Central connector foundation for the platform with:

- Multi-account and multi-marketplace configuration
- Amazon SP-API client with LWA token exchange and AWS SigV4 signing
- Product listings, inventory, pricing rules, order import, FBA/FBM fulfillment, shipments, returns, settlements, ads, performance metrics and sync logs
- OWL dashboard with marketplace KPIs, charts and operational queues
- Scheduled jobs, retryable sync jobs, security groups, demo data, PDF/Excel reports and tests

## Deployment

1. Copy `sale_amazon` to your the platform addons path.
2. Update apps list.
3. Install **Amazon Connector**.
4. Add users to Amazon Connector security groups.
5. Configure Seller Central credentials under **Amazon → Accounts**.
6. Configure mappings under **Amazon → Configuration**.
7. Run account health check, then use dashboard quick actions or scheduled jobs.

## Production hardening checklist

- Replace demo credentials and disable demo data in production.
- Use a dedicated Amazon SP-API application and least-privilege IAM user.
- Configure settlement journal, fee accounts and clearing accounts per company.
- Validate tax mappings per marketplace before activating automated sales-order creation.
- Configure carrier mappings for FBM shipment confirmation.
- Monitor **Amazon → Configuration → Sync Logs** after go-live.

## Notes

Amazon feed document upload, listings feed schemas, Restricted Data Token workflows, and settlement report file parsing vary by seller app permissions and marketplace. The module isolates those hooks in service/model methods so they can be completed safely using your approved SP-API roles.


## Amazon S3 connector

The module includes Amazon S3 Connections, Buckets, and Objects screens for managing export storage, report archives, attachment/object references, bucket discovery, object listing, and S3 sync logs.

## Menu organization

The Amazon app menu is grouped into Dashboard, Catalog, Operations, Finance & Analytics, Amazon S3, and Configuration to keep daily operations compact.
