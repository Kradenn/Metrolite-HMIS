/** @odoo-module **/

import { registry } from "@web/core/registry";
import { Component, onWillStart, useState } from "@odoo/owl";
import { useService } from "@web/core/utils/hooks";
import { rpc } from "@web/core/network/rpc";

class AmazonDashboard extends Component {
    static template = "sale_amazon.AmazonDashboard";

    setup() {
        this.action = useService("action");
        this.state = useState({
            loading: true,
            data: {},
        });
        onWillStart(async () => {
            await this.loadDashboard();
        });
    }

    async loadDashboard() {
        this.state.loading = true;
        this.state.data = await rpc("/sale_amazon/dashboard/data", {});
        this.state.loading = false;
    }

    openAction(xmlId) {
        this.action.doAction(xmlId);
    }

    maxValue(items) {
        const values = (items || []).map((item) => item.value || 0);
        return Math.max(...values, 1);
    }

    barWidth(value, items) {
        return `${Math.max(((value || 0) / this.maxValue(items)) * 100, 2)}%`;
    }
}

registry.category("actions").add("sale_amazon.dashboard", AmazonDashboard);
