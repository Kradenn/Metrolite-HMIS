# -*- coding: utf-8 -*-
from datetime import timedelta
import logging

from odoo import _, api, fields, models
from odoo.exceptions import UserError

from ..services.sp_api import AmazonSPAPIClient, AmazonSPAPIError

_logger = logging.getLogger(__name__)


MARKETPLACE_DATA = {
    'us': ('Amazon US', 'ATVPDKIKX0DER', 'https://sellingpartnerapi-na.amazon.com', 'us-east-1', 'USD'),
    'uk': ('Amazon UK', 'A1F83G8C2ARO7P', 'https://sellingpartnerapi-eu.amazon.com', 'eu-west-1', 'GBP'),
    'eu': ('Amazon EU', 'A1PA6795UKMFR9', 'https://sellingpartnerapi-eu.amazon.com', 'eu-west-1', 'EUR'),
    'ca': ('Amazon CA', 'A2EUQ1WTGCTBG2', 'https://sellingpartnerapi-na.amazon.com', 'us-east-1', 'CAD'),
    'ae': ('Amazon AE', 'A2VIGQ35RCS4UG', 'https://sellingpartnerapi-eu.amazon.com', 'eu-west-1', 'AED'),
    'in': ('Amazon IN', 'A21TJRUUN4KGV', 'https://sellingpartnerapi-eu.amazon.com', 'eu-west-1', 'INR'),
    'jp': ('Amazon JP', 'A1VC38T7YXB528', 'https://sellingpartnerapi-fe.amazon.com', 'us-west-2', 'JPY'),
    'au': ('Amazon AU', 'A39IBJ37TRP1C6', 'https://sellingpartnerapi-fe.amazon.com', 'us-west-2', 'AUD'),
}


class AmazonAccount(models.Model):
    _name = 'amazon.account'
    _description = 'Amazon Seller Account'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'sequence, name'

    name = fields.Char(string='Account Name', required=True, tracking=True)
    sequence = fields.Integer(default=10)
    active = fields.Boolean(default=True)
    company_id = fields.Many2one('res.company', required=True, default=lambda self: self.env.company, index=True)
    seller_id = fields.Char(string='Seller ID', required=True, tracking=True)
    marketplace_region = fields.Selection(
        [(key, value[0]) for key, value in MARKETPLACE_DATA.items()],
        string='Marketplace Region',
        required=True,
        default='us',
        tracking=True,
    )
    marketplace_id = fields.Char(required=True, readonly=False)
    endpoint = fields.Char(required=True)
    aws_region = fields.Char(required=True, default='us-east-1')
    access_key = fields.Char(string='Access Key', copy=False, groups='sale_amazon.group_amazon_admin')
    secret_key = fields.Char(string='Secret Key', copy=False, groups='sale_amazon.group_amazon_admin')
    lwa_client_id = fields.Char(string='LWA Client ID', copy=False, groups='sale_amazon.group_amazon_admin')
    lwa_client_secret = fields.Char(string='LWA Client Secret', copy=False, groups='sale_amazon.group_amazon_admin')
    refresh_token = fields.Char(string='Refresh Token', copy=False, groups='sale_amazon.group_amazon_admin')
    currency_id = fields.Many2one('res.currency', string='Currency', required=True, default=lambda self: self.env.company.currency_id)
    status = fields.Selection([
        ('draft', 'Draft'),
        ('connected', 'Connected'),
        ('warning', 'Warning'),
        ('error', 'Error'),
        ('disabled', 'Disabled'),
    ], default='draft', tracking=True)
    last_health_check = fields.Datetime(readonly=True)
    last_order_sync = fields.Datetime(readonly=True)
    last_inventory_sync = fields.Datetime(readonly=True)
    last_price_sync = fields.Datetime(readonly=True)
    last_settlement_sync = fields.Datetime(readonly=True)
    last_return_sync = fields.Datetime(readonly=True)
    auto_create_sales_orders = fields.Boolean(default=True)
    auto_confirm_fbm_orders = fields.Boolean(default=False)
    order_import_minutes = fields.Integer(default=15)
    inventory_sync_minutes = fields.Integer(default=30)
    price_sync_minutes = fields.Integer(default=60)
    safety_stock_qty = fields.Float(default=0.0)
    warehouse_id = fields.Many2one('stock.warehouse', string='Default Warehouse', domain="[('company_id', '=', company_id)]")
    journal_id = fields.Many2one('account.journal', string='Settlement Journal', domain="[('type', 'in', ('bank', 'general')), ('company_id', '=', company_id)]")
    receivable_account_id = fields.Many2one('account.account', string='Amazon Receivable Account')
    fee_account_id = fields.Many2one('account.account', string='Amazon Fee Expense Account')
    settlement_clearing_account_id = fields.Many2one('account.account', string='Settlement Clearing Account')
    listing_count = fields.Integer(compute='_compute_counts')
    order_count = fields.Integer(compute='_compute_counts')
    sync_error_count = fields.Integer(compute='_compute_counts')

    @api.onchange('marketplace_region')
    def _onchange_marketplace_region(self):
        for account in self:
            data = MARKETPLACE_DATA.get(account.marketplace_region)
            if data:
                account.marketplace_id = data[1]
                account.endpoint = data[2]
                account.aws_region = data[3]
                currency = self.env['res.currency'].search([('name', '=', data[4])], limit=1)
                if currency:
                    account.currency_id = currency

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            region = vals.get('marketplace_region', 'us')
            data = MARKETPLACE_DATA.get(region)
            if data:
                vals.setdefault('marketplace_id', data[1])
                vals.setdefault('endpoint', data[2])
                vals.setdefault('aws_region', data[3])
                if not vals.get('currency_id'):
                    currency = self.env['res.currency'].search([('name', '=', data[4])], limit=1)
                    if currency:
                        vals['currency_id'] = currency.id
        return super().create(vals_list)

    def _compute_counts(self):
        Listing = self.env['amazon.listing']
        Order = self.env['amazon.order']
        Log = self.env['amazon.sync.log']
        for account in self:
            account.listing_count = Listing.search_count([('account_id', '=', account.id)])
            account.order_count = Order.search_count([('account_id', '=', account.id)])
            account.sync_error_count = Log.search_count([('account_id', '=', account.id), ('level', '=', 'error'), ('state', '!=', 'resolved')])

    def _get_client(self):
        self.ensure_one()
        return AmazonSPAPIClient(
            endpoint=self.endpoint,
            aws_access_key=self.access_key,
            aws_secret_key=self.secret_key,
            lwa_client_id=self.lwa_client_id,
            lwa_client_secret=self.lwa_client_secret,
            refresh_token=self.refresh_token,
            aws_region=self.aws_region,
        )

    def _log_sync(self, operation, level='info', message='', payload=None, external_id=False):
        return self.env['amazon.sync.log'].sudo().create({
            'name': '%s - %s' % (self.display_name, operation),
            'account_id': self.id,
            'company_id': self.company_id.id,
            'operation': operation,
            'level': level,
            'message': message or '',
            'payload': payload or '',
            'external_id': external_id or '',
        })

    def action_health_check(self):
        for account in self:
            try:
                account._get_client().get_access_token()
                account.write({'status': 'connected', 'last_health_check': fields.Datetime.now()})
                account._log_sync('health_check', 'success', _('Amazon credentials validated successfully.'))
            except Exception as exc:  # noqa: BLE001 - log external API failures without crashing UI batch
                account.write({'status': 'error', 'last_health_check': fields.Datetime.now()})
                account._log_sync('health_check', 'error', str(exc))
                raise UserError(_('Amazon account health check failed: %s') % exc) from exc
        return True

    def action_sync_orders(self):
        return self._enqueue_or_run('import_orders')

    def action_sync_inventory(self):
        return self._enqueue_or_run('sync_inventory')

    def action_sync_products(self):
        return self._enqueue_or_run('sync_products')

    def action_sync_prices(self):
        return self._enqueue_or_run('sync_prices')

    def action_sync_settlements(self):
        return self._enqueue_or_run('sync_settlements')

    def action_sync_returns(self):
        return self._enqueue_or_run('sync_returns')

    def _enqueue_or_run(self, operation):
        jobs = self.env['amazon.sync.job']
        created = jobs
        for account in self:
            created |= jobs.create({
                'name': '%s - %s' % (account.display_name, operation),
                'account_id': account.id,
                'company_id': account.company_id.id,
                'operation': operation,
                'state': 'pending',
            })
        return {
            'type': 'ir.actions.act_window',
            'name': _('Amazon Sync Jobs'),
            'res_model': 'amazon.sync.job',
            'view_mode': 'list,form',
            'domain': [('id', 'in', created.ids)],
        }

    def _import_orders(self):
        Order = self.env['amazon.order'].sudo()
        imported = 0
        for account in self:
            created_after = (account.last_order_sync or (fields.Datetime.now() - timedelta(days=2))).isoformat()
            try:
                payload = account._get_client().get_orders(account.marketplace_id, created_after)
                amazon_orders = payload.get('payload', {}).get('Orders', []) or payload.get('Orders', [])
                for raw in amazon_orders:
                    order = Order._upsert_from_amazon(account, raw)
                    if account.auto_create_sales_orders and not order.sale_order_id:
                        order.action_create_sale_order()
                    imported += 1
                account.write({'last_order_sync': fields.Datetime.now(), 'status': 'connected'})
                account._log_sync('import_orders', 'success', _('Imported %s Amazon orders.') % len(amazon_orders))
            except AmazonSPAPIError as exc:
                account.write({'status': 'error'})
                account._log_sync('import_orders', 'error', str(exc))
        return imported

    def _sync_inventory(self):
        Inventory = self.env['amazon.inventory.record'].sudo()
        synced = 0
        for account in self:
            try:
                payload = account._get_client().get_inventory_summaries(account.marketplace_id)
                summaries = payload.get('payload', {}).get('inventorySummaries', []) or payload.get('inventorySummaries', [])
                for item in summaries:
                    Inventory._upsert_from_amazon(account, item)
                    synced += 1
                account.write({'last_inventory_sync': fields.Datetime.now(), 'status': 'connected'})
                account._log_sync('sync_inventory', 'success', _('Synchronized %s inventory records.') % len(summaries))
            except AmazonSPAPIError as exc:
                account.write({'status': 'error'})
                account._log_sync('sync_inventory', 'error', str(exc))
        return synced

    def _sync_products(self):
        for account in self:
            listings = self.env['amazon.listing'].search([('account_id', '=', account.id), ('listing_status', 'in', ('draft', 'active'))])
            for listing in listings:
                listing.action_push_to_amazon()
            account._log_sync('sync_products', 'success', _('Queued/pushed %s listings.') % len(listings))
        return True

    def _sync_prices(self):
        for account in self:
            rules = self.env['amazon.pricing.rule'].search([('account_id', '=', account.id), ('active', '=', True), ('auto_update', '=', True)])
            for rule in rules:
                rule.action_apply_rule()
            account.write({'last_price_sync': fields.Datetime.now()})
            account._log_sync('sync_prices', 'success', _('Applied %s pricing rules.') % len(rules))
        return True

    def _sync_settlements(self):
        for account in self:
            since = (account.last_settlement_sync or (fields.Datetime.now() - timedelta(days=30))).isoformat()
            try:
                payload = account._get_client().get_reports('_GET_V2_SETTLEMENT_REPORT_DATA_FLAT_FILE_', account.marketplace_id, since)
                self.env['amazon.settlement']._create_from_report_index(account, payload)
                account.write({'last_settlement_sync': fields.Datetime.now()})
                account._log_sync('sync_settlements', 'success', _('Settlement report index fetched.'))
            except AmazonSPAPIError as exc:
                account.write({'status': 'error'})
                account._log_sync('sync_settlements', 'error', str(exc))
        return True

    def _sync_returns(self):
        for account in self:
            account.write({'last_return_sync': fields.Datetime.now()})
            account._log_sync('sync_returns', 'info', _('Return synchronization hook executed. Configure report/feed parsing for your seller account.'))
        return True

    @api.model
    def cron_import_orders(self):
        accounts = self.search([('active', '=', True), ('status', '!=', 'disabled')])
        return accounts._run_operation_safely('_import_orders')

    @api.model
    def cron_sync_inventory(self):
        accounts = self.search([('active', '=', True), ('status', '!=', 'disabled')])
        return accounts._run_operation_safely('_sync_inventory')

    @api.model
    def cron_sync_prices(self):
        accounts = self.search([('active', '=', True), ('status', '!=', 'disabled')])
        return accounts._run_operation_safely('_sync_prices')

    @api.model
    def cron_sync_settlements(self):
        accounts = self.search([('active', '=', True), ('status', '!=', 'disabled')])
        return accounts._run_operation_safely('_sync_settlements')

    @api.model
    def cron_sync_returns(self):
        accounts = self.search([('active', '=', True), ('status', '!=', 'disabled')])
        return accounts._run_operation_safely('_sync_returns')

    def _run_operation_safely(self, method_name):
        total = 0
        for account in self:
            try:
                total += getattr(account, method_name)() or 0
            except Exception as exc:  # noqa: BLE001
                _logger.exception('Amazon cron operation failed for account %s', account.display_name)
                account._log_sync(method_name, 'error', str(exc))
        return total
