# -*- coding: utf-8 -*-
from odoo import _, api, fields, models
from odoo.exceptions import UserError


class AmazonShipment(models.Model):
    _name = 'amazon.shipment'
    _description = 'Amazon Shipment'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'ship_date desc, id desc'

    name = fields.Char(default=lambda self: self.env['ir.sequence'].next_by_code('amazon.shipment') or _('New'), copy=False, readonly=True)
    account_id = fields.Many2one('amazon.account', required=True, ondelete='cascade')
    company_id = fields.Many2one(related='account_id.company_id', store=True)
    order_id = fields.Many2one('amazon.order', required=True, domain="[('account_id', '=', account_id)]")
    sale_order_id = fields.Many2one(related='order_id.sale_order_id', store=True, readonly=True)
    picking_id = fields.Many2one('stock.picking')
    carrier_id = fields.Many2one('delivery.carrier', string='Carrier')
    carrier_name = fields.Char()
    tracking_number = fields.Char(tracking=True)
    ship_date = fields.Datetime(default=fields.Datetime.now)
    label_attachment_id = fields.Many2one('ir.attachment', string='Shipping Label')
    fulfillment_type = fields.Selection(related='order_id.fulfillment_type', store=True)
    state = fields.Selection([
        ('draft', 'Draft'),
        ('ready', 'Ready'),
        ('label_generated', 'Label Generated'),
        ('confirmed', 'Confirmed on Amazon'),
        ('done', 'Done'),
        ('error', 'Error'),
    ], default='draft', tracking=True)
    line_ids = fields.One2many('amazon.shipment.line', 'shipment_id')
    last_error = fields.Text(readonly=True)

    def action_prepare_from_order(self):
        for shipment in self:
            shipment.line_ids.unlink()
            lines = []
            for order_line in shipment.order_id.line_ids:
                lines.append((0, 0, {
                    'order_line_id': order_line.id,
                    'sku': order_line.sku,
                    'quantity': order_line.quantity_ordered - order_line.quantity_shipped,
                }))
            shipment.write({'line_ids': lines, 'state': 'ready'})
        return True

    def action_generate_label(self):
        for shipment in self:
            shipment.state = 'label_generated'
            shipment.account_id._log_sync('shipping_label', 'info', _('Shipping label generation requested for %s.') % shipment.name)
        return True

    def action_confirm_amazon_shipment(self):
        for shipment in self:
            if not shipment.tracking_number:
                raise UserError(_('Tracking number is required before confirming shipment to Amazon.'))
            payload = shipment._prepare_confirmation_payload()
            try:
                shipment.account_id._get_client().confirm_shipment(shipment.order_id.amazon_order_id, payload)
                shipment.write({'state': 'confirmed', 'last_error': False})
                shipment.order_id.action_mark_shipped()
                shipment.account_id._log_sync('shipment_confirmation', 'success', _('Shipment confirmed for Amazon order %s.') % shipment.order_id.amazon_order_id)
            except Exception as exc:  # noqa: BLE001
                shipment.write({'state': 'error', 'last_error': str(exc)})
                shipment.account_id._log_sync('shipment_confirmation', 'error', str(exc), external_id=shipment.order_id.amazon_order_id)
        return True

    def _prepare_confirmation_payload(self):
        self.ensure_one()
        return {
            'marketplaceId': self.account_id.marketplace_id,
            'packageDetail': {
                'packageReferenceId': self.name,
                'carrierCode': self.carrier_id.name if self.carrier_id else (self.carrier_name or 'Other'),
                'carrierName': self.carrier_name or (self.carrier_id.name if self.carrier_id else 'Other'),
                'shippingMethod': self.carrier_id.delivery_type if self.carrier_id else 'Other',
                'trackingNumber': self.tracking_number,
                'shipDate': (self.ship_date or fields.Datetime.now()).isoformat(),
                'orderItems': [{
                    'orderItemId': line.order_line_id.id,
                    'quantity': int(line.quantity),
                } for line in self.line_ids],
            }
        }


class AmazonShipmentLine(models.Model):
    _name = 'amazon.shipment.line'
    _description = 'Amazon Shipment Line'

    shipment_id = fields.Many2one('amazon.shipment', required=True, ondelete='cascade')
    order_line_id = fields.Many2one('amazon.order.line')
    sku = fields.Char(required=True)
    quantity = fields.Float(default=1.0)


class IrSequence(models.Model):
    _inherit = 'ir.sequence'
