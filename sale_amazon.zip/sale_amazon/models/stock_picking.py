# -*- coding: utf-8 -*-
from odoo import _, fields, models


class StockPicking(models.Model):
    _inherit = 'stock.picking'

    amazon_shipment_id = fields.Many2one('amazon.shipment', copy=False)
    amazon_order_id = fields.Many2one(related='sale_id.amazon_order_id', store=True, readonly=True)
    amazon_tracking_uploaded = fields.Boolean(default=False, copy=False)

    def action_create_amazon_shipment(self):
        shipment_model = self.env['amazon.shipment']
        created = shipment_model
        for picking in self:
            if not picking.amazon_order_id:
                continue
            shipment = shipment_model.create({
                'account_id': picking.amazon_order_id.account_id.id,
                'order_id': picking.amazon_order_id.id,
                'picking_id': picking.id,
                'carrier_id': picking.carrier_id.id,
                'tracking_number': picking.carrier_tracking_ref,
                'state': 'ready',
            })
            shipment.action_prepare_from_order()
            picking.amazon_shipment_id = shipment
            created |= shipment
        return {
            'type': 'ir.actions.act_window',
            'name': _('Amazon Shipments'),
            'res_model': 'amazon.shipment',
            'view_mode': 'list,form',
            'domain': [('id', 'in', created.ids)],
        }
