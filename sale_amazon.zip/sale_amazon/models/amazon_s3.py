# -*- coding: utf-8 -*-
from odoo import _, api, fields, models
from odoo.exceptions import UserError, ValidationError

from ..services.s3_client import AmazonS3Client, AmazonS3Error


class AmazonS3Connection(models.Model):
    _name = 'amazon.s3.connection'
    _description = 'Amazon S3 Connection'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'sequence, name'

    name = fields.Char(required=True, tracking=True)
    sequence = fields.Integer(default=10)
    active = fields.Boolean(default=True)
    company_id = fields.Many2one('res.company', required=True, default=lambda self: self.env.company, index=True)
    access_key_id = fields.Char(string='Access Key ID', copy=False, groups='sale_amazon.group_amazon_admin')
    secret_access_key = fields.Char(string='Secret Access Key', copy=False, groups='sale_amazon.group_amazon_admin')
    session_token = fields.Char(string='Session Token', copy=False, groups='sale_amazon.group_amazon_admin')
    region = fields.Char(default='us-east-1', required=True)
    endpoint_url = fields.Char(default='https://s3.us-east-1.amazonaws.com', required=True)
    use_path_style = fields.Boolean(string='Use Path-style URLs', default=True)
    server_side_encryption = fields.Selection([
        ('none', 'None'),
        ('AES256', 'SSE-S3 AES256'),
        ('aws:kms', 'SSE-KMS'),
    ], default='none', string='Server-side Encryption')
    storage_mode = fields.Selection([
        ('reports', 'Reports'),
        ('attachments', 'Attachments'),
        ('exports', 'Exports'),
        ('backups', 'Backups'),
        ('all', 'All Connector Files'),
    ], default='exports', required=True)
    default_prefix = fields.Char(default='odoo/amazon/')
    state = fields.Selection([
        ('draft', 'Draft'),
        ('connected', 'Connected'),
        ('warning', 'Warning'),
        ('error', 'Error'),
        ('disabled', 'Disabled'),
    ], default='draft', tracking=True)
    last_connection_test = fields.Datetime(readonly=True)
    last_bucket_sync = fields.Datetime(readonly=True)
    last_object_sync = fields.Datetime(readonly=True)
    bucket_ids = fields.One2many('amazon.s3.bucket', 'connection_id')
    default_bucket_id = fields.Many2one('amazon.s3.bucket', string='Default Bucket')
    bucket_count = fields.Integer(compute='_compute_counts')
    object_count = fields.Integer(compute='_compute_counts')
    notes = fields.Text()

    @api.onchange('region')
    def _onchange_region(self):
        for connection in self:
            if connection.region and not connection.endpoint_url:
                connection.endpoint_url = 'https://s3.%s.amazonaws.com' % connection.region

    def _compute_counts(self):
        Object = self.env['amazon.s3.object']
        for connection in self:
            connection.bucket_count = len(connection.bucket_ids)
            connection.object_count = Object.search_count([('connection_id', '=', connection.id)])

    def _get_client(self):
        self.ensure_one()
        return AmazonS3Client(
            access_key_id=self.access_key_id,
            secret_access_key=self.secret_access_key,
            session_token=self.session_token,
            region=self.region,
            endpoint_url=self.endpoint_url,
            use_path_style=self.use_path_style,
        )

    def _log_s3(self, level='info', message='', payload=False, external_id=False):
        return self.env['amazon.sync.log'].sudo().create({
            'name': '%s - Amazon S3' % self.display_name,
            'company_id': self.company_id.id,
            'operation': 'other',
            'level': level,
            'message': message or '',
            'payload': payload or '',
            'external_id': external_id or '',
        })

    def action_test_connection(self):
        for connection in self:
            try:
                connection._get_client().list_buckets()
                connection.write({'state': 'connected', 'last_connection_test': fields.Datetime.now()})
                connection._log_s3('success', _('Amazon S3 connection test succeeded.'))
            except AmazonS3Error as exc:
                connection.write({'state': 'error', 'last_connection_test': fields.Datetime.now()})
                connection._log_s3('error', str(exc))
                raise UserError(_('Amazon S3 connection test failed: %s') % exc) from exc
        return True

    def action_sync_buckets(self):
        Bucket = self.env['amazon.s3.bucket'].sudo()
        for connection in self:
            try:
                bucket_names = connection._get_client().list_buckets()
                synced = 0
                for item in bucket_names:
                    name = item.get('name')
                    bucket = Bucket.search([('connection_id', '=', connection.id), ('name', '=', name)], limit=1)
                    vals = {
                        'connection_id': connection.id,
                        'name': name,
                        'region': connection.region,
                        'purpose': connection.storage_mode,
                        'state': 'available',
                    }
                    if bucket:
                        bucket.write(vals)
                    else:
                        bucket = Bucket.create(vals)
                    synced += 1
                connection.write({'state': 'connected', 'last_bucket_sync': fields.Datetime.now()})
                connection._log_s3('success', _('Synchronized %s S3 buckets.') % synced)
            except AmazonS3Error as exc:
                connection.write({'state': 'error'})
                connection._log_s3('error', str(exc))
                raise UserError(_('Amazon S3 bucket synchronization failed: %s') % exc) from exc
        return True

    def action_sync_objects(self):
        buckets = self.mapped('bucket_ids').filtered(lambda bucket: bucket.active)
        if not buckets:
            raise UserError(_('No active S3 buckets found. Synchronize buckets first or create a bucket mapping manually.'))
        return buckets.action_sync_objects()

    def action_open_buckets(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': _('S3 Buckets'),
            'res_model': 'amazon.s3.bucket',
            'view_mode': 'list,form',
            'domain': [('connection_id', '=', self.id)],
            'context': {'default_connection_id': self.id},
        }

    def action_open_objects(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': _('S3 Objects'),
            'res_model': 'amazon.s3.object',
            'view_mode': 'list,form',
            'domain': [('connection_id', '=', self.id)],
            'context': {'default_connection_id': self.id},
        }

    @api.model
    def cron_sync_s3_objects(self):
        connections = self.search([('active', '=', True), ('state', 'in', ('connected', 'warning'))])
        for connection in connections:
            try:
                connection.action_sync_objects()
            except Exception as exc:  # noqa: BLE001
                connection._log_s3('error', str(exc))
        return True


class AmazonS3Bucket(models.Model):
    _name = 'amazon.s3.bucket'
    _description = 'Amazon S3 Bucket'
    _order = 'connection_id, name'

    name = fields.Char(required=True, index=True)
    active = fields.Boolean(default=True)
    connection_id = fields.Many2one('amazon.s3.connection', required=True, ondelete='cascade', index=True)
    company_id = fields.Many2one(related='connection_id.company_id', store=True, index=True)
    region = fields.Char(default='us-east-1')
    purpose = fields.Selection([
        ('reports', 'Reports'),
        ('attachments', 'Attachments'),
        ('exports', 'Exports'),
        ('backups', 'Backups'),
        ('all', 'All Connector Files'),
    ], default='exports', required=True)
    prefix = fields.Char(default='odoo/amazon/')
    state = fields.Selection([
        ('draft', 'Draft'),
        ('available', 'Available'),
        ('warning', 'Warning'),
        ('error', 'Error'),
    ], default='draft')
    last_sync = fields.Datetime(readonly=True)
    object_ids = fields.One2many('amazon.s3.object', 'bucket_id')
    object_count = fields.Integer(compute='_compute_object_count')
    notes = fields.Text()

    @api.constrains('connection_id', 'name')
    def _check_unique_bucket_per_connection(self):
        for bucket in self:
            name = (bucket.name or '').strip()
            if not bucket.connection_id or not name:
                continue
            duplicate = self.search([
                ('id', '!=', bucket.id),
                ('connection_id', '=', bucket.connection_id.id),
                ('name', '=ilike', name),
            ], limit=1)
            if duplicate:
                raise ValidationError(_('Each S3 bucket can only be mapped once per connection.'))

    def _compute_object_count(self):
        Object = self.env['amazon.s3.object']
        for bucket in self:
            bucket.object_count = Object.search_count([('bucket_id', '=', bucket.id)])

    def action_sync_objects(self):
        Object = self.env['amazon.s3.object'].sudo()
        for bucket in self:
            try:
                objects = bucket.connection_id._get_client().list_objects(bucket.name, prefix=bucket.prefix or bucket.connection_id.default_prefix or '')
                for item in objects:
                    key = item.get('key')
                    vals = {
                        'bucket_id': bucket.id,
                        'key': key,
                        'etag': item.get('etag'),
                        'size_bytes': item.get('size_bytes') or 0,
                        'storage_class': item.get('storage_class') or 'STANDARD',
                        'last_modified_text': item.get('last_modified'),
                        'state': 'synced',
                    }
                    record = Object.search([('bucket_id', '=', bucket.id), ('key', '=', key)], limit=1)
                    if record:
                        record.write(vals)
                    else:
                        Object.create(vals)
                bucket.write({'state': 'available', 'last_sync': fields.Datetime.now()})
                bucket.connection_id.write({'last_object_sync': fields.Datetime.now()})
                bucket.connection_id._log_s3('success', _('Synchronized %s S3 objects from bucket %s.') % (len(objects), bucket.name))
            except AmazonS3Error as exc:
                bucket.write({'state': 'error'})
                bucket.connection_id._log_s3('error', str(exc), external_id=bucket.name)
                raise UserError(_('Amazon S3 object synchronization failed for bucket %s: %s') % (bucket.name, exc)) from exc
        return True

    def action_open_objects(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': _('S3 Objects'),
            'res_model': 'amazon.s3.object',
            'view_mode': 'list,form',
            'domain': [('bucket_id', '=', self.id)],
            'context': {'default_bucket_id': self.id},
        }


class AmazonS3Object(models.Model):
    _name = 'amazon.s3.object'
    _description = 'Amazon S3 Object'
    _order = 'last_modified_text desc, key'

    bucket_id = fields.Many2one('amazon.s3.bucket', required=True, ondelete='cascade', index=True)
    connection_id = fields.Many2one(related='bucket_id.connection_id', store=True, index=True)
    company_id = fields.Many2one(related='connection_id.company_id', store=True, index=True)
    bucket_name = fields.Char(related='bucket_id.name', store=True)
    key = fields.Char(required=True, index=True)
    etag = fields.Char(string='ETag')
    size_bytes = fields.Integer(string='Size (bytes)')
    last_modified_text = fields.Char(string='Last Modified')
    storage_class = fields.Char(default='STANDARD')
    content_type = fields.Char()
    attachment_id = fields.Many2one('ir.attachment', string='Related Attachment', ondelete='set null')
    res_model = fields.Char(string='Related Model')
    res_id = fields.Integer(string='Related Record ID')
    state = fields.Selection([
        ('draft', 'Draft'),
        ('synced', 'Synced'),
        ('uploaded', 'Uploaded'),
        ('archived', 'Archived'),
        ('error', 'Error'),
    ], default='draft')
    object_url = fields.Char(compute='_compute_object_url')
    notes = fields.Text()

    @api.constrains('bucket_id', 'key')
    def _check_unique_object_key_per_bucket(self):
        for obj in self:
            key = (obj.key or '').strip()
            if not obj.bucket_id or not key:
                continue
            duplicate = self.search([
                ('id', '!=', obj.id),
                ('bucket_id', '=', obj.bucket_id.id),
                ('key', '=ilike', key),
            ], limit=1)
            if duplicate:
                raise ValidationError(_('Each S3 object key can only be stored once per bucket.'))

    def _compute_object_url(self):
        for obj in self:
            if obj.bucket_id and obj.key:
                endpoint = (obj.connection_id.endpoint_url or '').rstrip('/')
                if obj.connection_id.use_path_style:
                    obj.object_url = '%s/%s/%s' % (endpoint, obj.bucket_id.name, obj.key)
                else:
                    obj.object_url = '%s/%s' % (endpoint.replace('://', '://%s.' % obj.bucket_id.name), obj.key)
            else:
                obj.object_url = False

    def action_open_attachment(self):
        self.ensure_one()
        if not self.attachment_id:
            raise UserError(_('No the platform attachment is linked to this S3 object.'))
        return {
            'type': 'ir.actions.act_window',
            'name': _('Attachment'),
            'res_model': 'ir.attachment',
            'view_mode': 'form',
            'res_id': self.attachment_id.id,
        }
