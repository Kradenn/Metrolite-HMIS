# -*- coding: utf-8 -*-
from odoo import fields, models


class SaleOrder(models.Model):
    _inherit = 'sale.order'

    amazon_order_id = fields.Many2one('amazon.order', string='Amazon Order', copy=False, readonly=True)
    amazon_account_id = fields.Many2one(related='amazon_order_id.account_id', store=True, readonly=True)
    amazon_fulfillment_type = fields.Selection(related='amazon_order_id.fulfillment_type', store=True, readonly=True)
