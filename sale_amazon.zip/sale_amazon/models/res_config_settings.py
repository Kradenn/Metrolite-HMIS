# -*- coding: utf-8 -*-
from odoo import api, fields, models, _
from odoo.exceptions import ValidationError


class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    amazon_default_order_import_minutes = fields.Integer(
        string='Amazon Order Import Interval (minutes)',
        default=15,
        config_parameter='sale_amazon.default_order_import_minutes',
    )
    amazon_default_inventory_sync_minutes = fields.Integer(
        string='Amazon Inventory Sync Interval (minutes)',
        default=30,
        config_parameter='sale_amazon.default_inventory_sync_minutes',
    )
    amazon_default_price_sync_minutes = fields.Integer(
        string='Amazon Price Sync Interval (minutes)',
        default=60,
        config_parameter='sale_amazon.default_price_sync_minutes',
    )
    amazon_settlement_sync_days = fields.Integer(
        string='Amazon Settlement Lookback Days',
        default=30,
        config_parameter='sale_amazon.settlement_sync_days',
    )
    amazon_default_safety_stock = fields.Float(
        string='Amazon Default Safety Stock',
        config_parameter='sale_amazon.default_safety_stock',
    )
    amazon_auto_create_sales_orders = fields.Boolean(
        string='Amazon Auto-create Sales Orders',
        default=True,
        config_parameter='sale_amazon.auto_create_sales_orders',
    )
    amazon_auto_confirm_fbm_orders = fields.Boolean(
        string='Amazon Auto-confirm FBM Sales Orders',
        config_parameter='sale_amazon.auto_confirm_fbm_orders',
    )
    amazon_notify_on_sync_error = fields.Boolean(
        string='Amazon Sync Error Notifications',
        default=True,
        config_parameter='sale_amazon.notify_on_sync_error',
    )
    amazon_default_warehouse_id = fields.Many2one(
        'stock.warehouse',
        string='Amazon Default Warehouse',
        config_parameter='sale_amazon.default_warehouse_id',
    )
    amazon_s3_enabled = fields.Boolean(
        string='Amazon S3 Storage Enabled',
        config_parameter='sale_amazon.s3_enabled',
    )
    amazon_s3_connection_id = fields.Many2one(
        'amazon.s3.connection',
        string='Amazon Default S3 Connection',
        config_parameter='sale_amazon.s3_connection_id',
    )
    amazon_s3_export_prefix = fields.Char(
        string='Amazon S3 Export Prefix',
        default='odoo/amazon/exports/',
        config_parameter='sale_amazon.s3_export_prefix',
    )

    @api.constrains(
        'amazon_default_order_import_minutes',
        'amazon_default_inventory_sync_minutes',
        'amazon_default_price_sync_minutes',
        'amazon_settlement_sync_days',
        'amazon_default_safety_stock',
    )
    def _check_sale_amazon_settings_values(self):
        for settings in self:
            if settings.amazon_default_order_import_minutes <= 0:
                raise ValidationError(_('Amazon order import interval must be greater than zero.'))
            if settings.amazon_default_inventory_sync_minutes <= 0:
                raise ValidationError(_('Amazon inventory sync interval must be greater than zero.'))
            if settings.amazon_default_price_sync_minutes <= 0:
                raise ValidationError(_('Amazon price sync interval must be greater than zero.'))
            if settings.amazon_settlement_sync_days <= 0:
                raise ValidationError(_('Amazon settlement lookback days must be greater than zero.'))
            if settings.amazon_default_safety_stock < 0:
                raise ValidationError(_('Amazon default safety stock cannot be negative.'))

    @api.constrains('amazon_s3_export_prefix')
    def _check_amazon_s3_export_prefix(self):
        for settings in self:
            prefix = (settings.amazon_s3_export_prefix or '').strip()
            if prefix and prefix.startswith('/'):
                raise ValidationError(_('Amazon S3 export prefix must be a relative key prefix, not an absolute path.'))
