# -*- coding: utf-8 -*-
from odoo import fields, models


class ProductTemplate(models.Model):
    _inherit = 'product.template'

    amazon_enabled = fields.Boolean(string='Sell on Amazon')
    amazon_default_fulfillment_type = fields.Selection([('fba', 'FBA'), ('fbm', 'FBM')], default='fbm')
    amazon_title = fields.Char()
    amazon_bullet_points = fields.Text()
    amazon_keywords = fields.Char()
    amazon_manufacturer = fields.Char()
    amazon_condition = fields.Selection([
        ('new', 'New'),
        ('used_like_new', 'Used - Like New'),
        ('used_very_good', 'Used - Very Good'),
        ('used_good', 'Used - Good'),
        ('refurbished', 'Refurbished'),
    ], default='new')
    amazon_listing_ids = fields.One2many('amazon.listing', 'product_tmpl_id', string='Amazon Listings')


class ProductProduct(models.Model):
    _inherit = 'product.product'

    amazon_sku = fields.Char(string='Amazon SKU')
    amazon_asin = fields.Char(string='Amazon ASIN')
