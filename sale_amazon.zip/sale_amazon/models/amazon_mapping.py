# -*- coding: utf-8 -*-
from odoo import fields, models


class AmazonMarketplaceMapping(models.Model):
    _name = 'amazon.marketplace.mapping'
    _description = 'Amazon Marketplace Mapping'
    _order = 'sequence, name'

    sequence = fields.Integer(default=10)
    name = fields.Char(required=True)
    marketplace_region = fields.Selection([
        ('us', 'Amazon US'), ('uk', 'Amazon UK'), ('eu', 'Amazon EU'), ('ca', 'Amazon CA'),
        ('ae', 'Amazon AE'), ('in', 'Amazon IN'), ('jp', 'Amazon JP'), ('au', 'Amazon AU'),
    ], required=True)
    marketplace_id = fields.Char(required=True)
    country_id = fields.Many2one('res.country')
    currency_id = fields.Many2one('res.currency')
    endpoint = fields.Char()
    active = fields.Boolean(default=True)


class AmazonCategoryMapping(models.Model):
    _name = 'amazon.category.mapping'
    _description = 'Amazon Category Mapping'
    _order = 'sequence, amazon_category_name'

    sequence = fields.Integer(default=10)
    account_id = fields.Many2one('amazon.account', ondelete='cascade')
    company_id = fields.Many2one(related='account_id.company_id', store=True, readonly=True)
    amazon_category_id = fields.Char(required=True)
    amazon_category_name = fields.Char(required=True)
    product_category_id = fields.Many2one('product.category', string='the platform Product Category', required=True)
    browse_node_id = fields.Char()
    parent_category = fields.Char()
    required_attribute_ids = fields.One2many('amazon.category.attribute', 'category_mapping_id')
    active = fields.Boolean(default=True)


class AmazonCategoryAttribute(models.Model):
    _name = 'amazon.category.attribute'
    _description = 'Amazon Category Attribute'

    category_mapping_id = fields.Many2one('amazon.category.mapping', required=True, ondelete='cascade')
    name = fields.Char(required=True)
    amazon_attribute_code = fields.Char(required=True)
    required = fields.Boolean(default=False)
    odoo_field_name = fields.Char(help='Technical the platform field name used to populate this Amazon attribute.')


class AmazonTaxMapping(models.Model):
    _name = 'amazon.tax.mapping'
    _description = 'Amazon Tax Mapping'
    _order = 'account_id, amazon_tax_code'

    account_id = fields.Many2one('amazon.account', required=True, ondelete='cascade')
    company_id = fields.Many2one(related='account_id.company_id', store=True)
    amazon_tax_code = fields.Char(required=True)
    tax_id = fields.Many2one('account.tax', required=True, domain="[('company_id', '=', company_id)]")
    description = fields.Char()
    active = fields.Boolean(default=True)


class AmazonShippingMapping(models.Model):
    _name = 'amazon.shipping.mapping'
    _description = 'Amazon Shipping Mapping'
    _order = 'account_id, amazon_shipping_method'

    account_id = fields.Many2one('amazon.account', required=True, ondelete='cascade')
    company_id = fields.Many2one(related='account_id.company_id', store=True)
    amazon_shipping_method = fields.Char(required=True)
    carrier_id = fields.Many2one('delivery.carrier', required=True)
    service_level = fields.Selection([('standard', 'Standard'), ('expedited', 'Expedited'), ('priority', 'Priority'), ('same_day', 'Same Day')], default='standard')
    active = fields.Boolean(default=True)


class AmazonNotificationRule(models.Model):
    _name = 'amazon.notification.rule'
    _description = 'Amazon Notification Rule'
    _order = 'sequence, name'

    sequence = fields.Integer(default=10)
    name = fields.Char(required=True)
    account_id = fields.Many2one('amazon.account', ondelete='cascade')
    company_id = fields.Many2one(related='account_id.company_id', store=True)
    event_type = fields.Selection([
        ('sync_error', 'Sync Error'),
        ('listing_issue', 'Listing Issue'),
        ('account_health', 'Account Health Warning'),
        ('policy_violation', 'Policy Violation'),
        ('refund_request', 'Refund Request'),
        ('low_stock', 'Low Stock'),
    ], required=True)
    user_ids = fields.Many2many('res.users', string='Notify Users')
    email_template_id = fields.Many2one('mail.template')
    active = fields.Boolean(default=True)
