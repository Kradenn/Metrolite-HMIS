# -*- coding: utf-8 -*-
from odoo import api, fields, models


class AmazonAdvertisingInsight(models.Model):
    _name = 'amazon.ad.insight'
    _description = 'Amazon Advertising Insight'
    _order = 'date desc, campaign_name'

    account_id = fields.Many2one('amazon.account', required=True, ondelete='cascade')
    company_id = fields.Many2one(related='account_id.company_id', store=True)
    date = fields.Date(default=fields.Date.context_today, required=True)
    campaign_name = fields.Char(required=True)
    ad_group_name = fields.Char()
    product_id = fields.Many2one('product.product')
    listing_id = fields.Many2one('amazon.listing', domain="[('account_id', '=', account_id)]")
    impressions = fields.Integer()
    clicks = fields.Integer()
    spend = fields.Monetary(currency_field='currency_id')
    sales = fields.Monetary(currency_field='currency_id')
    orders = fields.Integer()
    cpc = fields.Monetary(currency_field='currency_id', compute='_compute_metrics', store=True)
    roas = fields.Float(compute='_compute_metrics', store=True)
    conversion_rate = fields.Float(compute='_compute_metrics', store=True)
    currency_id = fields.Many2one(related='account_id.currency_id', store=True)

    @api.depends('clicks', 'spend', 'sales', 'orders')
    def _compute_metrics(self):
        for rec in self:
            rec.cpc = rec.spend / rec.clicks if rec.clicks else 0.0
            rec.roas = rec.sales / rec.spend if rec.spend else 0.0
            rec.conversion_rate = (rec.orders / rec.clicks * 100.0) if rec.clicks else 0.0
