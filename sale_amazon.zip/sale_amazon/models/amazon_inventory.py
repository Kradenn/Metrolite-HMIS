# -*- coding: utf-8 -*-
from odoo import _, api, fields, models
from odoo.exceptions import ValidationError


class AmazonInventoryRecord(models.Model):
    _name = 'amazon.inventory.record'
    _description = 'Amazon Inventory Record'
    _order = 'last_sync desc, sku'

    account_id = fields.Many2one('amazon.account', required=True, ondelete='cascade', index=True)
    company_id = fields.Many2one(related='account_id.company_id', store=True, readonly=True)
    listing_id = fields.Many2one('amazon.listing', ondelete='set null')
    product_id = fields.Many2one('product.product', required=True)
    sku = fields.Char(required=True, index=True)
    warehouse_id = fields.Many2one('stock.warehouse')
    fulfillment_type = fields.Selection([('fba', 'FBA'), ('fbm', 'FBM')], default='fbm')
    sync_mode = fields.Selection([('push', 'Push Stock to Amazon'), ('pull', 'Pull Stock from Amazon')], default='push', required=True)
    available_qty = fields.Float(string='Available Stock')
    reserved_qty = fields.Float(string='Reserved Stock')
    fba_qty = fields.Float(string='FBA Stock')
    inbound_qty = fields.Float(string='Inbound Stock')
    safety_stock_qty = fields.Float()
    quantity_to_sync = fields.Float(compute='_compute_quantity_to_sync', store=True)
    last_sync = fields.Datetime(readonly=True)
    state = fields.Selection([('ok', 'OK'), ('warning', 'Warning'), ('error', 'Error')], default='ok')
    notes = fields.Text()

    @api.constrains('account_id', 'sku', 'fulfillment_type')
    def _check_unique_sku_account_fulfillment(self):
        for rec in self:
            sku = (rec.sku or '').strip()
            if not rec.account_id or not sku or not rec.fulfillment_type:
                continue
            duplicate = self.search([
                ('id', '!=', rec.id),
                ('account_id', '=', rec.account_id.id),
                ('sku', '=ilike', sku),
                ('fulfillment_type', '=', rec.fulfillment_type),
            ], limit=1)
            if duplicate:
                raise ValidationError(_('Inventory SKU must be unique per account and fulfillment type.'))


    @api.depends('available_qty', 'reserved_qty', 'safety_stock_qty')
    def _compute_quantity_to_sync(self):
        for rec in self:
            rec.quantity_to_sync = max((rec.available_qty or 0.0) - (rec.reserved_qty or 0.0) - (rec.safety_stock_qty or 0.0), 0.0)

    @api.model
    def _upsert_from_amazon(self, account, item):
        sku = item.get('sellerSku') or item.get('sellerSKU') or item.get('sku')
        asin = item.get('asin')
        if not sku:
            return self.browse()
        listing = self.env['amazon.listing'].search([('account_id', '=', account.id), '|', ('sku', '=', sku), ('asin', '=', asin)], limit=1)
        product = listing.product_id or self.env['product.product'].search([('default_code', '=', sku)], limit=1)
        if not product:
            product = self.env['product.product'].create({'name': sku, 'default_code': sku, 'type': 'consu'})
        quantity = item.get('totalQuantity') or item.get('inventoryDetails', {}).get('fulfillableQuantity') or 0.0
        vals = {
            'account_id': account.id,
            'company_id': account.company_id.id,
            'listing_id': listing.id,
            'product_id': product.id,
            'sku': sku,
            'fulfillment_type': 'fba',
            'sync_mode': 'pull',
            'available_qty': quantity,
            'fba_qty': quantity,
            'last_sync': fields.Datetime.now(),
        }
        record = self.search([('account_id', '=', account.id), ('sku', '=', sku), ('fulfillment_type', '=', 'fba')], limit=1)
        if record:
            record.write(vals)
        else:
            record = self.create(vals)
        if listing:
            listing.write({'fba_stock_qty': quantity, 'amazon_stock_qty': quantity, 'last_inventory_sync': fields.Datetime.now()})
        return record

    def action_push_stock(self):
        for rec in self:
            rec.last_sync = fields.Datetime.now()
            rec.account_id._log_sync('push_stock', 'success', _('Prepared inventory sync for SKU %s quantity %s.') % (rec.sku, rec.quantity_to_sync), external_id=rec.sku)
        return True
