# -*- coding: utf-8 -*-
from odoo import _, api, fields, models


class AmazonSyncLog(models.Model):
    _name = 'amazon.sync.log'
    _description = 'Amazon Sync Log'
    _order = 'create_date desc'

    name = fields.Char(required=True)
    account_id = fields.Many2one('amazon.account', ondelete='set null', index=True)
    company_id = fields.Many2one('res.company', default=lambda self: self.env.company, index=True)
    operation = fields.Selection([
        ('health_check', 'Health Check'),
        ('import_orders', 'Import Orders'),
        ('sync_products', 'Sync Products'),
        ('push_listing', 'Push Listing'),
        ('pull_listing', 'Pull Listing'),
        ('sync_inventory', 'Sync Inventory'),
        ('push_stock', 'Push Stock'),
        ('sync_prices', 'Sync Prices'),
        ('push_price', 'Push Price'),
        ('price_rule', 'Pricing Rule'),
        ('sync_settlements', 'Sync Settlements'),
        ('sync_returns', 'Sync Returns'),
        ('shipment_confirmation', 'Shipment Confirmation'),
        ('shipping_label', 'Shipping Label'),
        ('return_restock', 'Return Restock'),
        ('other', 'Other'),
    ], default='other', required=True)
    level = fields.Selection([('debug', 'Debug'), ('info', 'Info'), ('success', 'Success'), ('warning', 'Warning'), ('error', 'Error')], default='info', required=True)
    state = fields.Selection([('open', 'Open'), ('resolved', 'Resolved'), ('ignored', 'Ignored')], default='open')
    message = fields.Text()
    payload = fields.Text()
    external_id = fields.Char(index=True)
    job_id = fields.Many2one('amazon.sync.job')

    def action_resolve(self):
        self.write({'state': 'resolved'})

    def action_ignore(self):
        self.write({'state': 'ignored'})


class AmazonSyncJob(models.Model):
    _name = 'amazon.sync.job'
    _description = 'Amazon Sync Job'
    _inherit = ['mail.thread']
    _order = 'priority desc, create_date asc'

    name = fields.Char(required=True)
    account_id = fields.Many2one('amazon.account', required=True, ondelete='cascade')
    company_id = fields.Many2one(related='account_id.company_id', store=True)
    operation = fields.Selection([
        ('import_orders', 'Import Orders'),
        ('sync_products', 'Sync Products'),
        ('sync_inventory', 'Sync Inventory'),
        ('sync_prices', 'Sync Prices'),
        ('sync_settlements', 'Sync Settlements'),
        ('sync_returns', 'Sync Returns'),
    ], required=True)
    state = fields.Selection([('pending', 'Pending'), ('running', 'Running'), ('done', 'Done'), ('failed', 'Failed'), ('cancelled', 'Cancelled')], default='pending', tracking=True)
    priority = fields.Integer(default=5)
    attempt = fields.Integer(default=0)
    max_attempt = fields.Integer(default=3)
    scheduled_at = fields.Datetime(default=fields.Datetime.now)
    started_at = fields.Datetime(readonly=True)
    finished_at = fields.Datetime(readonly=True)
    error_message = fields.Text(readonly=True)
    log_ids = fields.One2many('amazon.sync.log', 'job_id')

    def action_run_now(self):
        for job in self:
            job._run_job()
        return True

    def action_cancel(self):
        self.write({'state': 'cancelled'})

    def action_retry(self):
        self.write({'state': 'pending', 'error_message': False})

    def _run_job(self):
        self.ensure_one()
        if self.state not in ('pending', 'failed'):
            return False
        self.write({'state': 'running', 'started_at': fields.Datetime.now(), 'attempt': self.attempt + 1})
        method_map = {
            'import_orders': '_import_orders',
            'sync_products': '_sync_products',
            'sync_inventory': '_sync_inventory',
            'sync_prices': '_sync_prices',
            'sync_settlements': '_sync_settlements',
            'sync_returns': '_sync_returns',
        }
        try:
            getattr(self.account_id, method_map[self.operation])()
            self.write({'state': 'done', 'finished_at': fields.Datetime.now(), 'error_message': False})
            self.account_id._log_sync(self.operation, 'success', _('Sync job completed.'), external_id=self.name).job_id = self.id
        except Exception as exc:  # noqa: BLE001
            state = 'failed' if self.attempt >= self.max_attempt else 'pending'
            self.write({'state': state, 'finished_at': fields.Datetime.now(), 'error_message': str(exc)})
            log = self.account_id._log_sync(self.operation, 'error', str(exc), external_id=self.name)
            log.job_id = self.id
        return True

    @api.model
    def cron_run_pending_jobs(self):
        jobs = self.search([('state', '=', 'pending'), ('scheduled_at', '<=', fields.Datetime.now())], limit=20)
        for job in jobs:
            job._run_job()
        return True
