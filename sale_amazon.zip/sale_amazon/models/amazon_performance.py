# -*- coding: utf-8 -*-
from odoo import api, fields, models


class AmazonPerformanceMetric(models.Model):
    _name = 'amazon.performance.metric'
    _description = 'Amazon Seller Performance Metric'
    _order = 'date desc'

    account_id = fields.Many2one('amazon.account', required=True, ondelete='cascade')
    company_id = fields.Many2one(related='account_id.company_id', store=True)
    date = fields.Date(default=fields.Date.context_today, required=True)
    buy_box_percentage = fields.Float(string='Buy Box %')
    order_defect_rate = fields.Float(string='Order Defect Rate %')
    late_shipment_rate = fields.Float(string='Late Shipment Rate %')
    cancellation_rate = fields.Float(string='Cancellation Rate %')
    return_rate = fields.Float(string='Return Rate %')
    seller_rating = fields.Float()
    account_health_score = fields.Float()
    policy_violation_count = fields.Integer()
    listing_suppression_count = fields.Integer()
    alert_level = fields.Selection([('green', 'Green'), ('amber', 'Amber'), ('red', 'Red')], compute='_compute_alert_level', store=True)
    notes = fields.Text()

    @api.depends('order_defect_rate', 'late_shipment_rate', 'cancellation_rate', 'policy_violation_count', 'listing_suppression_count')
    def _compute_alert_level(self):
        for rec in self:
            if rec.policy_violation_count or rec.order_defect_rate > 1.0 or rec.late_shipment_rate > 4.0 or rec.cancellation_rate > 2.5:
                rec.alert_level = 'red'
            elif rec.listing_suppression_count or rec.return_rate > 10.0:
                rec.alert_level = 'amber'
            else:
                rec.alert_level = 'green'
