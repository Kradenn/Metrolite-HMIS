# -*- coding: utf-8 -*-
from odoo import _, api, fields, models
from odoo.exceptions import UserError, ValidationError


class AmazonListing(models.Model):
    _name = 'amazon.listing'
    _description = 'Amazon Product Listing'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'write_date desc, sku'
    _rec_name = 'display_name'

    display_name = fields.Char(compute='_compute_display_name', store=True)
    account_id = fields.Many2one('amazon.account', required=True, ondelete='cascade', index=True)
    company_id = fields.Many2one(related='account_id.company_id', store=True, readonly=True)
    marketplace_region = fields.Selection(related='account_id.marketplace_region', store=True, readonly=True)
    sku = fields.Char(string='SKU', required=True, index=True, tracking=True)
    asin = fields.Char(string='ASIN', index=True, tracking=True)
    product_id = fields.Many2one('product.product', string='Product', required=True, index=True)
    product_tmpl_id = fields.Many2one(related='product_id.product_tmpl_id', store=True, readonly=True)
    category_id = fields.Many2one('amazon.category.mapping', string='Category')
    title = fields.Char(required=True)
    description = fields.Text()
    brand = fields.Char()
    barcode = fields.Char(related='product_id.barcode', readonly=False)
    price = fields.Monetary(currency_field='currency_id', tracking=True)
    currency_id = fields.Many2one(related='account_id.currency_id', store=True, readonly=True)
    stock_qty = fields.Float(string='Stock', compute='_compute_stock_qty', store=False)
    amazon_stock_qty = fields.Float(string='Amazon Stock')
    reserved_qty = fields.Float(string='Reserved Stock')
    fba_stock_qty = fields.Float(string='FBA Stock')
    inbound_qty = fields.Float(string='Inbound Stock')
    listing_status = fields.Selection([
        ('draft', 'Draft'),
        ('active', 'Active'),
        ('inactive', 'Inactive'),
        ('blocked', 'Blocked'),
        ('error', 'Error'),
    ], default='draft', required=True, tracking=True)
    fulfillment_type = fields.Selection([('fba', 'FBA'), ('fbm', 'FBM')], default='fbm', required=True, tracking=True)
    sync_inventory = fields.Boolean(default=True)
    sync_price = fields.Boolean(default=True)
    last_product_sync = fields.Datetime(readonly=True)
    last_inventory_sync = fields.Datetime(readonly=True)
    last_price_sync = fields.Datetime(readonly=True)
    last_error = fields.Text(readonly=True)
    listing_issue_ids = fields.One2many('amazon.listing.issue', 'listing_id')
    image_url = fields.Char()
    buy_box_price = fields.Monetary(currency_field='currency_id')
    buy_box_eligible = fields.Boolean()
    buy_box_percentage = fields.Float()

    @api.constrains('account_id', 'sku', 'asin')
    def _check_unique_amazon_identifiers(self):
        for listing in self:
            if not listing.account_id:
                continue
            sku = (listing.sku or '').strip()
            asin = (listing.asin or '').strip()
            if sku:
                duplicate_sku = self.search([
                    ('id', '!=', listing.id),
                    ('account_id', '=', listing.account_id.id),
                    ('sku', '=ilike', sku),
                ], limit=1)
                if duplicate_sku:
                    raise ValidationError(_('SKU must be unique per Amazon account.'))
            if asin:
                duplicate_asin = self.search([
                    ('id', '!=', listing.id),
                    ('account_id', '=', listing.account_id.id),
                    ('asin', '=ilike', asin),
                ], limit=1)
                if duplicate_asin:
                    raise ValidationError(_('ASIN must be unique per Amazon account.'))


    @api.depends('sku', 'asin', 'product_id')
    def _compute_display_name(self):
        for listing in self:
            listing.display_name = '[%s] %s%s' % (
                listing.sku or '-',
                listing.product_id.display_name or listing.title or _('Amazon Listing'),
                (' / %s' % listing.asin) if listing.asin else '',
            )

    @api.depends('product_id.qty_available')
    def _compute_stock_qty(self):
        for listing in self:
            qty = listing.product_id.qty_available
            safety = listing.account_id.safety_stock_qty or 0.0
            listing.stock_qty = max(qty - safety, 0.0)

    @api.onchange('product_id')
    def _onchange_product_id(self):
        for listing in self:
            if listing.product_id:
                listing.sku = listing.sku or listing.product_id.default_code
                listing.title = listing.title or listing.product_id.display_name
                listing.price = listing.price or listing.product_id.lst_price

    def action_push_to_amazon(self):
        for listing in self:
            try:
                if not listing.product_id.default_code and not listing.sku:
                    raise UserError(_('The product must have an internal reference/SKU before pushing to Amazon.'))
                feed_payload = listing._prepare_listing_feed_payload()
                # In real deployments, create a feed document first, upload XML/JSON, then submit the feed.
                listing.account_id._log_sync('push_listing', 'info', _('Prepared listing feed payload for %s.') % listing.sku, payload=str(feed_payload), external_id=listing.sku)
                listing.write({
                    'listing_status': 'active',
                    'last_product_sync': fields.Datetime.now(),
                    'last_error': False,
                })
            except Exception as exc:  # noqa: BLE001
                listing.write({'listing_status': 'error', 'last_error': str(exc)})
                listing.account_id._log_sync('push_listing', 'error', str(exc), external_id=listing.sku)
        return True

    def action_pull_from_amazon(self):
        for listing in self:
            listing.account_id._log_sync('pull_listing', 'info', _('Listing pull hook executed for %s.') % listing.sku, external_id=listing.sku)
            listing.write({'last_product_sync': fields.Datetime.now()})
        return True

    def action_sync_stock(self):
        for listing in self:
            listing.amazon_stock_qty = listing.stock_qty
            listing.last_inventory_sync = fields.Datetime.now()
            listing.account_id._log_sync('push_stock', 'success', _('Stock prepared for Amazon: %s units.') % listing.stock_qty, external_id=listing.sku)
        return True

    def action_sync_price(self):
        for listing in self:
            listing.last_price_sync = fields.Datetime.now()
            listing.account_id._log_sync('push_price', 'success', _('Price prepared for Amazon: %s.') % listing.price, external_id=listing.sku)
        return True

    def _prepare_listing_feed_payload(self):
        self.ensure_one()
        return {
            'sku': self.sku,
            'asin': self.asin,
            'title': self.title,
            'description': self.description or self.product_tmpl_id.description_sale,
            'price': self.price,
            'currency': self.currency_id.name,
            'barcode': self.barcode,
            'fulfillment_type': self.fulfillment_type,
            'available_quantity': self.stock_qty,
            'marketplace_id': self.account_id.marketplace_id,
        }


class AmazonListingIssue(models.Model):
    _name = 'amazon.listing.issue'
    _description = 'Amazon Listing Issue'
    _order = 'severity desc, create_date desc'

    listing_id = fields.Many2one('amazon.listing', required=True, ondelete='cascade')
    account_id = fields.Many2one(related='listing_id.account_id', store=True)
    company_id = fields.Many2one(related='listing_id.company_id', store=True)
    name = fields.Char(required=True)
    severity = fields.Selection([('low', 'Low'), ('medium', 'Medium'), ('high', 'High'), ('critical', 'Critical')], default='medium')
    issue_code = fields.Char()
    message = fields.Text(required=True)
    state = fields.Selection([('open', 'Open'), ('in_progress', 'In Progress'), ('resolved', 'Resolved')], default='open')
    detected_at = fields.Datetime(default=fields.Datetime.now)
    resolved_at = fields.Datetime()

    def action_resolve(self):
        self.write({'state': 'resolved', 'resolved_at': fields.Datetime.now()})
