# -*- coding: utf-8 -*-
from odoo import _, api, fields, models
from odoo.exceptions import UserError, ValidationError


class AmazonOrder(models.Model):
    _name = 'amazon.order'
    _description = 'Amazon Order'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'purchase_date desc, id desc'
    _rec_name = 'amazon_order_id'

    account_id = fields.Many2one('amazon.account', required=True, ondelete='cascade', index=True)
    company_id = fields.Many2one(related='account_id.company_id', store=True, readonly=True)
    amazon_order_id = fields.Char(required=True, index=True, tracking=True)
    marketplace_id = fields.Char(related='account_id.marketplace_id', store=True, readonly=True)
    sale_order_id = fields.Many2one('sale.order', readonly=True, copy=False)
    sale_order_count = fields.Integer(compute='_compute_sale_order_count')
    partner_id = fields.Many2one('res.partner', string='Customer')
    buyer_name = fields.Char()
    buyer_email = fields.Char()
    buyer_phone = fields.Char()
    shipping_name = fields.Char()
    shipping_address = fields.Text()
    purchase_date = fields.Datetime(index=True)
    latest_ship_date = fields.Datetime()
    order_status = fields.Selection([
        ('pending', 'Pending'),
        ('unshipped', 'Unshipped'),
        ('partially_shipped', 'Partially Shipped'),
        ('shipped', 'Shipped'),
        ('cancelled', 'Cancelled'),
        ('returned', 'Returned'),
    ], default='pending', tracking=True)
    fulfillment_type = fields.Selection([('fba', 'FBA'), ('fbm', 'FBM')], default='fbm', tracking=True)
    payment_status = fields.Selection([('pending', 'Pending'), ('paid', 'Paid'), ('refunded', 'Refunded'), ('failed', 'Failed')], default='paid')
    currency_id = fields.Many2one(related='account_id.currency_id', store=True, readonly=True)
    amount_total = fields.Monetary(currency_field='currency_id')
    amount_tax = fields.Monetary(currency_field='currency_id')
    shipping_amount = fields.Monetary(currency_field='currency_id')
    line_ids = fields.One2many('amazon.order.line', 'order_id', copy=True)
    raw_payload = fields.Text(readonly=True)
    last_sync = fields.Datetime(readonly=True)
    picking_count = fields.Integer(compute='_compute_picking_count')
    refund_count = fields.Integer(compute='_compute_refund_count')

    @api.depends('sale_order_id')
    def _compute_sale_order_count(self):
        for order in self:
            order.sale_order_count = 1 if order.sale_order_id else 0

    @api.depends('sale_order_id.picking_ids')
    def _compute_picking_count(self):
        for order in self:
            order.picking_count = len(order.sale_order_id.picking_ids) if order.sale_order_id else 0

    @api.depends('amazon_order_id')
    def _compute_refund_count(self):
        Return = self.env['amazon.return']
        for order in self:
            order.refund_count = Return.search_count([('order_id', '=', order.id)])

    @api.model
    def _map_status(self, status):
        mapping = {
            'Pending': 'pending',
            'Unshipped': 'unshipped',
            'PartiallyShipped': 'partially_shipped',
            'Shipped': 'shipped',
            'Canceled': 'cancelled',
            'Cancelled': 'cancelled',
        }
        return mapping.get(status, 'pending')

    @api.model
    def _upsert_from_amazon(self, account, raw):
        amazon_order_id = raw.get('AmazonOrderId') or raw.get('amazonOrderId')
        if not amazon_order_id:
            return self.browse()
        fulfillment_channel = raw.get('FulfillmentChannel') or raw.get('fulfillmentChannel')
        order_total = raw.get('OrderTotal') or {}
        amount = float(order_total.get('Amount') or raw.get('amount_total') or 0.0)
        buyer_info = raw.get('BuyerInfo') or {}
        shipping = raw.get('ShippingAddress') or {}
        vals = {
            'account_id': account.id,
            'amazon_order_id': amazon_order_id,
            'buyer_name': buyer_info.get('BuyerName') or raw.get('BuyerName'),
            'buyer_email': buyer_info.get('BuyerEmail') or raw.get('BuyerEmail'),
            'buyer_phone': shipping.get('Phone'),
            'shipping_name': shipping.get('Name'),
            'shipping_address': self._format_amazon_address(shipping),
            'purchase_date': raw.get('PurchaseDate') or raw.get('purchaseDate'),
            'latest_ship_date': raw.get('LatestShipDate') or raw.get('latestShipDate'),
            'order_status': self._map_status(raw.get('OrderStatus') or raw.get('orderStatus')),
            'fulfillment_type': 'fba' if fulfillment_channel == 'AFN' else 'fbm',
            'amount_total': amount,
            'raw_payload': str(raw),
            'last_sync': fields.Datetime.now(),
        }
        order = self.search([('account_id', '=', account.id), ('amazon_order_id', '=', amazon_order_id)], limit=1)
        if order:
            order.write(vals)
        else:
            order = self.create(vals)
        return order

    @api.model
    def _format_amazon_address(self, data):
        pieces = [
            data.get('AddressLine1'), data.get('AddressLine2'), data.get('AddressLine3'),
            data.get('City'), data.get('StateOrRegion'), data.get('PostalCode'), data.get('CountryCode'),
        ]
        return '\n'.join([p for p in pieces if p])

    def _get_or_create_partner(self):
        self.ensure_one()
        email = self.buyer_email or ('amazon_%s@example.invalid' % self.amazon_order_id.replace('-', '_'))
        partner = self.partner_id or self.env['res.partner'].search([('email', '=', email)], limit=1)
        if not partner:
            partner = self.env['res.partner'].create({
                'name': self.buyer_name or self.shipping_name or _('Amazon Buyer'),
                'email': email,
                'phone': self.buyer_phone,
                'company_id': False,
                'type': 'contact',
            })
        self.partner_id = partner
        return partner

    def action_create_sale_order(self):
        for order in self:
            if order.sale_order_id:
                continue
            partner = order._get_or_create_partner()
            warehouse = order.account_id.warehouse_id
            sale_vals = {
                'partner_id': partner.id,
                'company_id': order.company_id.id,
                'origin': order.amazon_order_id,
                'amazon_order_id': order.id,
                'client_order_ref': order.amazon_order_id,
            }
            if warehouse:
                sale_vals['warehouse_id'] = warehouse.id
            sale_order = self.env['sale.order'].with_company(order.company_id).create(sale_vals)
            for line in order.line_ids:
                product = line.product_id or self.env['product.product'].search([('default_code', '=', line.sku)], limit=1)
                if not product:
                    product = self.env['product.product'].create({'name': line.title or line.sku, 'default_code': line.sku, 'type': 'consu'})
                self.env['sale.order.line'].create({
                    'order_id': sale_order.id,
                    'product_id': product.id,
                    'name': line.title or product.display_name,
                    'product_uom_qty': line.quantity_ordered,
                    'price_unit': line.price_unit,
                    'tax_id': [(6, 0, line.tax_id.ids)],
                })
            order.sale_order_id = sale_order
            if order.account_id.auto_confirm_fbm_orders and order.fulfillment_type == 'fbm':
                sale_order.action_confirm()
        return True

    def action_open_sale_order(self):
        self.ensure_one()
        if not self.sale_order_id:
            raise UserError(_('No sales order has been created yet.'))
        return {
            'type': 'ir.actions.act_window',
            'res_model': 'sale.order',
            'res_id': self.sale_order_id.id,
            'view_mode': 'form',
        }


    def action_open_pickings(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': _('Pickings'),
            'res_model': 'stock.picking',
            'view_mode': 'list,form',
            'domain': [('id', 'in', self.sale_order_id.picking_ids.ids)],
        }

    def action_open_returns(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': _('Amazon Returns'),
            'res_model': 'amazon.return',
            'view_mode': 'list,form',
            'domain': [('order_id', '=', self.id)],
        }

    def action_mark_shipped(self):
        self.write({'order_status': 'shipped'})


class AmazonOrderLine(models.Model):
    _name = 'amazon.order.line'
    _description = 'Amazon Order Line'
    _order = 'order_id, id'

    order_id = fields.Many2one('amazon.order', required=True, ondelete='cascade')
    account_id = fields.Many2one(related='order_id.account_id', store=True)
    company_id = fields.Many2one(related='order_id.company_id', store=True)
    sku = fields.Char(required=True, index=True)
    asin = fields.Char(index=True)
    product_id = fields.Many2one('product.product')
    title = fields.Char(required=True)
    quantity_ordered = fields.Float(default=1.0)
    quantity_shipped = fields.Float(default=0.0)
    price_unit = fields.Monetary(currency_field='currency_id')
    tax_amount = fields.Monetary(currency_field='currency_id')
    shipping_amount = fields.Monetary(currency_field='currency_id')
    currency_id = fields.Many2one(related='order_id.currency_id', store=True, readonly=True)
    tax_id = fields.Many2many('account.tax')

    @api.constrains('account_id', 'amazon_order_id')
    def _check_unique_amazon_order_id(self):
        for order in self:
            amazon_order_id = (order.amazon_order_id or '').strip()
            if not order.account_id or not amazon_order_id:
                continue
            duplicate = self.search([
                ('id', '!=', order.id),
                ('account_id', '=', order.account_id.id),
                ('amazon_order_id', '=ilike', amazon_order_id),
            ], limit=1)
            if duplicate:
                raise ValidationError(_('Amazon order ID must be unique per account.'))

