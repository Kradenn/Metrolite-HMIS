# -*- coding: utf-8 -*-
from odoo import _, api, fields, models
from odoo.exceptions import UserError


class AmazonPricingRule(models.Model):
    _name = 'amazon.pricing.rule'
    _description = 'Amazon Pricing Rule'
    _inherit = ['mail.thread']
    _order = 'sequence, name'

    name = fields.Char(required=True, tracking=True)
    sequence = fields.Integer(default=10)
    active = fields.Boolean(default=True)
    account_id = fields.Many2one('amazon.account', required=True, ondelete='cascade')
    company_id = fields.Many2one(related='account_id.company_id', store=True, readonly=True)
    marketplace_region = fields.Selection(related='account_id.marketplace_region', store=True, readonly=True)
    listing_id = fields.Many2one('amazon.listing', domain="[('account_id', '=', account_id)]")
    product_id = fields.Many2one('product.product')
    rule_type = fields.Selection([
        ('fixed', 'Fixed Price'),
        ('margin', 'Margin Based'),
        ('competitor', 'Competitor Match'),
        ('discount', 'Discount'),
    ], default='margin', required=True, tracking=True)
    minimum_price = fields.Monetary(currency_field='currency_id', required=True, default=0.0)
    maximum_price = fields.Monetary(currency_field='currency_id')
    target_margin = fields.Float(string='Target Margin %', default=20.0)
    discount_percent = fields.Float(default=0.0)
    competitor_price = fields.Monetary(currency_field='currency_id')
    fixed_price = fields.Monetary(currency_field='currency_id')
    currency_id = fields.Many2one(related='account_id.currency_id', store=True, readonly=True)
    auto_update = fields.Boolean(default=True)
    last_applied = fields.Datetime(readonly=True)
    state = fields.Selection([('draft', 'Draft'), ('active', 'Active'), ('paused', 'Paused')], default='draft')

    def _get_target_listing(self):
        self.ensure_one()
        if self.listing_id:
            return self.listing_id
        domain = [('account_id', '=', self.account_id.id)]
        if self.product_id:
            domain.append(('product_id', '=', self.product_id.id))
        listing = self.env['amazon.listing'].search(domain, limit=1)
        if not listing:
            raise UserError(_('No Amazon listing found for pricing rule %s.') % self.display_name)
        return listing

    def _compute_price(self, listing):
        self.ensure_one()
        base_price = listing.product_id.lst_price or listing.price or 0.0
        cost = listing.product_id.standard_price or 0.0
        if self.rule_type == 'fixed':
            price = self.fixed_price
        elif self.rule_type == 'margin':
            price = cost * (1 + (self.target_margin or 0.0) / 100.0) if cost else base_price
        elif self.rule_type == 'discount':
            price = base_price * (1 - (self.discount_percent or 0.0) / 100.0)
        elif self.rule_type == 'competitor':
            price = self.competitor_price or base_price
        else:
            price = base_price
        if self.minimum_price:
            price = max(price, self.minimum_price)
        if self.maximum_price:
            price = min(price, self.maximum_price)
        return price

    def action_activate(self):
        self.write({'state': 'active'})

    def action_pause(self):
        self.write({'state': 'paused'})

    def action_apply_rule(self):
        for rule in self:
            listing = rule._get_target_listing()
            price = rule._compute_price(listing)
            listing.write({'price': price, 'last_price_sync': fields.Datetime.now()})
            rule.write({'last_applied': fields.Datetime.now(), 'state': 'active'})
            rule.account_id._log_sync('price_rule', 'success', _('Applied pricing rule %s to %s: %s') % (rule.name, listing.sku, price), external_id=listing.sku)
        return True
