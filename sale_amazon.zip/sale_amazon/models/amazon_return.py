# -*- coding: utf-8 -*-
from odoo import _, fields, models
from odoo.exceptions import UserError


class AmazonReturn(models.Model):
    _name = 'amazon.return'
    _description = 'Amazon Return and Refund'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'request_date desc, id desc'

    name = fields.Char(default=lambda self: self.env['ir.sequence'].next_by_code('amazon.return') or _('New'), copy=False, readonly=True)
    account_id = fields.Many2one('amazon.account', required=True, ondelete='cascade')
    company_id = fields.Many2one(related='account_id.company_id', store=True)
    order_id = fields.Many2one('amazon.order', required=True, domain="[('account_id', '=', account_id)]")
    amazon_return_id = fields.Char(index=True)
    reason = fields.Selection([
        ('buyer_remorse', 'Buyer Remorse'),
        ('damaged', 'Damaged'),
        ('defective', 'Defective'),
        ('wrong_item', 'Wrong Item'),
        ('not_as_described', 'Not as Described'),
        ('other', 'Other'),
    ], default='other', required=True)
    request_date = fields.Datetime(default=fields.Datetime.now)
    received_date = fields.Datetime()
    refund_amount = fields.Monetary(currency_field='currency_id')
    currency_id = fields.Many2one(related='account_id.currency_id', store=True)
    product_id = fields.Many2one('product.product')
    quantity = fields.Float(default=1.0)
    restock = fields.Boolean(default=True)
    replacement_order_id = fields.Many2one('sale.order')
    damage_report = fields.Text()
    state = fields.Selection([
        ('requested', 'Requested'),
        ('authorized', 'Authorized'),
        ('received', 'Received'),
        ('refunded', 'Refunded'),
        ('replaced', 'Replaced'),
        ('rejected', 'Rejected'),
    ], default='requested', tracking=True)
    credit_note_id = fields.Many2one('account.move', readonly=True)

    def action_authorize(self):
        self.write({'state': 'authorized'})

    def action_receive(self):
        for rec in self:
            rec.write({'state': 'received', 'received_date': fields.Datetime.now()})
            if rec.restock and rec.product_id:
                rec.account_id._log_sync('return_restock', 'info', _('Restocking requested for %s units of %s.') % (rec.quantity, rec.product_id.display_name))
        return True

    def action_process_refund(self):
        for rec in self:
            if not rec.order_id.sale_order_id:
                raise UserError(_('Create the related the platform sales order before processing an accounting refund.'))
            invoice = rec.order_id.sale_order_id.invoice_ids.filtered(lambda m: m.state == 'posted')[:1]
            if invoice:
                move_reversal = self.env['account.move.reversal'].with_context(active_model='account.move', active_ids=invoice.ids).create({
                    'journal_id': invoice.journal_id.id,
                    'reason': rec.reason,
                    'date': fields.Date.context_today(rec),
                })
                action = move_reversal.refund_moves()
                refund = self.env['account.move'].browse(action.get('res_id')) if isinstance(action, dict) and action.get('res_id') else False
                if refund:
                    rec.credit_note_id = refund
            rec.state = 'refunded'
        return True

    def action_create_replacement(self):
        for rec in self:
            if not rec.order_id.sale_order_id:
                raise UserError(_('Create the related the platform sales order first.'))
            replacement = rec.order_id.sale_order_id.copy({'origin': '%s Replacement' % rec.order_id.amazon_order_id})
            rec.write({'replacement_order_id': replacement.id, 'state': 'replaced'})
        return True
