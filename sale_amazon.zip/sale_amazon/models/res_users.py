# -*- coding: utf-8 -*-
# Neutral compatibility file.
# Amazon access is controlled by native the platform res.groups.privilege records.
# No custom user access fields are defined here.
