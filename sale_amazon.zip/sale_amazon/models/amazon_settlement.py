# -*- coding: utf-8 -*-
from odoo import _, api, fields, models
from odoo.exceptions import UserError, ValidationError


class AmazonSettlement(models.Model):
    _name = 'amazon.settlement'
    _description = 'Amazon Settlement'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'settlement_start_date desc, id desc'

    name = fields.Char(required=True, tracking=True)
    account_id = fields.Many2one('amazon.account', required=True, ondelete='cascade')
    company_id = fields.Many2one(related='account_id.company_id', store=True)
    settlement_id = fields.Char(index=True)
    settlement_start_date = fields.Datetime()
    settlement_end_date = fields.Datetime()
    deposit_date = fields.Datetime()
    currency_id = fields.Many2one(related='account_id.currency_id', store=True)
    sales_amount = fields.Monetary(currency_field='currency_id')
    amazon_fees = fields.Monetary(currency_field='currency_id')
    refund_deductions = fields.Monetary(currency_field='currency_id')
    advertising_fees = fields.Monetary(currency_field='currency_id')
    storage_fees = fields.Monetary(currency_field='currency_id')
    payout_amount = fields.Monetary(currency_field='currency_id', compute='_compute_payout_amount', store=True)
    line_ids = fields.One2many('amazon.settlement.line', 'settlement_id')
    journal_entry_id = fields.Many2one('account.move', readonly=True)
    state = fields.Selection([
        ('draft', 'Draft'),
        ('imported', 'Imported'),
        ('reconciled', 'Reconciled'),
        ('posted', 'Posted'),
        ('error', 'Error'),
    ], default='draft', tracking=True)
    notes = fields.Text()

    @api.constrains('account_id', 'settlement_id')
    def _check_unique_settlement_id(self):
        for settlement in self:
            settlement_id = (settlement.settlement_id or '').strip()
            if not settlement.account_id or not settlement_id:
                continue
            duplicate = self.search([
                ('id', '!=', settlement.id),
                ('account_id', '=', settlement.account_id.id),
                ('settlement_id', '=ilike', settlement_id),
            ], limit=1)
            if duplicate:
                raise ValidationError(_('Settlement ID must be unique per Amazon account.'))


    @api.depends('sales_amount', 'amazon_fees', 'refund_deductions', 'advertising_fees', 'storage_fees')
    def _compute_payout_amount(self):
        for settlement in self:
            settlement.payout_amount = (settlement.sales_amount or 0.0) - (settlement.amazon_fees or 0.0) - (settlement.refund_deductions or 0.0) - (settlement.advertising_fees or 0.0) - (settlement.storage_fees or 0.0)

    @api.model
    def _create_from_report_index(self, account, payload):
        reports = payload.get('reports') or payload.get('payload', {}).get('reports') or []
        for report in reports:
            settlement_id = report.get('reportId')
            if not settlement_id:
                continue
            settlement = self.search([('account_id', '=', account.id), ('settlement_id', '=', settlement_id)], limit=1)
            vals = {
                'name': report.get('reportType') or settlement_id,
                'account_id': account.id,
                'settlement_id': settlement_id,
                'settlement_start_date': report.get('processingStartTime'),
                'settlement_end_date': report.get('processingEndTime'),
                'state': 'imported',
            }
            if settlement:
                settlement.write(vals)
            else:
                self.create(vals)
        return True

    def action_reconcile(self):
        for settlement in self:
            if not settlement.account_id.journal_id:
                raise UserError(_('Configure a settlement journal on the Amazon account.'))
            if not settlement.account_id.receivable_account_id or not settlement.account_id.fee_account_id:
                raise UserError(_('Configure Amazon receivable and fee accounts before reconciliation.'))
            lines = []
            receivable = settlement.account_id.receivable_account_id
            fee_account = settlement.account_id.fee_account_id
            clearing = settlement.account_id.settlement_clearing_account_id or receivable
            if settlement.payout_amount:
                lines.append((0, 0, {
                    'name': _('Amazon payout %s') % settlement.name,
                    'account_id': clearing.id,
                    'debit': settlement.payout_amount if settlement.payout_amount > 0 else 0.0,
                    'credit': abs(settlement.payout_amount) if settlement.payout_amount < 0 else 0.0,
                }))
            fee_total = settlement.amazon_fees + settlement.advertising_fees + settlement.storage_fees + settlement.refund_deductions
            if fee_total:
                lines.append((0, 0, {'name': _('Amazon fees'), 'account_id': fee_account.id, 'debit': fee_total, 'credit': 0.0}))
            if settlement.sales_amount:
                lines.append((0, 0, {'name': _('Amazon sales clearing'), 'account_id': receivable.id, 'debit': 0.0, 'credit': settlement.sales_amount}))
            move = self.env['account.move'].with_company(settlement.company_id).create({
                'move_type': 'entry',
                'journal_id': settlement.account_id.journal_id.id,
                'date': fields.Date.context_today(settlement),
                'ref': settlement.name,
                'line_ids': lines,
            })
            settlement.write({'journal_entry_id': move.id, 'state': 'reconciled'})
        return True

    def action_post_entry(self):
        for settlement in self:
            if settlement.journal_entry_id and settlement.journal_entry_id.state == 'draft':
                settlement.journal_entry_id.action_post()
            settlement.state = 'posted'
        return True


class AmazonSettlementLine(models.Model):
    _name = 'amazon.settlement.line'
    _description = 'Amazon Settlement Line'
    _order = 'settlement_id, id'

    settlement_id = fields.Many2one('amazon.settlement', required=True, ondelete='cascade')
    account_id = fields.Many2one(related='settlement_id.account_id', store=True)
    company_id = fields.Many2one(related='settlement_id.company_id', store=True)
    transaction_type = fields.Selection([
        ('order', 'Order'),
        ('refund', 'Refund'),
        ('fee', 'Fee'),
        ('advertising', 'Advertising'),
        ('storage', 'Storage'),
        ('other', 'Other'),
    ], default='order')
    amazon_order_id = fields.Char()
    description = fields.Char(required=True)
    amount = fields.Monetary(currency_field='currency_id')
    currency_id = fields.Many2one(related='settlement_id.currency_id', store=True)
    product_id = fields.Many2one('product.product')
    fee_type = fields.Char()
