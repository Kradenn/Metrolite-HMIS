# -*- coding: utf-8 -*-
from datetime import timedelta

from odoo import api, fields, models


class AmazonReportWizard(models.TransientModel):
    _name = 'amazon.report.wizard'
    _description = 'Amazon Report Wizard'

    report_type = fields.Selection([
        ('sales', 'Sales Performance'),
        ('settlement', 'Settlement Report'),
        ('profitability', 'Product Profitability'),
        ('fba_fees', 'FBA Fees'),
        ('returns', 'Returns Analysis'),
        ('marketplace', 'Marketplace Performance'),
        ('inventory', 'Inventory Sync Report'),
    ], default='sales', required=True)
    account_id = fields.Many2one('amazon.account')
    date_from = fields.Date(default=lambda self: fields.Date.context_today(self) - timedelta(days=30), required=True)
    date_to = fields.Date(default=fields.Date.context_today, required=True)

    def action_print_pdf(self):
        self.ensure_one()
        return self.env.ref('sale_amazon.action_report_sale_amazon').report_action(self)

    def action_export_xlsx(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_url',
            'url': '/sale_amazon/report/xlsx?wizard_id=%s' % self.id,
            'target': 'self',
        }

    def _get_report_title(self):
        return dict(self._fields['report_type'].selection).get(self.report_type)

    def _base_domain(self, date_field='create_date'):
        domain = []
        if self.account_id:
            domain.append(('account_id', '=', self.account_id.id))
        if self.date_from:
            domain.append((date_field, '>=', fields.Datetime.to_datetime(self.date_from)))
        if self.date_to:
            domain.append((date_field, '<=', fields.Datetime.to_datetime(self.date_to) + timedelta(days=1)))
        return domain

    def _get_report_lines(self):
        self.ensure_one()
        if self.report_type == 'sales':
            orders = self.env['amazon.order'].search(self._base_domain('purchase_date'), limit=500)
            return [{
                'reference': o.amazon_order_id,
                'date': o.purchase_date,
                'marketplace': o.account_id.marketplace_region,
                'status': o.order_status,
                'fulfillment': o.fulfillment_type,
                'amount': o.amount_total,
            } for o in orders]
        if self.report_type == 'settlement':
            settlements = self.env['amazon.settlement'].search(self._base_domain('settlement_start_date'), limit=500)
            return [{
                'reference': s.settlement_id or s.name,
                'date': s.settlement_start_date,
                'marketplace': s.account_id.marketplace_region,
                'status': s.state,
                'fulfillment': '',
                'amount': s.payout_amount,
            } for s in settlements]
        if self.report_type == 'returns':
            returns = self.env['amazon.return'].search(self._base_domain('request_date'), limit=500)
            return [{
                'reference': r.name,
                'date': r.request_date,
                'marketplace': r.account_id.marketplace_region,
                'status': r.state,
                'fulfillment': r.reason,
                'amount': r.refund_amount,
            } for r in returns]
        if self.report_type == 'inventory':
            inv = self.env['amazon.inventory.record'].search(self._base_domain('last_sync'), limit=500)
            return [{
                'reference': r.sku,
                'date': r.last_sync,
                'marketplace': r.account_id.marketplace_region,
                'status': r.state,
                'fulfillment': r.fulfillment_type,
                'amount': r.quantity_to_sync,
            } for r in inv]
        ads = self.env['amazon.ad.insight'].search(self._base_domain('date'), limit=500)
        return [{
            'reference': a.campaign_name,
            'date': a.date,
            'marketplace': a.account_id.marketplace_region,
            'status': 'ROAS %.2f' % a.roas,
            'fulfillment': 'CPC %s' % a.cpc,
            'amount': a.sales,
        } for a in ads]
