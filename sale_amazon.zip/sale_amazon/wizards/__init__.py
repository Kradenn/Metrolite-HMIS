# -*- coding: utf-8 -*-
from . import amazon_report_wizard
