# -*- coding: utf-8 -*-
"""Amazon Selling Partner API client utilities.

This client intentionally keeps HTTP and signing concerns isolated from the platform models.
It implements Login With Amazon token exchange and AWS Signature Version 4 signing for
SP-API calls. In production, keep credentials in the platform's encrypted database/storage and
restrict access to groups that need marketplace configuration.
"""

from __future__ import annotations

import datetime as _dt
import hashlib
import hmac
import json
import logging
from typing import Any, Dict, Optional
from urllib.parse import quote, urlencode, urlsplit

import requests

_logger = logging.getLogger(__name__)

LWA_TOKEN_URL = "https://api.amazon.com/auth/o2/token"
SERVICE_NAME = "execute-api"


class AmazonSPAPIError(Exception):
    """Raised when Amazon SP-API returns an error or invalid payload."""


class AmazonSPAPIClient:
    """Small SP-API client used by the platform account records.

    Parameters are passed from ``amazon.account`` so the class remains framework-free
    and easy to unit test.
    """

    def __init__(
        self,
        endpoint: str,
        aws_access_key: str,
        aws_secret_key: str,
        lwa_client_id: str,
        lwa_client_secret: str,
        refresh_token: str,
        aws_region: str,
        timeout: int = 45,
    ) -> None:
        self.endpoint = (endpoint or "").rstrip("/")
        self.aws_access_key = aws_access_key or ""
        self.aws_secret_key = aws_secret_key or ""
        self.lwa_client_id = lwa_client_id or ""
        self.lwa_client_secret = lwa_client_secret or ""
        self.refresh_token = refresh_token or ""
        self.aws_region = aws_region or "us-east-1"
        self.timeout = timeout

    def get_access_token(self) -> str:
        missing = [
            name for name, value in {
                "lwa_client_id": self.lwa_client_id,
                "lwa_client_secret": self.lwa_client_secret,
                "refresh_token": self.refresh_token,
            }.items() if not value
        ]
        if missing:
            raise AmazonSPAPIError("Missing Amazon LWA credential(s): %s" % ", ".join(missing))
        payload = {
            "grant_type": "refresh_token",
            "refresh_token": self.refresh_token,
            "client_id": self.lwa_client_id,
            "client_secret": self.lwa_client_secret,
        }
        response = requests.post(LWA_TOKEN_URL, data=payload, timeout=self.timeout)
        if response.status_code >= 400:
            raise AmazonSPAPIError("Amazon LWA token request failed: %s" % self._safe_text(response))
        data = response.json()
        token = data.get("access_token")
        if not token:
            raise AmazonSPAPIError("Amazon LWA response did not contain access_token")
        return token

    def request(
        self,
        method: str,
        path: str,
        params: Optional[Dict[str, Any]] = None,
        payload: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        if not self.endpoint:
            raise AmazonSPAPIError("Amazon SP-API endpoint is not configured")
        access_token = self.get_access_token()
        url = "%s/%s" % (self.endpoint, path.lstrip("/"))
        body = json.dumps(payload or {}, separators=(",", ":")) if payload is not None else ""
        request_headers = {
            "content-type": "application/json",
            "host": urlsplit(url).netloc,
            "user-agent": "the platform-Amazon-Connector/19.0",
            "x-amz-access-token": access_token,
        }
        if headers:
            request_headers.update(headers)
        request_headers.update(self._aws_sigv4_headers(method, url, params or {}, body, request_headers))
        response = requests.request(
            method.upper(),
            url,
            params=params or None,
            data=body if body else None,
            headers=request_headers,
            timeout=self.timeout,
        )
        if response.status_code >= 400:
            raise AmazonSPAPIError("Amazon SP-API %s %s failed: %s" % (method.upper(), path, self._safe_text(response)))
        if not response.content:
            return {}
        try:
            return response.json()
        except ValueError:
            return {"raw": response.text}

    def get_orders(self, marketplace_id: str, created_after: str, next_token: Optional[str] = None) -> Dict[str, Any]:
        params: Dict[str, Any] = {"MarketplaceIds": marketplace_id}
        if next_token:
            params["NextToken"] = next_token
        else:
            params["CreatedAfter"] = created_after
        return self.request("GET", "/orders/v0/orders", params=params)

    def get_order_items(self, amazon_order_id: str) -> Dict[str, Any]:
        return self.request("GET", "/orders/v0/orders/%s/orderItems" % quote(amazon_order_id, safe=""))

    def get_inventory_summaries(self, marketplace_id: str, details: bool = True) -> Dict[str, Any]:
        params = {"details": str(details).lower(), "marketplaceIds": marketplace_id}
        return self.request("GET", "/fba/inventory/v1/summaries", params=params)

    def submit_feed(self, feed_type: str, marketplace_id: str, document_id: str) -> Dict[str, Any]:
        payload = {"feedType": feed_type, "marketplaceIds": [marketplace_id], "inputFeedDocumentId": document_id}
        return self.request("POST", "/feeds/2021-06-30/feeds", payload=payload)

    def get_reports(self, report_type: str, marketplace_id: str, created_since_iso: str) -> Dict[str, Any]:
        params = {
            "reportTypes": report_type,
            "marketplaceIds": marketplace_id,
            "createdSince": created_since_iso,
        }
        return self.request("GET", "/reports/2021-06-30/reports", params=params)

    def confirm_shipment(self, amazon_order_id: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        return self.request("POST", "/orders/v0/orders/%s/shipmentConfirmation" % quote(amazon_order_id, safe=""), payload=payload)

    def _aws_sigv4_headers(
        self,
        method: str,
        url: str,
        params: Dict[str, Any],
        body: str,
        headers: Dict[str, str],
    ) -> Dict[str, str]:
        missing = [
            name for name, value in {"access_key": self.aws_access_key, "secret_key": self.aws_secret_key}.items() if not value
        ]
        if missing:
            raise AmazonSPAPIError("Missing Amazon AWS credential(s): %s" % ", ".join(missing))
        now = _dt.datetime.utcnow()
        amz_date = now.strftime("%Y%m%dT%H%M%SZ")
        date_stamp = now.strftime("%Y%m%d")
        parsed = urlsplit(url)
        canonical_uri = parsed.path or "/"
        canonical_querystring = urlencode(sorted((params or {}).items()), doseq=True, quote_via=quote)
        signed_header_names = sorted(k.lower() for k in headers.keys()) + ["x-amz-date"]
        signed_header_names = sorted(set(signed_header_names))
        lower_headers = {k.lower(): v.strip() for k, v in headers.items()}
        lower_headers["x-amz-date"] = amz_date
        canonical_headers = "".join("%s:%s\n" % (key, lower_headers[key]) for key in signed_header_names)
        signed_headers = ";".join(signed_header_names)
        payload_hash = hashlib.sha256((body or "").encode("utf-8")).hexdigest()
        canonical_request = "\n".join([
            method.upper(),
            canonical_uri,
            canonical_querystring,
            canonical_headers,
            signed_headers,
            payload_hash,
        ])
        credential_scope = "%s/%s/%s/aws4_request" % (date_stamp, self.aws_region, SERVICE_NAME)
        string_to_sign = "\n".join([
            "AWS4-HMAC-SHA256",
            amz_date,
            credential_scope,
            hashlib.sha256(canonical_request.encode("utf-8")).hexdigest(),
        ])
        signing_key = self._get_signature_key(self.aws_secret_key, date_stamp, self.aws_region, SERVICE_NAME)
        signature = hmac.new(signing_key, string_to_sign.encode("utf-8"), hashlib.sha256).hexdigest()
        authorization_header = (
            "AWS4-HMAC-SHA256 Credential=%s/%s, SignedHeaders=%s, Signature=%s"
            % (self.aws_access_key, credential_scope, signed_headers, signature)
        )
        return {"x-amz-date": amz_date, "Authorization": authorization_header}

    @staticmethod
    def _sign(key: bytes, msg: str) -> bytes:
        return hmac.new(key, msg.encode("utf-8"), hashlib.sha256).digest()

    @classmethod
    def _get_signature_key(cls, key: str, date_stamp: str, region_name: str, service_name: str) -> bytes:
        k_date = cls._sign(("AWS4" + key).encode("utf-8"), date_stamp)
        k_region = cls._sign(k_date, region_name)
        k_service = cls._sign(k_region, service_name)
        return cls._sign(k_service, "aws4_request")

    @staticmethod
    def _safe_text(response: requests.Response) -> str:
        text = response.text or ""
        return text[:2000]
