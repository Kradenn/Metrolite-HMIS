# -*- coding: utf-8 -*-
"""Small Amazon S3 client used by the the platform connector.

The implementation intentionally avoids a hard dependency on boto3 so the
module can install on a clean the platform server. It signs simple S3 requests with
AWS Signature Version 4 and covers the operational screens needed by the
connector: health check, bucket discovery, and object listing.
"""
from __future__ import annotations

import datetime as _dt
import hashlib
import hmac
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET


class AmazonS3Error(Exception):
    """Raised when Amazon S3 returns an error or the request cannot be signed."""


class AmazonS3Client:
    def __init__(
        self,
        access_key_id,
        secret_access_key,
        region='us-east-1',
        endpoint_url=False,
        session_token=False,
        use_path_style=True,
    ):
        self.access_key_id = access_key_id
        self.secret_access_key = secret_access_key
        self.region = region or 'us-east-1'
        self.endpoint_url = (endpoint_url or 'https://s3.%s.amazonaws.com' % self.region).rstrip('/')
        self.session_token = session_token or False
        self.use_path_style = bool(use_path_style)
        if not self.access_key_id or not self.secret_access_key:
            raise AmazonS3Error('Missing Amazon S3 access key or secret key.')

    def list_buckets(self):
        body = self._request('GET', '/', {})
        root = ET.fromstring(body)
        buckets = []
        for bucket in root.findall('.//{*}Bucket'):
            name = bucket.findtext('{*}Name') or bucket.findtext('Name')
            created = bucket.findtext('{*}CreationDate') or bucket.findtext('CreationDate')
            if name:
                buckets.append({'name': name, 'creation_date': created})
        return buckets

    def list_objects(self, bucket, prefix='', max_keys=1000):
        if not bucket:
            raise AmazonS3Error('Missing bucket name.')
        params = {
            'list-type': '2',
            'max-keys': str(max_keys or 1000),
        }
        if prefix:
            params['prefix'] = prefix
        body = self._request('GET', '/', params, bucket=bucket)
        root = ET.fromstring(body)
        objects = []
        for item in root.findall('.//{*}Contents'):
            key = item.findtext('{*}Key') or item.findtext('Key')
            if not key:
                continue
            objects.append({
                'key': key,
                'etag': (item.findtext('{*}ETag') or item.findtext('ETag') or '').strip('"'),
                'size_bytes': int(item.findtext('{*}Size') or item.findtext('Size') or 0),
                'last_modified': item.findtext('{*}LastModified') or item.findtext('LastModified'),
                'storage_class': item.findtext('{*}StorageClass') or item.findtext('StorageClass') or 'STANDARD',
            })
        return objects

    def _request(self, method, canonical_uri='/', params=None, bucket=False, body=b''):
        params = params or {}
        endpoint = urllib.parse.urlparse(self.endpoint_url)
        scheme = endpoint.scheme or 'https'
        host = endpoint.netloc
        base_path = endpoint.path.rstrip('/')

        if bucket:
            if self.use_path_style:
                canonical_uri = '%s/%s%s' % (base_path, urllib.parse.quote(bucket), canonical_uri if canonical_uri.startswith('/') else '/' + canonical_uri)
                request_host = host
            else:
                canonical_uri = '%s%s' % (base_path, canonical_uri if canonical_uri.startswith('/') else '/' + canonical_uri)
                request_host = '%s.%s' % (bucket, host)
        else:
            canonical_uri = base_path + (canonical_uri if canonical_uri.startswith('/') else '/' + canonical_uri)
            request_host = host

        if not canonical_uri:
            canonical_uri = '/'
        canonical_uri = canonical_uri.replace('//', '/')
        query = urllib.parse.urlencode(sorted(params.items()), doseq=True, quote_via=urllib.parse.quote)
        url = '%s://%s%s' % (scheme, request_host, canonical_uri)
        if query:
            url += '?' + query

        amz_date = _dt.datetime.utcnow().strftime('%Y%m%dT%H%M%SZ')
        date_stamp = amz_date[:8]
        payload_hash = hashlib.sha256(body or b'').hexdigest()
        headers = {
            'host': request_host,
            'x-amz-content-sha256': payload_hash,
            'x-amz-date': amz_date,
        }
        if self.session_token:
            headers['x-amz-security-token'] = self.session_token

        signed_headers = ';'.join(sorted(headers))
        canonical_headers = ''.join('%s:%s\n' % (key, headers[key]) for key in sorted(headers))
        canonical_request = '\n'.join([
            method,
            canonical_uri,
            query,
            canonical_headers,
            signed_headers,
            payload_hash,
        ])
        credential_scope = '%s/%s/s3/aws4_request' % (date_stamp, self.region)
        string_to_sign = '\n'.join([
            'AWS4-HMAC-SHA256',
            amz_date,
            credential_scope,
            hashlib.sha256(canonical_request.encode('utf-8')).hexdigest(),
        ])
        signing_key = self._get_signature_key(self.secret_access_key, date_stamp, self.region, 's3')
        signature = hmac.new(signing_key, string_to_sign.encode('utf-8'), hashlib.sha256).hexdigest()
        headers['Authorization'] = (
            'AWS4-HMAC-SHA256 Credential=%s/%s, SignedHeaders=%s, Signature=%s'
            % (self.access_key_id, credential_scope, signed_headers, signature)
        )
        request = urllib.request.Request(url, data=body or None, headers=headers, method=method)
        try:
            with urllib.request.urlopen(request, timeout=30) as response:  # noqa: S310 - user-managed endpoint
                return response.read()
        except Exception as exc:  # noqa: BLE001 - external endpoint errors are surfaced in the platform logs
            raise AmazonS3Error(str(exc)) from exc

    @staticmethod
    def _sign(key, msg):
        return hmac.new(key, msg.encode('utf-8'), hashlib.sha256).digest()

    @classmethod
    def _get_signature_key(cls, key, date_stamp, region_name, service_name):
        k_date = cls._sign(('AWS4' + key).encode('utf-8'), date_stamp)
        k_region = cls._sign(k_date, region_name)
        k_service = cls._sign(k_region, service_name)
        return cls._sign(k_service, 'aws4_request')
