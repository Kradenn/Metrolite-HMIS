# -*- coding: utf-8 -*-
from odoo.tests import TransactionCase, tagged


@tagged('post_install', '-at_install')
class TestAmazonConnector(TransactionCase):

    def setUp(self):
        super().setUp()
        self.product = self.env['product.product'].create({
            'name': 'Amazon Test Product',
            'default_code': 'AMZ-TEST',
            'type': 'consu',
            'lst_price': 100.0,
            'standard_price': 50.0,
        })
        self.account = self.env['amazon.account'].create({
            'name': 'Test Amazon Account',
            'seller_id': 'A-TEST',
            'marketplace_region': 'us',
            'company_id': self.env.company.id,
        })

    def test_listing_pricing_rule(self):
        listing = self.env['amazon.listing'].create({
            'account_id': self.account.id,
            'product_id': self.product.id,
            'sku': 'AMZ-TEST',
            'title': 'Amazon Test Product',
            'price': 100.0,
        })
        rule = self.env['amazon.pricing.rule'].create({
            'name': 'Margin Rule',
            'account_id': self.account.id,
            'listing_id': listing.id,
            'rule_type': 'margin',
            'minimum_price': 60.0,
            'target_margin': 20.0,
        })
        rule.action_apply_rule()
        self.assertEqual(listing.price, 60.0)

    def test_order_creates_sale_order(self):
        order = self.env['amazon.order'].create({
            'account_id': self.account.id,
            'amazon_order_id': '111-TEST',
            'buyer_name': 'Buyer',
            'buyer_email': 'buyer@example.invalid',
            'amount_total': 100.0,
            'fulfillment_type': 'fbm',
        })
        self.env['amazon.order.line'].create({
            'order_id': order.id,
            'sku': 'AMZ-TEST',
            'product_id': self.product.id,
            'title': 'Amazon Test Product',
            'quantity_ordered': 1,
            'price_unit': 100.0,
        })
        order.action_create_sale_order()
        self.assertTrue(order.sale_order_id)
        self.assertEqual(order.sale_order_id.client_order_ref, '111-TEST')
