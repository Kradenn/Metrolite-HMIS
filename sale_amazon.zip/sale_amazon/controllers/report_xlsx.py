# -*- coding: utf-8 -*-
import io

from odoo import http
from odoo.http import request


class AmazonReportXlsxController(http.Controller):

    @http.route('/sale_amazon/report/xlsx', type='http', auth='user')
    def export_xlsx(self, wizard_id=None, **kwargs):
        wizard = request.env['amazon.report.wizard'].browse(int(wizard_id)).exists()
        if not wizard:
            return request.not_found()
        output = io.BytesIO()
        try:
            import xlsxwriter
        except ImportError:
            return request.make_response('xlsxwriter is required to export Excel reports.', headers=[('Content-Type', 'text/plain')])
        workbook = xlsxwriter.Workbook(output, {'in_memory': True})
        sheet = workbook.add_worksheet('Amazon Report')
        title_format = workbook.add_format({'bold': True, 'font_size': 14})
        header_format = workbook.add_format({'bold': True})
        sheet.write(0, 0, wizard._get_report_title(), title_format)
        headers = ['Reference', 'Date', 'Marketplace', 'Status', 'Fulfillment/Type', 'Amount']
        for col, header in enumerate(headers):
            sheet.write(2, col, header, header_format)
        for row, line in enumerate(wizard._get_report_lines(), start=3):
            sheet.write(row, 0, line.get('reference'))
            sheet.write(row, 1, str(line.get('date') or ''))
            sheet.write(row, 2, line.get('marketplace'))
            sheet.write(row, 3, line.get('status'))
            sheet.write(row, 4, line.get('fulfillment'))
            sheet.write(row, 5, line.get('amount'))
        workbook.close()
        output.seek(0)
        filename = 'amazon_%s_report.xlsx' % wizard.report_type
        return request.make_response(
            output.read(),
            headers=[
                ('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'),
                ('Content-Disposition', 'attachment; filename=%s' % filename),
            ],
        )
