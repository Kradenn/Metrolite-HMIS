# -*- coding: utf-8 -*-
from odoo import fields, http
from odoo.exceptions import AccessError
from odoo.http import request


class AmazonDashboardController(http.Controller):

    @http.route('/sale_amazon/dashboard/data', type='jsonrpc', auth='user')
    def dashboard_data(self, account_id=None):
        if not request.env.user.has_group('sale_amazon.group_amazon_user'):
            raise AccessError('You are not assigned to Amazon Connector.')
        env = request.env
        company = env.company
        account_domain = [('company_id', '=', company.id)]
        if account_id:
            account_domain.append(('id', '=', int(account_id)))
        accounts = env['amazon.account'].search(account_domain)
        domain = [('account_id', 'in', accounts.ids)] if accounts else [('id', '=', 0)]
        Order = env['amazon.order']
        Listing = env['amazon.listing']
        Return = env['amazon.return']
        Log = env['amazon.sync.log']
        Settlement = env['amazon.settlement']
        orders = Order.search(domain)
        kpis = {
            'total_orders': len(orders),
            'pending_orders': Order.search_count(domain + [('order_status', 'in', ('pending', 'unshipped'))]),
            'shipped_orders': Order.search_count(domain + [('order_status', '=', 'shipped')]),
            'fba_orders': Order.search_count(domain + [('fulfillment_type', '=', 'fba')]),
            'fbm_orders': Order.search_count(domain + [('fulfillment_type', '=', 'fbm')]),
            'total_revenue': sum(orders.mapped('amount_total')),
            'refund_requests': Return.search_count(domain + [('state', 'in', ('requested', 'authorized'))]),
            'active_listings': Listing.search_count(domain + [('listing_status', '=', 'active')]),
            'sync_errors': Log.search_count(domain + [('level', '=', 'error'), ('state', '=', 'open')]),
        }
        recent_orders = [{
            'id': o.id,
            'name': o.amazon_order_id,
            'buyer': o.buyer_name or o.partner_id.name or 'Amazon Buyer',
            'amount': o.amount_total,
            'status': o.order_status,
            'fulfillment': o.fulfillment_type,
        } for o in Order.search(domain, limit=8)]
        alert_listings = [l for l in Listing.search(domain, limit=80) if l.stock_qty <= 5][:8]
        inventory_alerts = [{
            'sku': l.sku,
            'name': l.product_id.display_name,
            'stock': l.stock_qty,
            'status': l.listing_status,
        } for l in alert_listings]
        listing_issues = [{
            'listing': issue.listing_id.display_name,
            'severity': issue.severity,
            'message': issue.message,
        } for issue in env['amazon.listing.issue'].search([('account_id', 'in', accounts.ids), ('state', '!=', 'resolved')], limit=8)]
        pending_shipments = [{
            'name': s.name,
            'order': s.order_id.amazon_order_id,
            'carrier': s.carrier_id.name or s.carrier_name or '-',
            'state': s.state,
        } for s in env['amazon.shipment'].search(domain + [('state', 'in', ('draft', 'ready', 'label_generated'))], limit=8)]
        refund_queue = [{
            'name': r.name,
            'order': r.order_id.amazon_order_id,
            'amount': r.refund_amount,
            'reason': r.reason,
            'state': r.state,
        } for r in Return.search(domain + [('state', 'in', ('requested', 'authorized', 'received'))], limit=8)]
        revenue_by_product = []
        for group in env['amazon.order.line'].read_group([('account_id', 'in', accounts.ids)], ['price_unit:sum', 'quantity_ordered:sum'], ['product_id'], limit=8):
            revenue_by_product.append({
                'label': group['product_id'][1] if group.get('product_id') else 'Unmapped',
                'value': group.get('price_unit', 0.0),
            })
        sales_trends = []
        groups = Order.read_group(domain, ['amount_total:sum'], ['purchase_date:day'], orderby='purchase_date:day')
        for group in groups[-14:]:
            sales_trends.append({'label': group.get('purchase_date:day') or '-', 'value': group.get('amount_total', 0.0)})
        fulfillment = [
            {'label': 'FBA', 'value': kpis['fba_orders']},
            {'label': 'FBM', 'value': kpis['fbm_orders']},
        ]
        returns_analysis = []
        for group in Return.read_group(domain, ['refund_amount:sum'], ['reason']):
            returns_analysis.append({'label': group.get('reason') or 'Other', 'value': group.get('refund_amount', 0.0)})
        settlement_payouts = [{
            'label': s.name,
            'value': s.payout_amount,
        } for s in Settlement.search(domain, limit=8)]
        listing_performance = [{
            'label': l.sku,
            'value': l.buy_box_percentage or 0.0,
        } for l in Listing.search(domain, limit=8)]
        return {
            'generated_at': fields.Datetime.now(),
            'kpis': kpis,
            'recent_orders': recent_orders,
            'inventory_alerts': inventory_alerts,
            'listing_issues': listing_issues,
            'pending_shipments': pending_shipments,
            'refund_queue': refund_queue,
            'charts': {
                'sales_trends': sales_trends,
                'fulfillment': fulfillment,
                'revenue_by_product': revenue_by_product,
                'returns_analysis': returns_analysis,
                'settlement_payouts': settlement_payouts,
                'listing_performance': listing_performance,
            },
        }
