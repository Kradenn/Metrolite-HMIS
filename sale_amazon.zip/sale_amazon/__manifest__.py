# -*- coding: utf-8 -*-
# Ultra Demark Technologies Ltd — proprietary. Licensed under OPL-1.
{
    "name": "Amazon Connector",
    "summary": "Amazon Seller Central integration for listings, orders, fulfilment, returns and settlements",
    "description": """

Amazon Connector — Amazon Seller Central integration for listings, orders, fulfilment, returns
and settlements.

Keeps a marketplace business in step with its back office. Listings and inventory are published
and refreshed, orders are imported with their fulfilment channel intact, returns and refunds are
reflected against the original sale, and settlement reports are reconciled line by line so that
marketplace fees stop being a mystery at month end.

Principal records: amazon.account, amazon.listing, amazon.order, amazon.s3.connection,
amazon.pricing.rule, amazon.settlement and 19 more. 2 guided wizards for bulk and multi-step
tasks. Ships with 7 scheduled jobs, 2 numbering sequences, 1 printable document. Access is
governed by 7 role groups, 7 record rules, 46 access-control lines. 2 web routes, all
authenticated.

Extends the standard Inventory, Sales applications across 3 existing records.
""",
    "version": "1.5",
    "category": "Sales/Sales",
    "author": "Ultra Demark Technologies Ltd",
    "maintainer": "Ultra Demark Technologies Ltd",
    "website": "https://www.ultrademark.com",
    "support": "info@ultrademark.com",
    "license": "OPL-1",
    "depends": [
        "base",
        "web",
        "mail",
        "product",
        "sale_management",
        "sale_stock",
        "stock",
        "delivery",
        "account",
        "purchase",
        "crm",
    ],
    "data": [
        "security/amazon_security.xml",
        "security/ir.model.access.csv",
        "security/amazon_rules.xml",
        "data/amazon_marketplace_data.xml",
        "data/amazon_cron.xml",
        "views/amazon_dashboard_views.xml",
        "views/amazon_listing_views.xml",
        "views/amazon_inventory_views.xml",
        "views/amazon_pricing_views.xml",
        "views/amazon_order_views.xml",
        "views/amazon_shipment_views.xml",
        "views/amazon_return_views.xml",
        "views/amazon_settlement_views.xml",
        "views/amazon_ads_views.xml",
        "views/amazon_performance_views.xml",
        "views/amazon_mapping_views.xml",
        "views/amazon_sync_views.xml",
        "views/amazon_s3_views.xml",
        "views/amazon_account_views.xml",
        "views/product_views.xml",
        "views/res_config_settings_views.xml",
        "wizards/amazon_report_wizard_views.xml",
        "reports/amazon_report_templates.xml",
        "views/amazon_menus.xml",
    ],
    "demo": ["demo/amazon_demo.xml"],
    "assets": {
        "web.assets_backend": [
            "sale_amazon/static/src/js/amazon_dashboard.js",
            "sale_amazon/static/src/xml/amazon_dashboard.xml",
            "sale_amazon/static/src/scss/amazon_dashboard.scss",
        ],
    
        'web.assets_web_dark': [
            'sale_amazon/static/src/scss/dark_mode_support.dark.scss',
        ],
    },
    "application": True,
    "installable": True,
    "auto_install": False,
}
