/** @odoo-module **/

console.log("Shopify Odoo Bridge initialized.");
