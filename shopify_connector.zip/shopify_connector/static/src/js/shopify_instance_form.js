/** @odoo-module **/

import { FormController } from "@web/views/form/form_controller";
import { formView } from "@web/views/form/form_view";
import { registry } from "@web/core/registry";
import { useService } from "@web/core/utils/hooks";

export class ShopifyInstanceFormController extends FormController {
    setup() {
        super.setup();
        this.notification = useService("notification");
        this.orm = useService("orm");
        this.actionService = useService("action");
    }

    async handleDisconnect() {
        const resId = this.model.root.resId;
        try {
            const action = await this.orm.call("shopify.instance", "action_disconnect", [resId]);
            if (action) {
                await this.actionService.doAction(action);
            }
            // Reload the record/page
            await this.actionService.doAction({
                type: "ir.actions.client",
                tag: "reload",
            });
        } catch (error) {
            // Error handled by Odoo
        }
    }

    async handleValidateStore() {
        const saved = await this.model.root.save();
        if (saved) {
            const resId = this.model.root.resId;
            this.notification.add("Registering store with bridge...", { type: "info" });
            try {
                await this.orm.call("shopify.instance", "action_validate_store", [resId]);
                this.notification.add("Store registered successfully! You can now connect to Shopify.", { type: "success" });
                await this.model.root.load();
            } catch (error) {
                // Error handled by Odoo dialog
            }
        }
    }

    /**
     * Intercept button actions defined in Python as type="object"
     */
    async executeCodeAction(action) {
        const record = this.model.root;
        
        // Map Python methods to JS handlers
        const methodHandlers = {
            'action_validate_store': this.handleValidateStore.bind(this),
            'action_authorize': this.handleAuthorize.bind(this),
            'test_connection': this.handleTestConnection.bind(this),
            'action_disconnect': this.handleDisconnect.bind(this),
            'sync_products': () => this.handleSync('sync_products', 'Products'),
            'sync_orders': () => this.handleSync('sync_orders', 'Orders'),
            'sync_customers': () => this.handleSync('sync_customers', 'Customers'),
        };

        if (methodHandlers[action.name]) {
            return methodHandlers[action.name]();
        }

        return super.executeCodeAction(...arguments);
    }

    async handleAuthorize() {
        const saved = await this.model.root.save();
        if (saved) {
            const resId = this.model.root.resId;
            const action = await this.orm.call("shopify.instance", "action_authorize", [resId]);
            if (action && action.type === "ir.actions.act_url") {
                this.actionService.doAction(action);
            }
        }
    }

    async handleTestConnection() {
        const resId = this.model.root.resId;
        this.notification.add("Verifying Shopify connection...", { type: "info", sticky: false });
        try {
            const action = await this.orm.call("shopify.instance", "test_connection", [resId]);
            if (action && action.tag === "display_notification") {
                this.notification.add(action.params.message, {
                    title: action.params.title,
                    type: action.params.type || "success",
                    sticky: false,
                });
            }
            await this.model.root.load();
        } catch (error) {
            // Odoo handles standard UserErrors with a dialog
        }
    }

    async handleSync(method, label) {
        const resId = this.model.root.resId;
        this.notification.add(`Requesting ${label} synchronization...`, { type: "info", sticky: false });
        try {
            const action = await this.orm.call("shopify.instance", method, [resId]);
            if (action && action.tag === "display_notification") {
                this.notification.add(action.params.message, {
                    title: action.params.title,
                    type: "success",
                    sticky: false,
                });
            }
        } catch (error) {
            this.notification.add(`An error occurred while syncing ${label}. Check the logs.`, { type: "danger" });
        }
    }
}

registry.category("views").add("shopify_instance_form", {
    ...formView,
    Controller: ShopifyInstanceFormController,
});
