/** @odoo-module **/

import { registry } from "@web/core/registry";
import { ShopifySyncDashboard } from "./sync_dashboard";

class ShopifySyncAction extends ShopifySyncDashboard {
    setup() {
        // Resolve instanceId from action context BEFORE calling super.setup()
        // which triggers onWillStart → loadData(). Must be a plain property, not a prop.
        const ctx = (this.props.action && this.props.action.context) || {};
        const params = (this.props.action && this.props.action.params) || {};
        this.instanceId = ctx.active_id || params.instance_id || null;
        super.setup();
    }
}

registry.category("actions").add("shopify_sync_dashboard_action", ShopifySyncAction);
