/** @odoo-module **/

import { Component, useState, onWillStart, onWillUnmount } from "@odoo/owl";
import { useService } from "@web/core/utils/hooks";
import { rpc } from "@web/core/network/rpc";
import { registry } from "@web/core/registry";
import { _t } from "@web/core/l10n/translation";

export class ShopifySyncDashboard extends Component {
    static template = "shopify_connector.ShopifySyncDashboard";
    _t = _t;

    setup() {
        this.notification = useService("notification");
        this.actionService = useService("action");
        this.orm = useService("orm");
        // instanceId is set by subclasses (e.g. ShopifySyncAction) BEFORE calling super.setup()
        // Default to null; subclasses assign this.instanceId before super.setup() is called
        if (this.instanceId === undefined) {
            this.instanceId = null;
        }
        this.state = useState({
            // UI state
            activeTab: 'orders', // 'orders', 'products', 'customers', 'logs'
            instanceId: this.instanceId || null,
            isSyncing: false,
            isLoading: false,
            
            // Stats (Summary Cards)
            stats: {
                total: 0,
                synced: 0,
                failed: 0,
                pending: 0
            },

            // Common Filters
            search: "",
            statusFilter: 'all',  // Orders tab shows All Draft Orders by default
            syncFilter: 'all',
            logTypeFilter: 'all',
            permissionError: null, // Stores ACCESS_DENIED details
            dateFrom: null,
            dateTo: null,
            limit: 20,
            showFilterModal: false,
            showImportModal: false,

            // Entity Data
            products: [],
            customers: [],
            orders: [],
            inventory: [],
            logs: [],
            settings: {
                warehouse_id: null,
                location_id: null,
                product_category_id: null,
                auto_sync_stock: true,
                master_inventory: 'shopify',
                import_images: true,
                csv_import_enabled: false,
                auto_create_invoice: true,
            },
            automations: {},

            // Pagination
            pageInfo: {
                hasNextPage: false,
                endCursor: null,
                hasPreviousPage: false,
                startCursor: null
            },
            currentCursorStack: [], // stack of previous cursors for back-navigation
            
            // Selection
            selectedIds: [],
            syncProgress: 0,
            totalToSync: 0,

            selectedLog: null,
            showLogModal: false,

            activeSettingTab: 'automation', // 'general', 'inventory', 'automation', 'mapping', 'notifications'
            activeAutomationTab: 'products', // 'products', 'customers', 'orders', 'advanced'
            
            // Available Instances
            instances: [],

            // CSV Import state
            csvPreviewHeaders: [],
            csvPreviewRows: [],
            csvFileContent: null,
            csvFileName: "",
        });

        onWillStart(async () => {
            // Fetch all connected instances
            const instances = await this.orm.searchRead(
                "shopify.instance",
                [["state", "=", "connected"]],
                ["id", "name"]
            );
            this.state.instances = instances;

            if (!this.state.instanceId && instances.length) {
                this.state.instanceId = instances[0].id;
            }
            await this.loadSettings();
            await this.loadData();
        });

        this.searchTimeout = null;
    }

    async loadData(cursor = null, direction = 'next') {
        if (!this.state.instanceId) return;
        
        let endpoint = "";
        let params = {
            instance_id: this.state.instanceId,
            cursor: cursor,
            limit: this.state.limit,
            search: this.state.search,
            status: this.state.statusFilter !== 'all' ? this.state.statusFilter : null,
            sync_status: this.state.syncFilter !== 'all' ? this.state.syncFilter : null,
            from_date: this.state.dateFrom || null,
            to_date: this.state.dateTo || null,
            direction: direction
        };

        switch(this.state.activeTab) {
            case 'products':
                endpoint = "/shopify/get/products";
                break;
            case 'customers':
                endpoint = "/shopify/get/customers";
                break;
            case 'orders':
                endpoint = "/shopify/get/orders";
                break;
            case 'inventory':
                endpoint = "/shopify/get/inventory";
                break;    
            case 'logs':
                await this.loadSyncLogs();
                return;
            case 'settings':
                await this.loadSettings();
                return;
        }

        this.state.isLoading = true;
        try {
            const result = await rpc(endpoint, params);
            this.state.permissionError = null;
            if (result && result.status === 'success') {
                // Use the tab-specific key from the response
                const tab = this.state.activeTab;
                this.state[tab] = result[tab] || [];
                this.state.pageInfo = result.pageInfo || {
                    hasNextPage: false,
                    endCursor: null,
                    hasPreviousPage: false,
                    startCursor: null
                };
                this.state.stats.totalShopify = result.totalCount || 0;
                this.updateSummaryStats();
            } else if (result && result.status === 'error') {
                console.error("Shopify API Error:", result.message);
                // Reset data and stats for this tab so stale counts don't show
                const tab = this.state.activeTab;
                this.state[tab] = [];
                this.state.stats = { total: 0, synced: 0, failed: 0, pending: 0 };
                this.state.pageInfo = { hasNextPage: false, endCursor: null, hasPreviousPage: false, startCursor: null };

                if (result.message && result.message.includes("ACCESS_DENIED")) {
                    let title;
                    let message;

                    if (tab === 'customers') {
                        title = _t("Protected Customer Data Access Required");
                        message = _t("This app does not have permission to access Customer data on Shopify. Please enable the 'read_customers' scope in your Shopify app settings to sync customers.");
                    } else if (tab === 'orders' && this.state.statusFilter === 'draft') {
                        title = _t("Protected Draft Orders Data Access Required");
                        message = _t("This app does not have permission to fetch Draft Orders on Shopify. Please enable the 'read_draft_orders' scope in your Shopify app settings.");
                    } else {
                        title = _t("Protected Draft Orders Data Access Required");
                        message = _t("This app does not have permission to fetch Draft Orders on Shopify. Please enable the 'read_draft_orders' scope in your Shopify app settings.")
                    }

                    this.state.permissionError = {
                        type: 'permission',
                        tab: tab,
                        title: title,
                        message: message,
                        link: "https://shopify.dev/docs/apps/launch/protected-customer-data"
                    };
                } else {
                    this.notification.add(result.message || _t("Error loading data"), { type: "danger" });
                }
            }
        } catch (error) {
            console.error(_t("Error loading sync data:"), error);
        } finally {
            this.state.isLoading = false;
        }
    }

    updateSummaryStats() {
        const data = this.state[this.state.activeTab];
        if (!data || data.length === 0) {
            this.state.stats = { total: 0, synced: 0, failed: 0, pending: 0 };
            return;
        }
        
        this.state.stats.total = data.length;
        this.state.stats.synced = data.filter(i => i.is_synced).length;
        this.state.stats.pending = this.state.stats.total - this.state.stats.synced;
    }

    // --- Actions ---
    async changeTab(tab) {
        this.state.activeTab = tab;
        this.state.search = "";
        this.state.statusFilter = 'all';  // Orders tab defaults to All Draft Orders
        this.state.syncFilter = 'all';
        this.state.dateFrom = null;
        this.state.dateTo = null;
        this.state.selectedIds = [];
        this.state.syncProgress = 0;
        this.resetCsvImport();
        await this.loadData();
    }
    changeSettingTab(tab) {
        this.state.activeSettingTab = tab;
    }

    changeAutomationTab(tab) {
        this.state.activeAutomationTab = tab;
    }

    // --- Filter Helpers ---
    get activeFilterCount() {
        let count = 0;
        if (this.state.statusFilter !== 'all') count++;
        if (this.state.syncFilter !== 'all') count++;
        if (this.state.dateFrom) count++;
        if (this.state.dateTo) count++;
        return count;
    }

    onSearch(ev) {
        this.state.search = ev.target.value;
        this.debounceLoad();
    }

    onFilterChange(filterType, value) {
        this.state[filterType] = value;
        this.loadData();
    }

    debounceLoad() {
        clearTimeout(this.searchTimeout);
        this.searchTimeout = setTimeout(() => this.loadData(), 500);
    }

    // --- Sync Actions ---
    async syncSelected() {
        if (this.state.selectedIds.length === 0) return;
        
        this.state.isSyncing = true;
        this.state.totalToSync = this.state.selectedIds.length;
        this.state.syncProgress = 0;

        let entityType = this.state.activeTab.slice(0, -1);
        if (this.state.activeTab === 'orders') {
            entityType = 'draft_order';
        }else if (this.state.activeTab === 'inventory') {
            entityType = 'inventory';
        }
        let syncedCount = 0;

        try {
            // Send ALL selected IDs in one request for better performance
            const result = await rpc("/shopify/sync/selected", {
                instance_id: this.state.instanceId,
                shopify_ids: this.state.selectedIds,
                entity_type: entityType
            });
            
            if (result.status === 'success') {
                syncedCount = result.synced_count || this.state.selectedIds.length;
                this.state.syncProgress = 100;
                let msg = "";
                if (this.state.activeTab === 'orders') {
                    msg = _t("%s orders synced successfully.").replace("%s", syncedCount);
                } else if (this.state.activeTab === 'customers') {
                    msg = _t("%s customers synced successfully.").replace("%s", syncedCount);
                } else if (this.state.activeTab === 'products') {
                    msg = _t("%s products synced successfully.").replace("%s", syncedCount);
                } else if (this.state.activeTab === 'inventory') {
                    msg = _t("%s inventory stock records synced successfully.").replace("%s", syncedCount);
                } else {
                    msg = _t("%s items synced successfully.").replace("%s", syncedCount);
                }
                this.notification.add(msg, { type: "success" });
            } else {
                this.notification.add(result.message || _t("Sync failed."), { type: "danger" });
            }
            
            this.state.selectedIds = [];
            await this.loadData();
        } catch (error) {
            this.notification.add(_t("Sync process interrupted."), { type: "danger" });
        } finally {
            setTimeout(() => {
                this.state.isSyncing = false;
                this.state.syncProgress = 0;
            }, 1000);
        }
    }

    async syncOne(id) {
        this.state.selectedIds = [id];
        await this.syncSelected();
    }

    // --- Selection ---
    toggleSelection(id) {
        if (this.state.isSyncing) return;
        const index = this.state.selectedIds.indexOf(id);
        if (index > -1) this.state.selectedIds.splice(index, 1);
        else this.state.selectedIds.push(id);
    }

    toggleAll(ev) {
        const data = this.state[this.state.activeTab];
        if (ev.target.checked) this.state.selectedIds = data.map(i => i.id);
        else this.state.selectedIds = [];
    }

    // --- Settings ---
    async loadSettings() {
        if (!this.state.instanceId) return;
        const result = await this.orm.read(
            "shopify.instance",
            [this.state.instanceId],
            ["name", "shop_url", "api_version", "warehouse_id", "location_id", "product_category_id", "auto_sync_stock", "master_inventory", "import_images", "csv_import_enabled", "auto_create_invoice"]
        );
        if (result.length) {
            this.state.settings = result[0];
            // Clear stats for settings tab
            this.state.stats = { total: 0, synced: 0, failed: 0, pending: 0 };
        }
        // Load Automations
        const automations = await this.orm.searchRead(
            "shopify.automation",
            [["instance_id", "=", this.state.instanceId], ["active", "in", [true, false]]],
            ["id", "entity_type", "interval_number", "interval_type", "active", "sync_filter"]
        );
        const autoObj = {
            product: { active: false, interval_number: 1, interval_type: 'hours', sync_filter: 'all' },
            order: { active: false, interval_number: 1, interval_type: 'hours', sync_filter: 'all' },
            customer: { active: false, interval_number: 1, interval_type: 'hours', sync_filter: 'all' },
            inventory: { active: false, interval_number: 1, interval_type: 'hours', sync_filter: 'all' }
        };
        automations.forEach(a => {
            autoObj[a.entity_type] = a;
        });
        this.state.automations = autoObj;
    }

    async saveSettings() {
        if (!this.state.instanceId) return;
        try {
            await this.orm.write("shopify.instance", [this.state.instanceId], {
                name: this.state.settings.name,
                api_version: this.state.settings.api_version,
                warehouse_id: this.state.settings.warehouse_id ? this.state.settings.warehouse_id[0] : false,
                location_id: this.state.settings.location_id ? this.state.settings.location_id[0] : false,
                product_category_id: this.state.settings.product_category_id ? this.state.settings.product_category_id[0] : false,
                auto_sync_stock: this.state.settings.auto_sync_stock,
                master_inventory: this.state.settings.master_inventory,
                import_images: this.state.settings.import_images,
                csv_import_enabled: this.state.settings.csv_import_enabled,
                auto_create_invoice: this.state.settings.auto_create_invoice,
            });
            // Save Automations
            for (const type in this.state.automations) {
                const auto = this.state.automations[type];
                if (auto.id) {
                    await this.orm.write("shopify.automation", [auto.id], {
                        interval_number: parseInt(auto.interval_number) || 1,
                        interval_type: auto.interval_type,
                        active: auto.active,
                        sync_filter: auto.sync_filter || 'all'
                    });
                } else {
                    await this.orm.create("shopify.automation", [{
                        instance_id: this.state.instanceId,
                        entity_type: type,
                        interval_number: parseInt(auto.interval_number) || 1,
                        interval_type: auto.interval_type,
                        active: auto.active,
                        sync_filter: auto.sync_filter || 'all'
                    }]);
                }
            }
            this.notification.add(_t("Settings saved successfully."), { type: "success" });
            await this.loadSettings();
        } catch (error) {
            this.notification.add(_t("Failed to save settings: %s", (error.message || error.data?.message || "Unknown error")), { type: "danger" });
            console.error(error);
        }
    }
    async runAllSync() {
        if (!this.state.instanceId) return;
        this.state.isSyncing = true;
        try {
            await this.orm.call("shopify.instance", "action_run_all_automations", [this.state.instanceId]);
            this.notification.add(_t("Manual sync triggered for all automated entities."), { type: "success" });
        } catch (error) {
            this.notification.add(_t("Failed to run automations: %s", (error.message || "Unknown error")), { type: "danger" });
        } finally {
            this.state.isSyncing = false;
        }
    }
    async disconnectInstance() {
        if (!this.state.instanceId) return;
        if (!confirm(_t("Are you sure you want to disconnect this instance? This will clear all connection tokens."))) return;
        try {
            await this.orm.call("shopify.instance", "action_disconnect", [this.state.instanceId]);
            this.notification.add(_t("Instance disconnected successfully."), { type: "warning" });
            window.location.reload(); // Reload to update entire state
        } catch (error) {
            this.notification.add(_t("Failed to disconnect instance."), { type: "danger" });
        }
    }

    // --- Logs ---
    async loadSyncLogs() {
        const result = await rpc("/shopify/sync/logs", {
            instance_id: this.state.instanceId,
            limit: this.state.limit,
            search: this.state.search,
            status: this.state.statusFilter !== 'all' ? this.state.statusFilter : null,
            sync_type: this.state.logTypeFilter !== 'all' ? this.state.logTypeFilter : null,
            from_date: this.state.dateFrom || null,
            to_date: this.state.dateTo || null
        });
        this.state.logs = result || [];
    }
    openLogDetail(log) {
        this.state.selectedLog = log;
        this.state.showLogModal = true;
    }

    closeLogModal() {
        this.state.selectedLog = null;
        this.state.showLogModal = false;
    }

    // --- Instance Selection ---
    async onInstanceChange(ev) {
        this.state.instanceId = parseInt(ev.target.value, 10);
        this.state.selectedIds = [];
        this.state.pageInfo = {
            hasNextPage: false, endCursor: null,
            hasPreviousPage: false, startCursor: null
        };
        await this.loadData();
    }

    // --- Per Page ---
    onLimitChange(ev) {
        this.state.limit = parseInt(ev.target.value, 10);
        this.state.pageInfo = {
            hasNextPage: false, endCursor: null,
            hasPreviousPage: false, startCursor: null
        };
        this.loadData(null);
    }

    // --- Pagination ---
    nextPage() {
        if (this.state.pageInfo.hasNextPage) {
            this.loadData(this.state.pageInfo.endCursor, 'next');
        }
    }

    prevPage() {
        if (this.state.pageInfo.hasPreviousPage) {
            this.loadData(this.state.pageInfo.startCursor, 'prev');
        }
    }

    // --- Advanced Filters JS Modal ---
    toggleFilterModal() {
        this.state.showFilterModal = !this.state.showFilterModal;
    }

    async applyFilters() {
        this.toggleFilterModal();
        await this.loadData();
    }

    async resetFilters() {
        this.state.statusFilter = 'all';
        this.state.syncFilter = 'all';
        this.state.dateFrom = null;
        this.state.dateTo = null;
        this.toggleFilterModal();
        await this.loadData();
    }

    async openFilterWizard() {
        this.toggleFilterModal();
    }

    async openImportCsvWizard() {
        this.state.showImportModal = true;
    }

    toggleImportModal() {
        this.state.showImportModal = !this.state.showImportModal;
    }

    async downloadCsvSample() {
        let headers = "";
        let row = "";
        const filename = `shopify_${this.state.activeTab}_sample.csv`;

        if (this.state.activeTab === 'products') {
            headers = "Handle,Title,Body (HTML),Vendor,Type,Tags,Option1 Name,Option1 Value,Variant Price";
            row = "t-shirt,T-Shirt,Cool shirt,Vendor X,Clothing,cotton,Size,Large,19.99";
        } else if (this.state.activeTab === 'customers') {
            headers = "First Name,Last Name,Email,Phone,Accepts Marketing,Address1,City,Province,Country,Zip";
            row = "John,Doe,john@example.com,+1234567890,yes,123 Main St,Seattle,WA,United States,98101";
        } else if (this.state.activeTab === 'orders') {
            headers = "Order ID,Email,Total,Currency,Financial Status,Fulfillment Status,Lineitem Name,Lineitem Quantity";
            row = "#1001,customer@example.com,100.00,USD,paid,unfulfilled,Product X,1";
        } else {
            this.notification.add(_t("Sample not available for this tab."), { type: "warning" });
            return;
        }

        const csvContent = "data:text/csv;charset=utf-8," + headers + "\n" + row;
        const encodedUri = encodeURI(csvContent);
        const link = document.createElement("a");
        link.setAttribute("href", encodedUri);
        link.setAttribute("download", filename);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }

    resetCsvImport() {
        this.state.csvPreviewHeaders = [];
        this.state.csvPreviewRows = [];
        this.state.csvFileContent = null;
        this.state.csvFileName = "";
        const fileInput = document.getElementById('csvFileUpdate');
        if (fileInput) fileInput.value = "";
    }

    async handleCsvImport(ev) {
        const file = ev.target.files[0];
        if (!file) return;

        this.state.csvFileName = file.name;
        const reader = new FileReader();
        reader.onload = (e) => {
            const content = e.target.result;
            const lines = content.split(/\r?\n/).filter(line => line.trim() !== "");
            if (lines.length > 0) {
                this.state.csvPreviewHeaders = lines[0].split(',').map(h => h.trim());
                this.state.csvPreviewRows = lines.slice(1, 6).map(line => line.split(',').map(c => c.trim())); // Preview first 5 rows
                this.state.csvFileContent = content; // Store full content for final sync
            }
        };
        reader.readAsText(file);
    }

    async startCsvSync() {
        if (!this.state.csvFileContent) return;

        this.state.isSyncing = true;
        try {
            // In a real implementation, you'd call an RPC route here
            // const result = await rpc("/shopify/import/csv_data", {
            //     instance_id: this.state.instanceId,
            //     entity_type: this.state.activeTab.slice(0, -1),
            //     content: this.state.csvFileContent
            // });
            
            // Simulating success
            let msg = "";
            if (this.state.activeTab === 'orders') {
                msg = _t("Successfully processed CSV for orders.");
            } else if (this.state.activeTab === 'customers') {
                msg = _t("Successfully processed CSV for customers.");
            } else if (this.state.activeTab === 'products') {
                msg = _t("Successfully processed CSV for products.");
            } else {
                msg = _t("Successfully processed CSV for items.");
            }
            this.notification.add(msg, { type: "success" });
            this.state.showImportModal = false;
            this.resetCsvImport();
            await this.loadData();
        } catch (error) {
            this.notification.add(_t("Failed to process CSV file."), { type: "danger" });
        } finally {
            this.state.isSyncing = false;
        }
    }

    getBadgeClass(state) {
        switch (state) {
            case 'success': case 'active': case 'PAID': case 'FULFILLED': return 'success';
            case 'error': case 'FAILED': return 'danger';
            case 'warning': case 'draft': case 'PENDING': return 'warning';
            default: return 'info';
        }
    }
}
