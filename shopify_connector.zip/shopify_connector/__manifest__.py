# -*- coding: utf-8 -*-
# Ultra Demark Technologies Ltd — proprietary. Licensed under OPL-1.
{
    "name": "Shopify Connector",
    "summary": "Two-way synchronisation of products, customers, orders, inventory and fulfilment with Shopify",
    "description": """

Shopify Connector — Two-way synchronisation of products, customers, orders, inventory and
fulfilment with Shopify.

Connects an online storefront to the operational system behind it. Catalogue and stock levels
flow outward, orders and customers flow inward, and fulfilment status flows back to the shopper.
Synchronisation runs on a schedule with a log of every exchange, so a missing order can be
traced instead of guessed at.

Principal records: shopify.instance, shopify.sync.log, shopify.automation. 1 guided wizard for
bulk and multi-step tasks. Ships with 1 scheduled job. Access is governed by 3 access-control
lines. 10 web routes, 2 of them public-facing.

Extends the standard Inventory, Sales applications across 4 existing records.
""",
    "version": "1.5",
    "category": "Sales",
    "author": "Ultra Demark Technologies Ltd",
    "maintainer": "Ultra Demark Technologies Ltd",
    "website": "https://www.ultrademark.com",
    "support": "info@ultrademark.com",
    "license": "OPL-1",
    "depends": ["base", "sale_management", "stock", "account", "delivery", "product"],
    "data": [
        "security/ir.model.access.csv",
        "views/res_config_settings_views.xml",
        "views/shopify_sync_log_views.xml",
        "views/shopify_instance_views.xml",
        "views/shopify_automation_views.xml",
        "views/product_views.xml",
        "views/sale_order_views.xml",
        "views/res_partner_views.xml",
        "views/menu.xml",
        "data/cron.xml",
        "data/shopify_demo.xml",
    ],
    "assets": {
        "web.assets_backend": [
            "shopify_connector/static/src/css/style.css",
            "shopify_connector/static/src/scss/sync_dashboard.scss",
            "shopify_connector/static/src/js/main.js",
            "shopify_connector/static/src/js/shopify_instance_form.js",
            "shopify_connector/static/src/js/sync_dashboard.js",
            "shopify_connector/static/src/js/sync_action.js",
            "shopify_connector/static/src/xml/sync_dashboard.xml",
        ],
    },
    "images": ["static/description/banner.png", "static/description/icon.png"],
    "application": True,
    "installable": True,
    "auto_install": False,
    "live_test_url": "https://quickdevlabs.sumws.com/shopify-connector-demo",
}
