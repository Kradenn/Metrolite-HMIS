from odoo import models, fields

class ProductProduct(models.Model):
    _inherit = "product.product"

    shopify_variant_id = fields.Char(string="Shopify Variant ID", help="ID of this variant in Shopify")
    shopify_instance_id = fields.Many2one('shopify.instance', string="Shopify Instance")
    is_synced_to_shopify = fields.Boolean(string="Synced to Shopify", default=False)
