from odoo import models, fields, api, _
import logging

_logger = logging.getLogger(__name__)

class StockPicking(models.Model):
    _inherit = 'stock.picking'

    def button_validate(self):
        """ Override button_validate to push tracking info to Shopify """
        res = super(StockPicking, self).button_validate()
        
        # If picking is validated successfully (res is True or None depending on return)
        if res is True or res is None:
            for picking in self:
                if picking.state == 'done' and picking.sale_id and picking.sale_id.shopify_instance_id:
                    # Trigger push to Shopify
                    try:
                        picking.sale_id.shopify_instance_id.push_fulfillment_to_shopify(picking)
                    except Exception as e:
                        _logger.error("Failed to push fulfillment for %s: %s", picking.name, str(e))
        
        return res
