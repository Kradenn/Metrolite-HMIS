from odoo import models, fields, api, _
from odoo.exceptions import ValidationError
import logging

_logger = logging.getLogger(__name__)

class ShopifyAutomation(models.Model):
    _name = 'shopify.automation'
    _description = 'Shopify Automation Settings'    

    name = fields.Char(string="Name", compute="_compute_name", store=True)
    instance_id = fields.Many2one('shopify.instance', string="Shopify Instance", required=True, ondelete='cascade')
    entity_type = fields.Selection([
        ('product', 'Products'),
        ('order', 'Orders'),
        ('customer', 'Customers'),
        ('inventory', 'Inventory/Stock')
    ], string="Entity Type", required=True)
    
    interval_number = fields.Integer(string="Interval Number", default=1, required=True)
    interval_type = fields.Selection([
        ('minutes', 'Minutes'),
        ('hours', 'Hours'),
        ('days', 'Days'),
        ('weeks', 'Weeks'),
        ('months', 'Months')
    ], string="Interval Type", default='minutes', required=True)    
    active = fields.Boolean(string="Active", default=True)
    sync_filter = fields.Selection([
        ('all', 'All Records'),
        ('unsynced', 'Only Unsynced'),
        ('synced', 'Only Synced'),
        ('custom', 'Custom Filter')
    ], string="Sync Filter", default='all')
    last_sync = fields.Datetime()


    @api.depends('instance_id', 'entity_type')
    def _compute_name(self):
        entity_labels = dict(self._fields['entity_type'].selection)
        for record in self:
            instance_name = record.instance_id.display_name or _('Shopify Instance')
            entity_name = entity_labels.get(record.entity_type, _('Sync'))
            record.name = f"{instance_name} - {entity_name}"

    @api.constrains('instance_id', 'entity_type')
    def _check_unique_sync(self):
        for record in self:
            if not record.instance_id or not record.entity_type:
                continue
            duplicate = self.search_count([
                ('id', '!=', record.id),
                ('instance_id', '=', record.instance_id.id),
                ('entity_type', '=', record.entity_type),
            ])
            if duplicate:
                raise ValidationError(_('Each sync type must be unique per Shopify instance.'))

    @api.constrains('interval_number')
    def _check_interval_number(self):
        for record in self:
            if record.interval_number < 1:
                raise ValidationError(_('Interval Number must be at least 1.'))

    def action_run_now(self):
        """ Manually trigger the automation for this entity type """
        self.ensure_one()
        instance = self.instance_id
        if self.entity_type == 'product':
            instance.automation_sync_products(config=self)
        elif self.entity_type == 'order':
            instance.automation_sync_orders(config=self)
        elif self.entity_type == 'customer':
            instance.automation_sync_customers(config=self)
        elif self.entity_type == 'inventory':
            instance.automation_sync_inventory(config=self)
            
        self.last_sync = fields.Datetime.now()   

    def _update_cron(self):
        """ Ensure automations are only active if the instance is connected """
        for record in self:
            if record.instance_id.state != 'connected' and record.active:
                record.active = False
                _logger.info("Deactivating automation %s for instance %s (State: %s)", 
                             record.entity_type, record.instance_id.name, record.instance_id.state)

    