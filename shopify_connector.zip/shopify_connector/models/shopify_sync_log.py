from odoo import models, fields, api

class ShopifySyncLog(models.Model):
    _name = 'shopify.sync.log'
    _description = 'Shopify Sync Log'
    _order = 'create_date desc'

    name = fields.Char(string="Sync Operation", required=True)
    instance_id = fields.Many2one('shopify.instance', string="Shopify Instance", ondelete='cascade')
    sync_type = fields.Selection([
        ('product', 'Product'),
        ('variant', 'Variant'),
        ('customer', 'Customer'),
        ('order', 'Order'),
        ('inventory', 'Inventory'),
        ('image', 'Image'),
        ('other', 'Other')
    ], string="Sync Type", default='product')
    
    state = fields.Selection([
        ('info', 'Info'),
        ('success', 'Success'),
        ('warning', 'Warning'),
        ('error', 'Error')
    ], string="Status", default='info')
    
    message = fields.Text(string="Details")
    payload = fields.Text(string="Received Payload", help="Raw data received from Shopify")
    shopify_id = fields.Char(string="Shopify ID")
    res_model = fields.Char(string="the platform Model")
    res_id = fields.Integer(string="the platform ID")

    @api.model
    def log(self, instance_id, name, sync_type, state, message, shopify_id=None, res_model=None, res_id=None, payload=None):
        import json
        payload_str = json.dumps(payload, indent=2) if payload else False
        return self.create({
            'instance_id': instance_id,
            'name': name,
            'sync_type': sync_type,
            'state': state,
            'message': message,
            'shopify_id': shopify_id,
            'res_model': res_model,
            'res_id': res_id,
            'payload': payload_str
        })
