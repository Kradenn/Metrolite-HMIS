from odoo import models, fields

class ResPartner(models.Model):
    _inherit = 'res.partner'

    shopify_customer_id = fields.Char(string="Shopify Customer ID", help="ID of this customer in Shopify")
    shopify_instance_id = fields.Many2one('shopify.instance', string="Shopify Instance")
    is_shopify_customer = fields.Boolean(string="Is Shopify Customer", default=False)
