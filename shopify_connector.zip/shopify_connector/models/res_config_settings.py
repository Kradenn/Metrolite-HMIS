from odoo import models, fields, api, _
from odoo.exceptions import ValidationError

class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    # shopify_client_id = fields.Char(string="Shopify Client ID", config_parameter='shopify_connector.shopify_client_id')
    # shopify_client_secret = fields.Char(string="Shopify Client Secret", config_parameter='shopify_connector.shopify_client_secret')
    # shopify_redirect_url = fields.Char(string="Shopify Redirect URL", config_parameter='shopify_connector.shopify_redirect_url')
    # shopify_scopes = fields.Char(string="Shopify Scopes", config_parameter='shopify_connector.shopify_scopes', default="read_products,write_products,read_orders,write_orders,read_customers,write_customers,read_locations,read_inventory,write_inventory")
    shopify_third_party_url = fields.Char(
        string="Shopify Bridge URL", 
        config_parameter='shopify_connector.shopify_third_party_url', 
        default="https://app.sumws.com/odosh",        
    )


    @api.constrains('shopify_third_party_url')
    def _check_shopify_third_party_url(self):
        for record in self:
            url = (record.shopify_third_party_url or '').strip()
            if url and not (url.startswith('http://') or url.startswith('https://')):
                raise ValidationError(_('Shopify Bridge URL must start with http:// or https://.'))
