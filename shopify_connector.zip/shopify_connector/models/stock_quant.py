from odoo import models, api, fields
import logging

_logger = logging.getLogger(__name__)

class StockQuant(models.Model):
    _inherit = 'stock.quant'

    @api.model_create_multi
    def create(self, vals_list):
        quants = super(StockQuant, self).create(vals_list)
        for quant in quants:
            quant._sync_stock_to_shopify()
        return quants

    def write(self, vals):
        res = super(StockQuant, self).write(vals)
        if 'quantity' in vals or 'inventory_quantity' in vals:
            for quant in self:
                quant._sync_stock_to_shopify()
        return res

    def _sync_stock_to_shopify(self):
        for quant in self:
            product = quant.product_id
            if product and product.shopify_variant_id:
                instance = product.shopify_instance_id
                if instance and instance.state == 'connected' and instance.auto_sync_stock and instance.master_inventory == 'odoo':
                    # Ensure the quant location matches the instance's location or warehouse fallback
                    target_location = instance.location_id
                    if not target_location and instance.warehouse_id:
                        target_location = instance.warehouse_id.lot_stock_id
                    
                    # If target_location is configured, only sync if this quant is in that location
                    if target_location and quant.location_id.id != target_location.id:
                        continue
                        
                    try:
                        # Fetch the platform on-hand qty for this product at this location
                        qty = product.with_context(location=quant.location_id.id).qty_available
                        instance._update_shopify_inventory(product, qty)
                    except Exception as e:
                        _logger.error(f"Failed to auto-sync the platform stock change to Shopify for {product.name}: {str(e)}")
