from odoo import models, fields

class ProductTemplate(models.Model):
    _inherit = 'product.template'

    shopify_product_id = fields.Char(string="Shopify Product ID", help="ID of this product in Shopify")
    shopify_instance_id = fields.Many2one('shopify.instance', string="Shopify Instance")
    is_synced_to_shopify = fields.Boolean(string="Synced to Shopify", default=False)
