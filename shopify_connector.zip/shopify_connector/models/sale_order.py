from odoo import models, fields

class SaleOrder(models.Model):
    _inherit = 'sale.order'

    shopify_order_id = fields.Char(string="Shopify Order ID", help="ID of this order in Shopify")
    shopify_draft_order_id = fields.Char(string="Shopify Draft Order ID", help="ID of the draft order in Shopify if this order was created from one")
    shopify_instance_id = fields.Many2one('shopify.instance', string="Shopify Instance")
    is_shopify_order = fields.Boolean(string="Is Shopify Order", default=False)
