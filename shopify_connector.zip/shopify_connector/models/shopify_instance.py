from odoo import models, fields, api, _
from odoo.exceptions import UserError, ValidationError
from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta
import requests
import json
import logging
import base64
from datetime import datetime

_logger = logging.getLogger(__name__)

class ShopifyInstance(models.Model):
    _name = 'shopify.instance'
    _description = 'Shopify Instance configured for Bridge'

    name = fields.Char(string="Instance Name", required=True, help="E.g., My Shopify Store")
    shop_url = fields.Char(string="Shop URL", required=True, help="E.g., https://my-store.myshopify.com")
    
    # OAuth Credentials
    shopify_client_id = fields.Char(string="Client ID")
    shopify_client_secret = fields.Char(string="Client Secret")
    shopify_access_token = fields.Char(string="Access Token")
    shopify_scopes = fields.Char(string="Scopes", default="read_products,write_products,read_orders,write_orders,read_customers,write_customers,read_inventory,write_inventory,read_locations")
    shopify_redirect_uri = fields.Char(
        string="Redirect URI", 
        help="Whitelisted URI in Shopify App settings. If empty, the platform base URL will be used.",
        default="https://app.sumws.com/odosh/install.php",
        readonly=True,
    )
    shopify_third_party_uri = fields.Char(
        string="Third Party URL",
        help="URL of the third-party bridge API used to securely fetch and synchronize Shopify access tokens with the platform.",
        default="https://app.sumws.com/odosh",
        readonly=True      
    )
    
    # Shop Details
    shopify_shop_id = fields.Char(string="Shopify Shop ID", readonly=True)
    shopify_shop_name = fields.Char(string="Shopify Shop Name", readonly=True)
    shopify_shop_email = fields.Char(string="Shopify Shop Email", readonly=True)
    
    # Legacy / Alternative API credentials
    api_key = fields.Char(string="API Key", help="Used for Private apps or as Username")
    api_secret = fields.Char(string="API Secret/Password", help="Used for Private apps or Password")
    
    api_version = fields.Selection([
        ('2023-01', '2023-01'),
        ('2023-04', '2023-04'),
        ('2023-07', '2023-07'),
        ('2023-10', '2023-10'),
        ('2024-01', '2024-01'),
        ('2024-04', '2024-04'),
        ('2024-07', '2024-07'),
        ('2024-10', '2024-10'),
        ('2025-01', '2025-01'),
        ('2025-04', '2025-04'),
        ('2025-07', '2025-07'),
        ('2025-10', '2025-10'),
        ('2026-01', '2026-01'),
        ('2026-04', '2026-04'),
    ], string="API Version", default='2026-01', required=True)
    
    state = fields.Selection([
        ('draft', 'Draft'),
        ('validated', 'Validated'),
        ('connected', 'Connected'),
        ('disconnected', 'Disconnected'),
        ('error', 'Error')
    ], string="Status", default='draft')
    
    company_id = fields.Many2one('res.company', string="Company", default=lambda self: self.env.company)
    shopify_auth_code = fields.Char(string="Auth Code (Manual)", help="If automatic redirect fails, paste the 'code' parameter from the URL here.")
    shopify_access_token_manual = fields.Char(string="Manual Access Token", help="Paste your shpat_ or shpua_ token here directly.")

    # the platform Configuration (the platform compatible)
    warehouse_id = fields.Many2one('stock.warehouse', string="Default Warehouse", help="Warehouse for Shopify orders and stock sync.")
    location_id = fields.Many2one('stock.location', string="Stock Location", help="Specific location within the warehouse to sync stock from.")
    product_category_id = fields.Many2one('product.category', string="Default Category", help="Category assigned to new Shopify products.")
    
    auto_sync_stock = fields.Boolean(string="Auto-Sync Stock Levels", default=True, help="If checked, the platform stock changes will automatically sync to Shopify.")
    master_inventory = fields.Selection([
        ('shopify', 'Shopify'),
        ('odoo', 'the platform')
    ], string="Master Inventory", default="shopify", help="Determines stock sync direction. If Shopify, stock is synced from Shopify to the platform. If the platform, stock is synced from the platform to Shopify.")
    import_images = fields.Boolean(string="Import Product Images", default=True)
    notify_on_error = fields.Boolean(string="Notify on Errors", default=True)
    csv_import_enabled = fields.Boolean(string="CSV Import Support", default=False)
    auto_create_invoice = fields.Boolean(string="Auto-Create Invoice", default=True, help="Automatically create and validate an invoice in the platform when a paid order is synced from Shopify.")
    pricelist_id = fields.Many2one('product.pricelist', string="Pricelist", help="If set, product variant prices from Shopify will be synced to this the platform pricelist.")
    
    automation_ids = fields.One2many('shopify.automation', 'instance_id', string="Automations")


    @api.constrains('shop_url', 'company_id')
    def _check_unique_shop_url_per_company(self):
        for record in self:
            if not record.shop_url:
                continue
            normalized_url = record.shop_url.replace('https://', '').replace('http://', '').strip('/').lower()
            duplicates = self.search([
                ('id', '!=', record.id),
                ('company_id', '=', record.company_id.id if record.company_id else False),
                ('shop_url', '!=', False),
            ])
            for duplicate in duplicates:
                duplicate_url = duplicate.shop_url.replace('https://', '').replace('http://', '').strip('/').lower()
                if duplicate_url == normalized_url:
                    raise ValidationError(_('Shop URL must be unique per company.'))

    @api.constrains('shop_url')
    def _check_shop_url_format(self):
        for record in self:
            if record.shop_url and ' ' in record.shop_url.strip():
                raise ValidationError(_('Shop URL must not contain spaces.'))

    def sync_inventory(self):
        """ Sync inventory levels from the platform to Shopify (Export) or vice versa (Import) """
        self.ensure_one()
        # For now, we reuse the existing products sync logic which also updates inventory
        return self.sync_products_graphql()

    def write(self, vals):
        res = super().write(vals)
        if 'state' in vals:
            for record in self:
                if hasattr(record, 'automation_ids'):
                    record.automation_ids._update_cron()
        return res


    @api.onchange('warehouse_id')
    def _onchange_warehouse_id(self):
        if self.warehouse_id:
            self.location_id = self.warehouse_id.lot_stock_id
        else:
            self.location_id = False

    def run_all_sync(self):
        """ Cron method to run all active automations for ALL instances based on timing """
        configs = self.env['shopify.automation'].search([
            ('active', '=', True),
            ('instance_id.state', '=', 'connected')
        ])

        now = datetime.now()
        for config in configs:
            if config.interval_type == 'months':
                delta = relativedelta(months=config.interval_number)
            else:
                delta = timedelta(**{config.interval_type: config.interval_number})
            
            if not config.last_sync or now >= (config.last_sync + delta):
                config.action_run_now()

    def automation_sync_products(self, config=None):    
        _logger.info(f"Syncing PRODUCTS for {self.name}")
        sync_filter = config.sync_filter if config else 'all'
        # Fetch first 50 records to sync
        res = self.get_shopify_products_paged(limit=50, sync_status=sync_filter)
        if res.get('status') == 'success':
            shopify_ids = [p['id'] for p in res['products']]
            if shopify_ids:
                print("shopify_ids",shopify_ids)
                self.sync_selected_products(shopify_ids)
    def automation_sync_orders(self, config=None): 
        _logger.info(f"Syncing ORDERS for {self.name}")
        sync_filter = config.sync_filter if config else 'all'
        res = self.get_shopify_orders_paged(limit=50, sync_status=sync_filter)
        if res.get('status') == 'success':
            shopify_ids = [o['id'] for o in res['orders']]
            if shopify_ids:
                print("shopify_ids",shopify_ids)
                self.sync_selected_draft_orders(shopify_ids)
    def automation_sync_customers(self, config=None): 
        _logger.info(f"Syncing CUSTOMERS for {self.name}")
        sync_filter = config.sync_filter if config else 'all'
        res = self.get_shopify_customers_paged(limit=50, sync_status=sync_filter)
        if res.get('status') == 'success':
            shopify_ids = [c['id'] for c in res['customers']]
            if shopify_ids:
                print("shopify_ids",shopify_ids)
                self.sync_selected_customers(shopify_ids)

    def automation_sync_inventory(self, config=None): 
        _logger.info(f"Syncing INVENTORY for {self.name} (Master: {self.master_inventory})")
        # Find all synced variants in the platform
        synced_variants = self.env['product.product'].search([
            ('shopify_instance_id', '=', self.id),
            ('shopify_variant_id', '!=', False)
        ], limit=200) # Sync up to 200 at a time
        if synced_variants:
            shopify_ids = synced_variants.mapped('shopify_variant_id')
            self.sync_selected_inventory(shopify_ids)

    def get_access_token(self):
        self.ensure_one()
        third_party_url = self.shopify_third_party_uri
        if not third_party_url: return self.shopify_access_token
        try:
            shop_domain = self.shop_url.replace('https://', '').replace('http://', '').strip('/')
            response = requests.get(f"{third_party_url.strip('/')}/get_token.php", params={"shop": shop_domain}, timeout=15)
            if response.status_code == 200:
                try: data = response.json(); token = data.get("access_token")
                except: token = response.text.strip()
                if token and ('shpat_' in token or 'shpua_' in token):
                    self.shopify_access_token = token
                    return token
        except Exception: pass
        return self.shopify_access_token

    def action_fetch_token(self):
        """ Manually trigger token fetch from bridge and test connection """
        self.ensure_one()
        token = self.get_access_token()
        if not token:
            raise UserError(_("Could not fetch access token. Please ensure you have authorized the app and the Bridge URL is correct."))
        
        # Once fetched, test the connection to update status and fetch shop info
        return self.test_connection()

    def action_disconnect(self):
        """ Reset connection details and set status to draft """
        self.ensure_one()
        self.write({
            'state': 'disconnected',
            'shopify_access_token': False,
            'shopify_access_token_manual': False,
            'shopify_shop_id': False,
            'shopify_shop_name': False,
            'shopify_shop_email': False,
        })
        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': _('Disconnected'),
                'message': _('Shopify instance has been disconnected.'),
                'type': 'warning',
                'sticky': False,
            }
        }

    def action_validate_store(self):
        """ 
        Sends shop url to third party and updates state to validated.
        """
        self.ensure_one()
        third_party_url = self.shopify_third_party_uri
        client_id = self.shopify_client_id
        client_secret = self.shopify_client_secret
        api_version = self.api_version
        if not self.shop_url:
            raise UserError(_("Please provide Shop URL."))
            
        # Ensure shop_url starts with https:// and doesn't end with /
        shop_url = self.shop_url.strip()
        if not shop_url.startswith('http'):
            shop_url = 'https://' + shop_url
        if shop_url.endswith('/'):
            shop_url = shop_url[:-1]
        self.shop_url = shop_url

        if third_party_url:
            try:
                _logger.info("Sending shop URL to third party: %s", self.shop_url)
                app_url = f"{third_party_url.strip('/')}/inc.php"
                _logger.info("Calling validation URL: %s", app_url)
                response = requests.post(
                    app_url,
                    data={"shop_url": self.shop_url, 'client_id': client_id, 'client_secret': client_secret, 'api_version': api_version},
                    timeout=10
                )
                if response.status_code in [200, 201]:
                    self.state = 'validated'
                else:
                    raise UserError(_("Third party validation failed. Status code: %s") % response.status_code)
            except Exception as e:
                _logger.error("Failed to send shop URL to third party: %s", str(e))
                raise UserError(_("Connection to third party failed: %s") % str(e))
        else:
            self.state = 'validated'

    def action_authorize(self):
        """ 
        Redirects to Shopify App install URL.
        """
        self.ensure_one()
        
        client_id = self.shopify_client_id
        redirect_uri = self.shopify_redirect_uri
        scopes = self.shopify_scopes

        if not client_id or not self.shop_url:
            raise UserError(_("Please provide Shop URL in instance and Client ID in Settings."))
        
        # Action: Redirect to Shopify App install URL
        shop_domain = self.shop_url.replace('https://', '').replace('http://', '').strip('/')
        
        # Build authorize URL
        auth_url = f"https://{shop_domain}/admin/oauth/authorize?client_id={client_id}"
        if scopes:
            auth_url += f"&scope={scopes}"
        if redirect_uri:
            auth_url += f"&redirect_uri={redirect_uri}"
        
        # Add state to identify instance on callback
        base_url = self.env['ir.config_parameter'].sudo().get_param('web.base.url')
        state_data = f"{self.id}|{base_url}"
        auth_url += f"&state={state_data}"
        
        _logger.info("Redirecting to Shopify Auth: %s", auth_url)
        return {
            'type': 'ir.actions.act_url',
            'url': auth_url,
            'target': 'self',
        }

    def test_connection(self):
        for record in self:
            token = record.shopify_access_token_manual or record.shopify_access_token
            
            # Auto-detect if shp* token is placed in other fields
            if not token:
                if record.shopify_client_secret and record.shopify_client_secret.startswith('shp'):
                    token = record.shopify_client_secret
                elif record.api_key and record.api_key.startswith('shp'):
                    token = record.api_key
                elif record.api_secret and record.api_secret.startswith('shp'):
                    token = record.api_secret

            url = f"{record.shop_url}/admin/api/{record.api_version}/shop.json"
            headers = {}
            auth = None
            
            if token:
                headers = {'X-Shopify-Access-Token': token.strip()}
                _logger.info("Testing connection using Access Token: %s...", token[:10])
            elif record.api_key and record.api_secret:
                auth = (record.api_key.strip(), record.api_secret.strip())
                _logger.info("Testing connection using Basic Auth (API Key/Secret)...")
            else:
                if record.shopify_client_id and record.shop_url:
                    raise UserError(_("No Access Token found. Please click 'Authorize App' or provide a Manual Access Token."))
                else:
                    raise UserError(_("No credentials found. Please provide Shop URL and authentication details."))

            try:
                response = requests.get(url, headers=headers, auth=auth, timeout=10)
                _logger.info("Shopify Connection Response Code: %s", response.status_code)
                if response.status_code == 200:
                    shop_data = response.json().get('shop', {})
                    record.write({
                        'state': 'connected',
                        'shopify_shop_id': str(shop_data.get('id')),
                        'shopify_shop_name': shop_data.get('name'),
                        'shopify_shop_email': shop_data.get('email'),
                    })
                    return {
                        'type': 'ir.actions.client',
                        'tag': 'display_notification',
                        'params': {
                            'title': _('Connection Successful'),
                            'message': _('Successfully connected to Shopify store: %s') % record.shopify_shop_name,
                            'type': 'success',
                            'sticky': False,
                        }
                    }
                else:
                    record.state = 'error'
                    _logger.error("Shopify Test Connection Failed: %s", response.text)
                    raise UserError(_("Connection failed! Status code: %s, Message: %s") % (response.status_code, response.text))
            except Exception as e:
                record.state = 'error'
                raise UserError(_("Connection failed! Error: %s") % str(e))

    def _get_shopify_headers(self):
        self.ensure_one()
        # FIX: Read stored tokens directly first (same as the platform) to avoid triggering a
        # DB write on every dashboard data-fetch request, which causes concurrent update
        # serialization errors. Only call get_access_token() (which writes to DB) when
        # no token is stored yet.
        token = self.shopify_access_token_manual or self.shopify_access_token
        if not token:
            token = self.get_access_token()
        if token:
            return {
                'X-Shopify-Access-Token': token.strip(),
                'Content-Type': 'application/json'
            }
        return {}

    def shopify_graphql_query(self, query, variables=None):
        self.ensure_one()
        url = f"{self.shop_url}/admin/api/{self.api_version}/graphql.json"
        headers = self._get_shopify_headers()
        
        payload = {'query': query}
        if variables:
            payload['variables'] = variables

        try:
            response = requests.post(url, headers=headers, json=payload, timeout=30)
            if response.status_code == 200:
                result = response.json()
                if 'errors' in result:
                    _logger.error("Shopify GraphQL Errors: %s", result['errors'])
                    return {'error': result['errors']}
                return result.get('data', {})
            else:
                _logger.error("Shopify GraphQL Request Failed: %s", response.text)
                return {'error': response.text}
        except Exception as e:
            _logger.error("Exception in Shopify GraphQL Request: %s", str(e))
            return {'error': str(e)}
        
    

    def action_sync_products_graphql(self):
        """ Start the GraphQL synchronization process """
        self.ensure_one()
        # This will be called via JS for real-time progress, 
        # but can also be called directly for a simple batch sync.
        return self.sync_products_graphql()

    def sync_products_graphql(self, cursor=None, limit=10):
        self.ensure_one()
        query = """
        query GetProducts($first: Int!, $after: String) {
          products(first: $first, after: $after) {
            pageInfo {
              hasNextPage
              endCursor
            }
        nodes {
                id
                title
                handle
                descriptionHtml
                vendor
                productType
                createdAt
                updatedAt
                status
                tags
                images(first: 10) {
                  edges {
                    node {
                      id
                      url
                      altText
                    }
                  }
                }
                variants(first: 50) {
                  edges {
                    node {
                      id
                      title
                      sku
                      price
                      compareAtPrice
                      inventoryQuantity
                      selectedOptions {
                        name
                        value
                      }
                    }
                  }
                }
                options {
                  id
                  name
                  values
                }
            }
          }
        }
        """
        variables = {'first': limit, 'after': cursor}
        data = self.shopify_graphql_query(query, variables)
        
        if 'error' in data:
            self.env['shopify.sync.log'].log(self.id, "Fetch Products", 'product', 'error', f"Failed to fetch products: {data['error']}")
            return {'status': 'error', 'message': str(data['error'])}

        products_data = data.get('products', {})
        nodes = products_data.get('nodes', [])
        page_info = products_data.get('pageInfo', {})

        synced_count = 0
        for product_node in nodes:
            try:
                # Pass self to ensure it uses this instance's config (location_id, category, etc)
                self._process_shopify_product_graphql(product_node)
                synced_count += 1
            except Exception as e:
                _logger.error("Error processing product %s: %s", product_node.get('title'), str(e))
                self.env['shopify.sync.log'].log(self.id, product_node.get('title', 'Unknown'), 'product', 'error', str(e), shopify_id=product_node.get('id'))

        return {
            'status': 'success',
            'synced_count': synced_count,
            'has_next_page': page_info.get('hasNextPage'),
            'end_cursor': page_info.get('endCursor')
        }

    def _process_shopify_product_graphql(self, node):
        shopify_id = node['id']
        handle = node['handle']
        title = node['title']
        
        # 1. Find or create Template
        template = self.env['product.template'].search([
            '|', 
            ('shopify_product_id', '=', shopify_id),
            ('default_code', '=', node['variants']['edges'][0]['node']['sku']) if node['variants']['edges'] and node['variants']['edges'][0]['node']['sku'] else (0, '=', 1)
        ], limit=1)

        # Process Tags
        tag_ids = []
        for tag_name in node.get('tags', []):
            tag = self.env['product.tag'].search([('name', '=', tag_name)], limit=1)
            if not tag:
                tag = self.env['product.tag'].create({'name': tag_name})
            tag_ids.append(tag.id)

        vals = {
            'name': title,
            'description_sale': node.get('descriptionHtml'),
            'shopify_product_id': shopify_id,
            'shopify_instance_id': self.id,
            'is_synced_to_shopify': True,
            'product_tag_ids': [(6, 0, tag_ids)],
            'type': 'consu', # the platform uses 'consu' for Goods
            'is_storable': True, # This flag activates stock tracking
        }

        if template:
            template.write(vals)
        else:
            template = self.env['product.template'].create(vals)

        self.env['shopify.sync.log'].log(self.id, title, 'product', 'success', f"Synced template: {title}", shopify_id=shopify_id, res_model='product.template', res_id=template.id, payload=node)

        # 2. Process Attributes (Options)
        attribute_map = {}
        for option in node.get('options', []):
            attr_name = option['name']
            if attr_name == 'Title' and len(node.get('options', [])) == 1:
                continue # Shopify default single variant option
                
            attribute = self.env['product.attribute'].search([('name', '=', attr_name)], limit=1)
            if not attribute:
                attribute = self.env['product.attribute'].create({'name': attr_name, 'display_type': 'select'})
            
            attribute_map[attr_name] = attribute

            # Process all predefined values for this option
            value_ids = []
            for val_name in option.get('values', []):
                value = self.env['product.attribute.value'].search([
                    ('attribute_id', '=', attribute.id),
                    ('name', '=', val_name)
                ], limit=1)
                if not value:
                    value = self.env['product.attribute.value'].create({
                        'attribute_id': attribute.id,
                        'name': val_name
                    })
                value_ids.append(value.id)

            # Add attribute to template if not present, with all its values
            line = template.attribute_line_ids.filtered(lambda l: l.attribute_id == attribute)
            if not line:
                template.attribute_line_ids = [(0, 0, {
                    'attribute_id': attribute.id,
                    'value_ids': [(6, 0, value_ids)]
                })]
            else:
                line.write({'value_ids': [(6, 0, value_ids)]})

        # 3. Process Variants
        for edge in node.get('variants', {}).get('edges', []):
            variant_node = edge['node']
            self._process_shopify_variant_graphql(template, variant_node, attribute_map)

        # 4. Process Images
        if self.import_images and node.get('images', {}).get('edges'):
            image_edges = node['images']['edges']
            
            # Main image
            first_image_node = image_edges[0]['node']
            try:
                # Use a smaller timeout and handle potential request errors
                response = requests.get(first_image_node['url'], timeout=10)
                if response.status_code == 200:
                    template.image_1920 = base64.b64encode(response.content)
            except Exception as e:
                _logger.warning("Failed to fetch main image for product %s: %s", title, str(e))
                
            # Additional images - only if the field exists (usually requires website_sale or similar)
            if len(image_edges) > 1 and hasattr(template, 'product_template_image_ids'):
                try:
                    # Basic strategy: remove existing and re-add to keep in sync with Shopify
                    template.product_template_image_ids.unlink()
                    for edge in image_edges[1:]:
                        img_node = edge['node']
                        img_resp = requests.get(img_node['url'], timeout=10)
                        if img_resp.status_code == 200:
                            self.env['product.image'].create({
                                'product_tmpl_id': template.id,
                                'name': img_node.get('altText') or title,
                                'image_1920': base64.b64encode(img_resp.content),
                            })
                except Exception as e:
                    _logger.warning("Failed to process additional images for product %s: %s", title, str(e))

    def _process_shopify_variant_graphql(self, template, node, attribute_map):
        shopify_variant_id = node['id']
        sku = node.get('sku')
        price = float(node.get('price', 0))
        qty = node.get('inventoryQuantity', 0)

        # 1. Update/Ensure Attribute Value IDs are tracked
        value_ids = []
        for option in node.get('selectedOptions', []):
            attr_name = option['name']
            attr_val = option['value']
            if attr_name in attribute_map:
                attribute = attribute_map[attr_name]
                value = self.env['product.attribute.value'].search([
                    ('attribute_id', '=', attribute.id),
                    ('name', '=', attr_val)
                ], limit=1)
                if not value:
                    value = self.env['product.attribute.value'].create({
                        'attribute_id': attribute.id,
                        'name': attr_val
                    })
                
                # Ensure value is on template line
                line = template.attribute_line_ids.filtered(lambda l: l.attribute_id == attribute)
                if value not in line.value_ids:
                    line.value_ids = [(4, value.id)]
                
                value_ids.append(value.id)

        # 2. Identify the PTAVs (Product Template Attribute Values) for this combination
        ptavs = self.env['product.template.attribute.value'].search([
            ('product_tmpl_id', '=', template.id),
            ('product_attribute_value_id', 'in', value_ids)
        ])

        # 3. Find specific variant
        variant = self.env['product.product'].search([
            '|',
            ('shopify_variant_id', '=', shopify_variant_id),
            ('default_code', '=', sku) if sku else (0, '=', 1)
        ], limit=1)

        if not variant and ptavs:
            variant = template._get_variant_for_combination(ptavs)

        if not variant and not ptavs and len(template.product_variant_ids) == 1:
            variant = template.product_variant_ids[0]

        if variant:
            # Update variant-specific identification
            variant.write({
                'shopify_variant_id': shopify_variant_id,
                'default_code': sku,
                'shopify_instance_id': self.id,
                'is_synced_to_shopify': True
            })

            # Handle Price: Set template price from first variant found (Base Price)
            if not template.list_price or template.list_price == 0.0:
                template.write({'list_price': price})
            
            # Sync to Product Variant Extra Price (for the platform List View Visibility)
            diff = price - template.list_price
            if diff != 0 and ptavs:
                # Apply diff to the first attribute (e.g. Color) to make it visible in "Sales Price" column
                target_ptav = ptavs[0]
                if target_ptav.price_extra != diff:
                    target_ptav.write({'price_extra': diff})

            # Sync Stock (if it's a storable product)
            self._update_odoo_inventory(variant, qty)

            self.env['shopify.sync.log'].log(self.id, f"Variant: {node.get('title')}", 'variant', 'success', f"Synced variant SKU: {sku}", shopify_id=shopify_variant_id, res_model='product.product', res_id=variant.id, payload=node)

            # Sync to Pricelist if configured
            if self.pricelist_id:
                pricelist_item = self.env['product.pricelist.item'].search([
                    ('pricelist_id', '=', self.pricelist_id.id),
                    ('product_id', '=', variant.id)
                ], limit=1)
                
                if pricelist_item:
                    pricelist_item.write({
                        'compute_price': 'fixed',
                        'fixed_price': price,
                    })
                else:
                    self.env['product.pricelist.item'].create({
                        'pricelist_id': self.pricelist_id.id,
                        'product_id': variant.id,
                        'product_tmpl_id': template.id,
                        'fixed_price': price,
                        'applied_on': '0_product_variant',
                        'compute_price': 'fixed'
                    })


    def _update_odoo_inventory(self, product, qty):
        """ Basic inventory update logic to sync stock levels (the platform compatible) """
        if not product:
            return
            
        # In the platform/18/19, is_storable is the key flag, type is usually 'product'
        if not product.is_storable:
            _logger.info("Skipping stock sync for product %s: is_storable is False", product.name)
            return

        # Use configured stock location from this instance
        location = self.location_id
        _logger.info("DEBUG: Instance %s using location_id: %s", self.name, self.location_id.id)
        if not location and self.warehouse_id:
            location = self.warehouse_id.lot_stock_id
            _logger.info("Using warehouse fallback location: %s", location.display_name if location else 'None')
        
        if not location:
            # Fallback to first internal location as last resort
            location = self.env['stock.location'].search([('usage', '=', 'internal')], limit=1)
            _logger.info("Using last-resort fallback location: %s", location.display_name if location else 'None')
        
        if not location:
            _logger.warning("No internal location found for Shopify inventory sync.")
            return

        _logger.info("SYNCING STOCK: Product: %s | Qty: %s | Target Location: %s (ID: %s)", product.name, qty, location.display_name, location.id)

        # Use stock.quant's inventory mode to perform the adjustment
        # Search for an existing quant to update, or create a new one if it doesn't exist
        quant = self.env['stock.quant'].search([
            ('product_id', '=', product.id),
            ('location_id', '=', location.id),
            ('lot_id', '=', False),
            ('package_id', '=', False),
            ('owner_id', '=', False)
        ], limit=1)
        
        if quant:
            # Update existing quant
            quant.with_context(inventory_mode=True).inventory_quantity = qty
            quant.action_apply_inventory()
            _logger.info("Updated existing quant for %s", product.name)
        else:
            # Create new quant for this location
            quant = self.env['stock.quant'].with_context(inventory_mode=True).create({
                'product_id': product.id,
                'location_id': location.id,
                'inventory_quantity': qty,
            })
            quant.action_apply_inventory()
            _logger.info("Created new quant for %s", product.name)
        
        _logger.info("Stock sync complete for %s", product.name)

    def sync_orders(self):
        """ Fetch orders from Shopify """
        self.ensure_one()
        _logger.info("Syncing orders for instance %s", self.name)
        url = f"{self.shop_url}/admin/api/{self.api_version}/orders.json?status=any"
        
        try:
            response = requests.get(url, headers=self._get_shopify_headers(), auth=self._get_shopify_auth(), timeout=15)
            if response.status_code == 200:
                orders = response.json().get('orders', [])
                for order in orders:
                    _logger.info("Fetched Shopify Order: %s (ID: %s)", order.get('name'), order.get('id'))
                
                return {
                    'type': 'ir.actions.client',
                    'tag': 'display_notification',
                    'params': {
                        'title': _('Order Sync Completed'),
                        'message': _('Successfully fetched %s orders from Shopify.') % len(orders),
                        'sticky': False,
                    }
                }
            else:
                raise UserError(_("Failed to fetch orders: %s") % response.text)
        except Exception as e:
            raise UserError(_("Error during order sync: %s") % str(e))
        
    def sync_customers(self):
        """ Fetch customers from Shopify """
        self.ensure_one()
        _logger.info("Syncing customers for instance %s", self.name)
        url = f"{self.shop_url}/admin/api/{self.api_version}/customers.json"
        
        try:
            response = requests.get(url, headers=self._get_shopify_headers(), auth=self._get_shopify_auth(), timeout=15)
            if response.status_code == 200:
                customers = response.json().get('customers', [])
                for cust in customers:
                    _logger.info("Fetched Shopify Customer: %s %s", cust.get('first_name'), cust.get('last_name'))
                
                return {
                    'type': 'ir.actions.client',
                    'tag': 'display_notification',
                    'params': {
                        'title': _('Customer Sync Completed'),
                        'message': _('Successfully fetched %s customers from Shopify.') % len(customers),
                        'sticky': False,
                    }
                }
            else:
                raise UserError(_("Failed to fetch customers: %s") % response.text)
        except Exception as e:
            raise UserError(_("Error during customer sync: %s") % str(e))

    def get_shopify_products_paged(self, cursor=None, limit=20, search=None, status=None, sync_status=None, from_date=None, to_date=None, direction='next'):
        """ Fetch products from Shopify for the dashboard preview with advanced filtering """
        self.ensure_one()
        products = []
        current_cursor = cursor
        has_next_page = True
        has_previous_page = True
        
        # Fetch total count via REST (GraphQL doesn't support totalCount on top-level products)
        total_count = 0
        try:
            count_url = f"{self.shop_url}/admin/api/{self.api_version}/products/count.json"
            count_params = {}
            if status: count_params['status'] = status
            if search: count_params['title'] = search
            count_res = requests.get(count_url, headers=self._get_shopify_headers(), params=count_params, timeout=10)
            if count_res.status_code == 200:
                total_count = count_res.json().get('count', 0)
        except: pass

        while len(products) < limit and (has_next_page if direction == 'next' else has_previous_page):
            query_filter = []
            if search: query_filter.append(f'title:{search}*')
            if status: query_filter.append(f'status:{status}')
            if from_date: query_filter.append(f'updated_at:>{from_date}')
            if to_date: query_filter.append(f'updated_at:<{to_date}')
            filter_str = f', query: "{" ".join(query_filter)}"' if query_filter else ""

            query = """
            query GetProducts($first: Int, $after: String, $last: Int, $before: String) {
              products(first: $first, after: $after, last: $last, before: $before, reverse: true%s) {
                pageInfo { hasNextPage endCursor hasPreviousPage startCursor }
                nodes { id title handle status totalVariants updatedAt productType images(first: 1) { edges { node { url } } } }
              }
            }
            """ % filter_str

            variables = {'first': None, 'after': None, 'last': None, 'before': None}
            if direction == 'next':
                variables.update({'first': min(limit * 2, 250), 'after': current_cursor})
            else:
                variables.update({'last': min(limit * 2, 250), 'before': current_cursor})

            data = self.shopify_graphql_query(query, variables)
            if 'error' in data: return {'status': 'error', 'message': str(data['error'])}
            
            shopify_data = data.get('products', {})
            nodes = shopify_data.get('nodes', [])
            page_info = shopify_data.get('pageInfo', {})
            
            has_next_page = page_info.get('hasNextPage', False)
            has_previous_page = page_info.get('hasPreviousPage', False)
            
            if direction == 'next':
                current_cursor = page_info.get('endCursor')
            else:
                current_cursor = page_info.get('startCursor')
            
            shopify_ids = [n['id'] for n in nodes]
            synced_ids = self.env['product.template'].search([('shopify_product_id', 'in', shopify_ids)]).mapped('shopify_product_id')

            for node in nodes:
                is_synced = node['id'] in synced_ids
                if sync_status == 'synced' and not is_synced: continue
                if sync_status == 'not_synced' and is_synced: continue
                
                products.append({
                    'id': node['id'], 'title': node['title'], 'handle': node['handle'], 'status': node['status'],
                    'type': node.get('productType'), 'updated_at': node.get('updatedAt'),
                    'variants_count': node['totalVariants'],
                    'image_url': node['images']['edges'][0]['node']['url'] if node['images']['edges'] else False,
                    'is_synced': is_synced
                })
                if len(products) == limit: break
            
            if not nodes: break

        return {
            'status': 'success', 
            'products': products, 
            'totalCount': total_count,
            'pageInfo': {
                'hasNextPage': has_next_page, 
                'endCursor': page_info.get('endCursor'),
                'hasPreviousPage': has_previous_page,
                'startCursor': page_info.get('startCursor')
            }
        }

    def get_shopify_customers_paged(self, cursor=None, limit=20, search=None, status=None, sync_status=None, from_date=None, to_date=None, direction='next'):
        """ Fetch customers from Shopify for the dashboard preview """
        self.ensure_one()
        customers = []
        current_cursor = cursor
        has_next_page = True
        has_previous_page = True
        
        total_count = 0
        try:
            count_url = f"{self.shop_url}/admin/api/{self.api_version}/customers/count.json"
            count_res = requests.get(count_url, headers=self._get_shopify_headers(), timeout=10)
            if count_res.status_code == 200:
                total_count = count_res.json().get('count', 0)
        except: pass

        while len(customers) < limit and (has_next_page if direction == 'next' else has_previous_page):
            query_filter = []
            if search:
                query_filter.append(f'*{search}*')
            if from_date: query_filter.append(f'updated_at:>{from_date}')
            if to_date: query_filter.append(f'updated_at:<{to_date}')
            filter_str = f', query: "{" ".join(query_filter)}"' if query_filter else ""

            query = """
            query GetCustomers($first: Int, $after: String, $last: Int, $before: String) {
              customers(first: $first, after: $after, last: $last, before: $before, reverse: true%s) {
                pageInfo { hasNextPage endCursor hasPreviousPage startCursor }
                nodes {
                    id firstName lastName email phone updatedAt
                    defaultAddress { country city }
                }
              }
            }
            """ % filter_str

            variables = {'first': None, 'after': None, 'last': None, 'before': None}
            if direction == 'next':
                variables.update({'first': min(limit * 2, 100), 'after': current_cursor})
            else:
                variables.update({'last': min(limit * 2, 100), 'before': current_cursor})

            data = self.shopify_graphql_query(query, variables)
            if 'error' in data:
                error_msg = str(data['error'])
                if "ACCESS_DENIED" in error_msg or "not approved to access" in error_msg:
                    return {'status': 'error', 'message': "ACCESS_DENIED: Protected Customer Data access required."}
                return {'status': 'error', 'message': error_msg}

            shopify_data = data.get('customers', {})
            nodes = shopify_data.get('nodes', [])
            page_info = shopify_data.get('pageInfo', {})
            has_next_page = page_info.get('hasNextPage', False)
            has_previous_page = page_info.get('hasPreviousPage', False)

            if direction == 'next':
                current_cursor = page_info.get('endCursor')
            else:
                current_cursor = page_info.get('startCursor')

            # Check which ones are already in the platform
            shopify_ids = [n['id'] for n in nodes]
            existing_partners = self.env['res.partner'].search_read(
                [('shopify_customer_id', 'in', shopify_ids)], 
                ['shopify_customer_id']
            )
            synced_ids = [p['shopify_customer_id'] for p in existing_partners]

            for node in nodes:
                is_synced = node['id'] in synced_ids
                if sync_status == 'synced' and not is_synced: continue
                if sync_status == 'not_synced' and is_synced: continue
                
                customers.append({
                    'id': node['id'],
                    'name': f"{node['firstName'] or ''} {node['lastName'] or ''}".strip() or "No Name",
                    'email': node['email'],
                    'phone': node['phone'],
                    'updated_at': node.get('updatedAt'),
                    'location': f"{node['defaultAddress']['city']}, {node['defaultAddress']['country']}" if node['defaultAddress'] else "No Address",
                    'is_synced': is_synced
                })
                if len(customers) == limit: break
            
            if not nodes: break

        return {
            'status': 'success',
            'customers': customers,
            'totalCount': total_count,
            'pageInfo': page_info
        }

    # ─────────────────────────────────────────────────────────────────────────
    # CONFIRMED ORDERS — Fetch & Sync
    # ─────────────────────────────────────────────────────────────────────────

    def get_shopify_orders_paged(self, cursor=None, limit=20, search=None, status=None,
                                  sync_status=None, from_date=None, to_date=None, direction='next'):
        """ Fetch CONFIRMED orders from Shopify for the dashboard preview """
        self.ensure_one()
        orders = []
        current_cursor = cursor
        has_next_page = True
        has_previous_page = True

        # Total count via REST
        total_count = 0
        try:
            count_params = {}
            if status and status != 'all':
                count_params['financial_status'] = status
            count_res = requests.get(
                f"{self.shop_url}/admin/api/{self.api_version}/orders/count.json",
                headers=self._get_shopify_headers(),
                params=count_params,
                timeout=10
            )
            if count_res.status_code == 200:
                total_count = count_res.json().get('count', 0)
        except:
            pass

        while len(orders) < limit and (has_next_page if direction == 'next' else has_previous_page):
            query_filter = []
            if search:
                query_filter.append(f'name:*{search}*')
            if status and status != 'all':
                query_filter.append(f'financial_status:{status}')
            if from_date:
                query_filter.append(f'processed_at:>{from_date}')
            if to_date:
                query_filter.append(f'processed_at:<{to_date}')
            filter_str = f', query: "{" ".join(query_filter)}"' if query_filter else ""

            query = """
            query GetConfirmedOrders($first: Int, $after: String, $last: Int, $before: String) {
              orders(first: $first, after: $after, last: $last, before: $before, reverse: true%s) {
                pageInfo { hasNextPage endCursor hasPreviousPage startCursor }
                nodes {
                    id name createdAt
                    displayFinancialStatus
                    displayFulfillmentStatus
                    totalPriceSet { presentmentMoney { amount currencyCode } }
                    customer { firstName lastName email }
                }
              }
            }
            """ % filter_str

            variables = {'first': None, 'after': None, 'last': None, 'before': None}
            if direction == 'next':
                variables.update({'first': min(limit * 2, 100), 'after': current_cursor})
            else:
                variables.update({'last': min(limit * 2, 100), 'before': current_cursor})

            data = self.shopify_graphql_query(query, variables)
            if 'error' in data:
                error_msg = str(data['error'])
                if "ACCESS_DENIED" in error_msg or "not approved to access" in error_msg:
                    return {'status': 'error', 'message': "ACCESS_DENIED: Protected Customer Data access required."}
                return {'status': 'error', 'message': error_msg}

            shopify_data = data.get('orders', {})
            nodes = shopify_data.get('nodes', [])
            page_info = shopify_data.get('pageInfo', {})
            has_next_page = page_info.get('hasNextPage', False)
            has_previous_page = page_info.get('hasPreviousPage', False)
            current_cursor = page_info.get('endCursor') if direction == 'next' else page_info.get('startCursor')

            shopify_ids = [n['id'] for n in nodes]
            existing_orders = self.env['sale.order'].search_read(
                [('shopify_order_id', 'in', shopify_ids)], ['shopify_order_id']
            )
            synced_ids = [o['shopify_order_id'] for o in existing_orders]

            for node in nodes:
                is_synced = node['id'] in synced_ids
                if sync_status == 'synced' and not is_synced:
                    continue
                if sync_status == 'not_synced' and is_synced:
                    continue

                customer_name = "Guest"
                if node.get('customer'):
                    customer_name = (
                        f"{node['customer']['firstName'] or ''} {node['customer']['lastName'] or ''}".strip()
                        or node['customer']['email']
                    )

                orders.append({
                    'id': node['id'],
                    'name': node['name'],
                    'date': node['createdAt'],
                    'amount': f"{node['totalPriceSet']['presentmentMoney']['amount']} {node['totalPriceSet']['presentmentMoney']['currencyCode']}",
                    'financial_status': node.get('displayFinancialStatus', ''),
                    'fulfillment_status': node.get('displayFulfillmentStatus', ''),
                    'customer': customer_name,
                    'is_synced': is_synced,
                    'type': 'order',
                })
                if len(orders) == limit:
                    break

            if not nodes:
                break

        return {
            'status': 'success',
            'orders': orders,
            'totalCount': total_count,
            'pageInfo': page_info if orders or not has_next_page else {},
        }

    # ─────────────────────────────────────────────────────────────────────────
    # DRAFT ORDERS — Fetch & Sync
    # ─────────────────────────────────────────────────────────────────────────

    def get_shopify_draft_orders_paged(self, cursor=None, limit=20, search=None,
                                        status=None, sync_status=None, from_date=None, to_date=None, direction='next'):
        """ Fetch DRAFT orders from Shopify for the dashboard preview """
        # status: None/'all' = all, 'draft'/'open' = OPEN, 'completed' = COMPLETED
        self.ensure_one()
        orders = []
        current_cursor = cursor
        has_next_page = True
        has_previous_page = True

        # Total count via REST
        total_count = 0
        try:
            count_params = {}
            # Map frontend status to Shopify REST status values
            if status in ('draft', 'open'):
                count_params['status'] = 'open'
            elif status == 'completed':
                count_params['status'] = 'completed'
            count_res = requests.get(
                f"{self.shop_url}/admin/api/{self.api_version}/draft_orders/count.json",
                headers=self._get_shopify_headers(),
                params=count_params,
                timeout=10
            )
            if count_res.status_code == 200:
                total_count = count_res.json().get('count', 0)
        except:
            pass

        while len(orders) < limit and (has_next_page if direction == 'next' else has_previous_page):
            query_filter = []
            if search:
                query_filter.append(f'name:*{search}*')
            # Shopify draft order status filter: 'open' = pending/draft, 'completed' = converted to order
            if status in ('draft', 'open'):
                query_filter.append('status:open')
            elif status == 'completed':
                query_filter.append('status:completed')
            if from_date:
                query_filter.append(f'updated_at:>{from_date}')
            if to_date:
                query_filter.append(f'updated_at:<{to_date}')
            filter_str = f', query: "{" ".join(query_filter)}"' if query_filter else ""

            query = """
            query GetDraftOrders($first: Int, $after: String, $last: Int, $before: String) {
              draftOrders(first: $first, after: $after, last: $last, before: $before, reverse: true%s) {
                pageInfo { hasNextPage endCursor hasPreviousPage startCursor }
                nodes {
                    id name createdAt status
                    order { id }
                    totalPriceSet { presentmentMoney { amount currencyCode } }
                    customer { firstName lastName email }
                }
              }
            }
            """ % filter_str

            variables = {'first': None, 'after': None, 'last': None, 'before': None}
            if direction == 'next':
                variables.update({'first': min(limit * 2, 100), 'after': current_cursor})
            else:
                variables.update({'last': min(limit * 2, 100), 'before': current_cursor})

            data = self.shopify_graphql_query(query, variables)
            if 'error' in data:
                error_msg = str(data['error'])
                if "ACCESS_DENIED" in error_msg or "not approved to access" in error_msg:
                    return {'status': 'error', 'message': "ACCESS_DENIED: Protected Customer Data access required."}
                return {'status': 'error', 'message': error_msg}

            shopify_data = data.get('draftOrders', {})
            nodes = shopify_data.get('nodes', [])
            page_info = shopify_data.get('pageInfo', {})
            has_next_page = page_info.get('hasNextPage', False)
            has_previous_page = page_info.get('hasPreviousPage', False)
            current_cursor = page_info.get('endCursor') if direction == 'next' else page_info.get('startCursor')

            # Build list of IDs to check: the Draft IDs and their linked Final Order IDs
            all_shopify_ids = []
            draft_to_final = {} # Map draft ID -> final ID
            for n in nodes:
                all_shopify_ids.append(n['id'])
                if n.get('order') and n['order'].get('id'):
                    final_id = n['order']['id']
                    all_shopify_ids.append(final_id)
                    draft_to_final[n['id']] = final_id

            # Search the platform for any orders matching either ID in either field
            existing_orders = self.env['sale.order'].search_read(
                ['|', ('shopify_order_id', 'in', all_shopify_ids), ('shopify_draft_order_id', 'in', all_shopify_ids)],
                ['shopify_order_id', 'shopify_draft_order_id']
            )
            
            # Extract all matched IDs from the platform records
            odoo_synced_ids = set()
            for o in existing_orders:
                if o.get('shopify_order_id'): odoo_synced_ids.add(o['shopify_order_id'])
                if o.get('shopify_draft_order_id'): odoo_synced_ids.add(o['shopify_draft_order_id'])

            for node in nodes:
                # A draft is synced if its Draft ID or its linked Final ID is found in the platform
                is_synced = node['id'] in odoo_synced_ids or (draft_to_final.get(node['id']) in odoo_synced_ids)
                if sync_status == 'synced' and not is_synced:
                    continue
                if sync_status == 'not_synced' and is_synced:
                    continue

                customer_name = "Guest"
                if node.get('customer'):
                    customer_name = (
                        f"{node['customer']['firstName'] or ''} {node['customer']['lastName'] or ''}".strip()
                        or node['customer']['email']
                    )

                orders.append({
                    'id': node['id'],
                    'name': node['name'],
                    'date': node['createdAt'],
                    'amount': f"{node['totalPriceSet']['presentmentMoney']['amount']} {node['totalPriceSet']['presentmentMoney']['currencyCode']}",
                    'financial_status': node.get('status', 'OPEN'),
                    'fulfillment_status': 'DRAFT',
                    'customer': customer_name,
                    'is_synced': is_synced,
                    'type': 'draft_order',
                })
                if len(orders) == limit:
                    break

            if not nodes:
                break

        return {
            'status': 'success',
            'orders': orders,
            'totalCount': total_count,
            'pageInfo': page_info if orders or not has_next_page else {},
        }

    def sync_selected_customers(self, shopify_ids):
        """ Sync selected customers from Shopify """
        self.ensure_one()
        # Full Customer GraphQL fetch
        query = """
        query GetCustomers($ids: [ID!]!) {
          nodes(ids: $ids) {
            ... on Customer {
                id firstName lastName email phone note tags
                defaultAddress { address1 address2 city province zip country provinceCode countryCode company }
            }
          }
        }
        """
        data = self.shopify_graphql_query(query, {'ids': shopify_ids})
        if 'error' in data: return {'status': 'error', 'message': str(data['error'])}
        
        nodes = data.get('nodes', [])
        count = 0
        for node in nodes:
            if not node: continue
            
            # Mapping Logic (Full Address Support for the platform)
            vals = {
                'name': f"{node['firstName'] or ''} {node['lastName'] or ''}".strip() or node['email'] or "Unnamed Shopify Customer",
                'email': node['email'],
                'phone': node['phone'],
                'comment': node.get('note'),
                'shopify_customer_id': node['id'],
                'shopify_instance_id': self.id,
                'is_shopify_customer': True,
                'customer_rank': 1, # the platform uses rank to identify customers
            }
            
            # Handle Tags (Shopify tags list -> the platform Partner Category)
            shopify_tags = node.get('tags', [])
            if shopify_tags:
                category_ids = []
                for tag_name in shopify_tags:
                    category = self.env['res.partner.category'].search([('name', '=', tag_name)], limit=1)
                    if not category:
                        category = self.env['res.partner.category'].create({'name': tag_name})
                    category_ids.append(category.id)
                if category_ids:
                    vals['category_id'] = [(6, 0, category_ids)]

            # Handle Address matching
            addr = node.get('defaultAddress')
            if addr:
                vals.update({
                    'street': addr.get('address1'),
                    'street2': addr.get('address2'),
                    'city': addr.get('city'),
                    'zip': addr.get('zip'),
                    'company_name': addr.get('company'), # Stored in company_name if it exists
                })
                
                # Resolve Country
                country_code = addr.get('countryCode')
                if country_code:
                    country = self.env['res.country'].search([('code', '=', country_code)], limit=1)
                    if country:
                        vals['country_id'] = country.id
                        
                        # Resolve State only if country is found
                        state_code = addr.get('provinceCode')
                        if state_code:
                            state = self.env['res.country.state'].search([
                                ('code', '=', state_code),
                                ('country_id', '=', country.id)
                            ], limit=1)
                            if not state:
                                # Try to match by name if code fails
                                state = self.env['res.country.state'].search([
                                    ('name', '=', addr.get('province')),
                                    ('country_id', '=', country.id)
                                ], limit=1)
                            if state:
                                vals['state_id'] = state.id

            partner = self.env['res.partner'].search([('shopify_customer_id', '=', node['id'])], limit=1)
            if partner: 
                partner.write(vals)
            else: 
                partner = self.env['res.partner'].create(vals)
            
            count += 1
            self.env['shopify.sync.log'].log(self.id, vals['name'], 'customer', 'success', f"Synced customer: {vals['name']}", shopify_id=node['id'], res_model='res.partner', res_id=partner.id, payload=node)
        
        return {'status': 'success', 'synced_count': count}

    def sync_selected_orders(self, shopify_ids):
        """ Sync selected confirmed orders from Shopify """
        self.ensure_one()
        query = """
        query GetOrders($ids: [ID!]!) {
          nodes(ids: $ids) {
            ... on Order {
                __typename
                id name createdAt displayFinancialStatus
                totalPriceSet { presentmentMoney { amount currencyCode } }
                customer { firstName lastName email phone }
                lineItems(first: 50) {
                    edges {
                        node {
                            id title sku quantity
                            variant { id }
                            discountedUnitPriceSet { presentmentMoney { amount currencyCode } }
                        }
                    }
                }
            }
          }
        }
        """
        data = self.shopify_graphql_query(query, {'ids': shopify_ids})
        if 'error' in data: return {'status': 'error', 'message': str(data['error'])}
        
        nodes = data.get('nodes', [])
        count = 0
        for node in nodes:
            if not node: continue
            self._process_shopify_order_node(node)
            count += 1
            
        return {'status': 'success', 'synced_count': count}

    def sync_selected_draft_orders(self, shopify_ids):
        """ Sync selected draft orders from Shopify """
        self.ensure_one()
        query = """
        query GetDraftOrders($ids: [ID!]!) {
          nodes(ids: $ids) {
            ... on DraftOrder {
              __typename
              id
              name
              createdAt
              status
        
              totalPriceSet { presentmentMoney { amount currencyCode } }
              subtotalPriceSet { presentmentMoney { amount currencyCode } }
              totalTaxSet { presentmentMoney { amount currencyCode } }
              totalDiscountsSet { presentmentMoney { amount currencyCode } }
        
              customer { firstName lastName email phone }
              order { id }
              shippingLine { title price }
        
              appliedDiscount {
                title
                description
                value
                valueType
                amountSet { presentmentMoney { amount currencyCode } }
              }
        
              taxLines { title rate ratePercentage }
        
              lineItems(first: 50) {
                edges {
                  node {
                    id title sku quantity variant { id }
                    originalUnitPriceSet { presentmentMoney { amount currencyCode } }
                    discountedUnitPriceSet { presentmentMoney { amount currencyCode } }
                    discountedTotalSet { presentmentMoney { amount currencyCode } }
                    appliedDiscount {
                      title description value valueType
                      amountSet { presentmentMoney { amount currencyCode } }
                    }
                  }
                }
              }
            }
          }
        }
        """
        data = self.shopify_graphql_query(query, {'ids': shopify_ids})
        if 'error' in data: return {'status': 'error', 'message': str(data['error'])}
        
        nodes = data.get('nodes', [])
        count = 0
        for node in nodes:
            if not node: continue
            self._process_shopify_order_node(node)
            count += 1
            
        return {'status': 'success', 'synced_count': count}
    def _process_shopify_order_node(self, node):
        """ Helper method to process a single Shopify order or draft order node """
        # 1. Process Customer
        partner = self.env['res.partner']
        if node.get('customer'):
            email = node['customer'].get('email')
            if email:
                partner = self.env['res.partner'].search([('email', '=', email)], limit=1)
            
            if not partner:
                partner = self.env['res.partner'].create({
                    'name': f"{node['customer'].get('firstName') or ''} {node['customer'].get('lastName') or ''}".strip() or email or "Shopify Customer",
                    'email': email,
                    'phone': node['customer'].get('phone'),
                })
        
        # 2. Extract Order Lines and Taxes
        tax_ids = []
        for tax_line in node.get('taxLines', []):
            rate_percentage = tax_line.get('ratePercentage')
            rate = tax_line.get('rate')
            if rate_percentage is None and rate is not None:
                rate_percentage = rate * 100
            if rate_percentage:
                title = tax_line.get('title') or f"Tax {rate_percentage}%"
                odoo_tax = self.env['account.tax'].search([('amount', '=', rate_percentage), ('type_tax_use', '=', 'sale')], limit=1)
                if not odoo_tax:
                    odoo_tax = self.env['account.tax'].sudo().create({
                        'name': f"{title} ({rate_percentage}%)",
                        'amount': rate_percentage,
                        'amount_type': 'percent',
                        'type_tax_use': 'sale',
                    })
                tax_ids.append(odoo_tax.id)
                
        order_lines = []
        for edge in node.get('lineItems', {}).get('edges', []):
            li = edge['node']
            variant_id = li.get('variant', {}).get('id') if li.get('variant') else False
            sku = li.get('sku')
            qty = li.get('quantity', 1)
            
            is_draft = node.get('__typename') == 'DraftOrder'
            discount_val = 0.0
            
            if is_draft:
                original_price_set = li.get('originalUnitPriceSet')
                price = float(original_price_set.get('presentmentMoney', {}).get('amount', 0.0)) if original_price_set else 0.0
                
                line_discount = li.get('appliedDiscount')
                if line_discount:
                    if line_discount.get('valueType') == 'PERCENTAGE':
                        discount_val = float(line_discount.get('value', 0.0))
                    elif line_discount.get('valueType') == 'FIXED_AMOUNT':
                        discount_amt = float(line_discount.get('amountSet', {}).get('presentmentMoney', {}).get('amount', 0.0))
                        total_original = price * qty
                        if total_original > 0:
                            discount_val = (discount_amt / total_original) * 100.0
                else:
                    # Fallback for discounts applied via code targeting specific products
                    discounted_price_set = li.get('discountedUnitPriceSet')
                    if discounted_price_set:
                        discounted_price = float(discounted_price_set.get('presentmentMoney', {}).get('amount', 0.0))
                        if price > 0 and discounted_price < price:
                            discount_val = ((price - discounted_price) / price) * 100.0
            else:
                price_set = li.get('discountedUnitPriceSet')
                price = float(price_set.get('presentmentMoney', {}).get('amount', 0.0)) if price_set else 0.0
            
            # Find product in the platform
            product = self.env['product.product'].search([
                '|',
                ('shopify_variant_id', '=', variant_id),
                ('default_code', '=', sku) if sku else (0, '=', 1)
            ], limit=1)
            
            # If product not found, search by name
            if not product:
                product = self.env['product.product'].search([('name', '=', li['title'])], limit=1)
            
            # Fallback to a Generic Shopify Product if still not found
            if not product:
                product = self.env['product.product'].search([('default_code', '=', 'SHOPIFY_GENERIC')], limit=1)
                if not product:
                    product = self.env['product.product'].create({
                        'name': li['title'],
                        'default_code': sku or 'SHOPIFY_GENERIC',
                        'type': 'consu',
                        'is_storable': True,                            
                        'invoice_policy': 'order', # Essential for auto-invoicing before delivery
                    })

            order_lines.append((0, 0, {
                'product_id': product.id,
                'name': li['title'],
                'product_uom_qty': qty,
                'price_unit': float(price),
                'discount': discount_val,
                'tax_ids': [(6, 0, tax_ids)],
            }))

        if is_draft:
            # Add Shipping Line
            shipping_line = node.get('shippingLine')
            if shipping_line and float(shipping_line.get('price', 0.0)) > 0:
                shipping_price = float(shipping_line.get('price', 0.0))
                shipping_product = self.env['product.product'].search([('default_code', '=', 'SHOPIFY_SHIPPING')], limit=1)
                if not shipping_product:
                    shipping_product = self.env['product.product'].create({
                        'name': 'Shopify Shipping',
                        'default_code': 'SHOPIFY_SHIPPING',
                        'type': 'service',
                        'invoice_policy': 'order',
                    })
                order_lines.append((0, 0, {
                    'product_id': shipping_product.id,
                    'name': shipping_line.get('title') or 'Shipping',
                    'product_uom_qty': 1,
                    'price_unit': shipping_price,
                    'tax_ids': [(6, 0, [])],
                }))
            
            # Add Discount Line
            discount = node.get('appliedDiscount')
            if discount:
                discount_amount = float(discount.get('amountSet', {}).get('presentmentMoney', {}).get('amount', 0.0))
                if discount_amount > 0:
                    discount_product = self.env['product.product'].search([('default_code', '=', 'SHOPIFY_DISCOUNT')], limit=1)
                    if not discount_product:
                        discount_product = self.env['product.product'].create({
                            'name': 'Shopify Discount',
                            'default_code': 'SHOPIFY_DISCOUNT',
                            'type': 'service',
                            'invoice_policy': 'order',
                        })
                    order_lines.append((0, 0, {
                        'product_id': discount_product.id,
                        'name': discount.get('title') or 'Discount',
                        'product_uom_qty': 1,
                        'price_unit': -discount_amount,
                        'tax_ids': [(6, 0, tax_ids)],
                    }))

            # Taxes are handled directly on the order lines using tax_id.

        # 3. Create or Find Sale Order
        try:
            draft_order_id = False
            final_order_id = False
            
            if is_draft:
                draft_order_id = node['id']
                if node.get('order'):
                    final_order_id = node['order'].get('id')
            else:
                final_order_id = node['id']

            domain = []
            if final_order_id:
                domain.append(('shopify_order_id', '=', final_order_id))
            if draft_order_id:
                domain.append(('shopify_draft_order_id', '=', draft_order_id))
                domain.append(('shopify_order_id', '=', draft_order_id)) # Legacy drafted orders

            # Build OR domain
            if len(domain) > 1:
                search_domain = ['|'] * (len(domain) - 1) + domain
            else:
                search_domain = domain

            existing = self.env['sale.order'].search(search_domain, limit=1)
            sale_order = False
            if existing:
                if existing.state not in ['draft', 'sent']:
                    # Order is already confirmed/processed, do not overwrite lines
                    self.env['shopify.sync.log'].log(self.id, node['name'], 'order', 'info', f"Order already exists and is confirmed ({existing.state}). Skipping update.", shopify_id=node['id'])
                    _logger.info("Shopify Order %s already in %s state. Skipping update.", node['name'], existing.state)
                    sale_order = existing
                else:
                    # Fully update existing lines and ensure IDs are up to date
                    update_vals = {'order_line': [(5, 0, 0)] + order_lines}
                    if final_order_id:
                        update_vals['shopify_order_id'] = final_order_id
                    if draft_order_id:
                        update_vals['shopify_draft_order_id'] = draft_order_id

                    existing.write(update_vals)
                    _logger.info("Shopify Order already exists: %s. Updated details.", node['name'])
                    sale_order = existing
            else:
                create_vals = {
                    'partner_id': partner.id or self.env.user.partner_id.id,
                    'shopify_order_id': final_order_id or None,
                    'shopify_instance_id': self.id,
                    'is_shopify_order': True,
                    'origin': f"Shopify Order {node['name']}",
                    'order_line': order_lines,
                }
                if draft_order_id:
                    create_vals['shopify_draft_order_id'] = draft_order_id
                
                sale_order = self.env['sale.order'].create(create_vals)
            if sale_order:
                # 4. Handle Auto-Confirmation & Invoicing
                # For DraftOrders, status=='COMPLETED' means it was converted to an order
                # For Orders, displayFinancialStatus=='PAID' means it's paid
                status_val = node.get('status') or node.get('displayFinancialStatus', '')
                
                # We confirm/invoice if the draft is completed OR the order is paid
                if status_val in ('COMPLETED', 'PAID'):
                    # Confirm if still quotation
                    if sale_order.state in ['draft', 'sent']:
                        try:
                            sale_order.action_confirm()
                            self.env['shopify.sync.log'].log(self.id, node['name'], 'order', 'success', f"Auto-confirmed order: {node['name']}", shopify_id=node['id'])
                        except Exception as confirm_err:
                            _logger.warning("Auto-confirm failed for %s: %s", sale_order.name, str(confirm_err))
                            self.env['shopify.sync.log'].log(self.id, node['name'], 'order', 'warning', f"Order saved but Auto-confirm failed: {str(confirm_err)}", shopify_id=node['id'])
                    
                    # Create and Validate Invoice if confirmed and not yet invoiced
                    if self.auto_create_invoice and sale_order.state in ['sale', 'done'] and sale_order.invoice_status == 'to invoice':
                        try:
                            # the platform standard: _create_invoices
                            invoice = sale_order._create_invoices(final=True)
                            if invoice:
                                invoice.action_post()
                                self.env['shopify.sync.log'].log(self.id, node['name'], 'order', 'success', f"Auto-created and validated invoice: {invoice.name}", shopify_id=node['id'], res_model='account.move', res_id=invoice.id)
                            else:
                                _logger.warning("Failed to create invoice for order %s: _create_invoices returned empty.", sale_order.name)
                        except Exception as inv_err:
                            _logger.error("Error creating invoice for %s: %s", sale_order.name, str(inv_err))
                            self.env['shopify.sync.log'].log(self.id, node['name'], 'order', 'error', f"Invoice creation failed: {str(inv_err)}", shopify_id=node['id'])

            if not existing:
                self.env['shopify.sync.log'].log(self.id, node['name'], 'order', 'success', f"Synced order: {node['name']}", shopify_id=node['id'], payload=node)
        except Exception as e:
            _logger.error("Failed to sync order %s: %s", node['name'], str(e))
            self.env['shopify.sync.log'].log(self.id, node['name'], 'order', 'error', str(e), shopify_id=node['id'])
   


    def sync_selected_products(self, shopify_ids):
        """ Sync specific selected products from Shopify """
        self.ensure_one()
        query = """
        query GetProducts($ids: [ID!]!) {
          nodes(ids: $ids) {
            ... on Product {
                id title handle descriptionHtml vendor productType createdAt updatedAt status tags
                images(first: 10) { edges { node { id url altText } } }
                variants(first: 50) { edges { node { id title sku price compareAtPrice inventoryQuantity selectedOptions { name value } } } }
                options { id name values }
            }
          }
        }
        """
        data = self.shopify_graphql_query(query, {'ids': shopify_ids})
        if 'error' in data:
            return {'status': 'error', 'message': str(data['error'])}
        
        nodes = data.get('nodes', [])
        count = 0
        for node in nodes:
            if not node: continue
            try:
                self._process_shopify_product_graphql(node)
                count += 1
            except Exception as e:
                _logger.error("Failed to sync selected product %s: %s", node.get('title'), str(e))
                self.env['shopify.sync.log'].log(self.id, node.get('title', 'Unknown'), 'product', 'error', str(e), shopify_id=node.get('id'))
        
        return {'status': 'success', 'synced_count': count}

    def push_fulfillment_to_shopify(self, picking):
        """ Push tracking info and fulfill order in Shopify via GraphQL """
        self.ensure_one()
        sale_order = picking.sale_id
        if not sale_order or not sale_order.shopify_order_id:
            return False
            
        shopify_order_id = sale_order.shopify_order_id
        
        # 1. Get Fulfillment Order ID (Required for GraphQL fulfillment)
        query_fo = """
        query getFulfillmentOrders($orderId: ID!) {
          order(id: $orderId) {
            fulfillmentOrders(first: 5, displayable: true) {
              nodes {
                id
                status
              }
            }
          }
        }
        """
        fo_data = self.shopify_graphql_query(query_fo, {'orderId': shopify_order_id})
        if 'error' in fo_data:
            _logger.error("Failed to fetch fulfillment orders for %s: %s", sale_order.name, fo_data['error'])
            return False
            
        fo_nodes = fo_data.get('order', {}).get('fulfillmentOrders', {}).get('nodes', [])
        # Find an OPEN fulfillment order that can be processed
        fo_id = False
        for fo in fo_nodes:
            if fo['status'] == 'OPEN':
                fo_id = fo['id']
                break
        
        if not fo_id:
            _logger.warning("No OPEN fulfillment order found for Shopify Order %s. It might already be fulfilled.", sale_order.name)
            return False

        # 2. Create Fulfillment in Shopify
        tracking_number = picking.carrier_tracking_ref
        tracking_url = picking.carrier_id.get_tracking_link(picking) if picking.carrier_id and hasattr(picking.carrier_id, 'get_tracking_link') else False
        tracking_company = picking.carrier_id.name if picking.carrier_id else "Other"
        
        fulfillment_payload = {
            'lineItemsByFulfillmentOrder': [
                {
                    'fulfillmentOrderId': fo_id,
                }
            ],
            'notifyCustomer': True
        }

        # Add tracking info only if we have at least a tracking number
        if tracking_number:
            tracking_info = {'number': tracking_number}
            if tracking_url:
                tracking_info['url'] = tracking_url
            if tracking_company:
                tracking_info['company'] = tracking_company
            fulfillment_payload['trackingInfo'] = tracking_info
        
        mutation = """
        mutation fulfillmentCreateV2($fulfillment: FulfillmentV2Input!) {
          fulfillmentCreateV2(fulfillment: $fulfillment) {
            fulfillment { id }
            userErrors { field message }
          }
        }
        """
        variables = {'fulfillment': fulfillment_payload}
        
        res = self.shopify_graphql_query(mutation, variables)
        if 'error' in res:
            _logger.error("Fulfillment creation failed for %s: %s", sale_order.name, res['error'])
            return False
            
        errors = res.get('fulfillmentCreateV2', {}).get('userErrors', [])
        if errors:
            _logger.error("Shopify User Errors during fulfillment for %s: %s", sale_order.name, errors)
            return False
            
        _logger.info("Successfully fulfilled Shopify Order %s from the platform Picking %s", sale_order.name, picking.name)
        return True
    
    def _get_shopify_location_id(self):
        query = """
        query {
          locations(first: 1) {
            nodes {
              id
            }
          }
        }
        """
        res = self.shopify_graphql_query(query)
        if 'error' in res:
            _logger.error(f"Error fetching Shopify locations: {res['error']}")
            return False
        nodes = res.get('locations', {}).get('nodes', [])
        if nodes:
            return nodes[0]['id']
        return False
    
    def _update_shopify_inventory(self, variant, qty):
        """ Sync stock level from the platform to Shopify for a variant """
        if not variant.shopify_variant_id:
            return False
        
        # 1. Fetch inventory item ID for this variant
        query = """
        query getVariantInventoryItem($id: ID!) {
          node(id: $id) {
            ... on ProductVariant {
              inventoryItem {
                id
                tracked
              }
            }
          }
        }
        """
        res = self.shopify_graphql_query(query, {'id': variant.shopify_variant_id})
        if 'error' in res or not res.get('node'):
            _logger.error(f"Failed to fetch inventory item for variant {variant.name}: {res.get('error')}")
            return False
            
        inventory_item = res['node'].get('inventoryItem')
        if not inventory_item or not inventory_item.get('tracked'):
            _logger.info(f"Inventory not tracked for Shopify variant {variant.name}")
            return False
            
        inventory_item_id = inventory_item['id']
        
        # 2. Get Shopify location
        shopify_location_id = self._get_shopify_location_id()
        if not shopify_location_id:
            _logger.error("No active Shopify location found to sync stock.")
            return False
            
        # 3. Set the quantity on Shopify
        mutation = """
        mutation inventorySetQuantities($input: InventorySetQuantitiesInput!) {
          inventorySetQuantities(input: $input) {
            userErrors {
              field
              message
            }
          }
        }
        """
        variables = {
            'input': {
                'name': 'available',
                'reason': 'correction',
                'ignoreCompareQuantity': True,
                'quantities': [{
                    'inventoryItemId': inventory_item_id,
                    'locationId': shopify_location_id,
                    'quantity': int(qty)
                }]
            }
        }
        
        mutate_res = self.shopify_graphql_query(mutation, variables)
        if 'error' in mutate_res:
            _logger.error(f"Failed to update Shopify inventory: {mutate_res['error']}")
            return False
            
        errors = mutate_res.get('inventorySetQuantities', {}).get('userErrors', [])
        if errors:
            _logger.error(f"Shopify inventory update errors: {errors}")
            return False
            
        _logger.info(f"Successfully updated Shopify inventory for variant {variant.name} to {qty}")
        return True
    
    def get_shopify_inventory_paged(self, cursor=None, limit=20, search=None, status=None, sync_status=None, from_date=None, to_date=None, direction='next'):
        self.ensure_one()
        inventory = []
        current_cursor = cursor
        has_next_page = True
        has_previous_page = True

        total_count = 0
        try:
            count_url = f"{self.shop_url}/admin/api/{self.api_version}/products/count.json"
            count_params = {}
            if search: count_params['title'] = search
            count_res = requests.get(count_url, headers=self._get_shopify_headers(), params=count_params, timeout=10)
            if count_res.status_code == 200:
                total_count = count_res.json().get('count', 0)
        except: pass

        while len(inventory) < limit and (has_next_page if direction == 'next' else has_previous_page):
            query_filter = []
            if search: query_filter.append(f'title:{search}*')
            if from_date: query_filter.append(f'updated_at:>{from_date}')
            if to_date: query_filter.append(f'updated_at:<{to_date}')
            filter_str = f', query: "{" ".join(query_filter)}"' if query_filter else ""
            
            # Query products, their variants and their Shopify stock
            query = """
            query GetInventory($first: Int, $after: String, $last: Int, $before: String) {
              products(first: $first, after: $after, last: $last, before: $before, reverse: true%s) {
                pageInfo { hasNextPage endCursor hasPreviousPage startCursor }
                nodes {
                  id
                  title
                  images(first: 1) { edges { node { url } } }
                  variants(first: 50) {
                    edges {
                      node {
                        id
                        title
                        sku
                        inventoryQuantity
                        inventoryItem {
                          id
                          inventoryLevels(first: 10) {
                            nodes {
                              quantities(names: ["available", "on_hand"]) {
                                name
                                quantity
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
            """ % filter_str

            variables = {'first': None, 'after': None, 'last': None, 'before': None}
            if direction == 'next':
                variables.update({'first': min(limit, 50), 'after': current_cursor})
            else:
                variables.update({'last': min(limit, 50), 'before': current_cursor})

            data = self.shopify_graphql_query(query, variables)
            if 'error' in data: return {'status': 'error', 'message': str(data['error'])}
            shopify_data = data.get('products', {})
            nodes = shopify_data.get('nodes', [])
            page_info = shopify_data.get('pageInfo', {})
            has_next_page = page_info.get('hasNextPage', False)
            has_previous_page = page_info.get('hasPreviousPage', False)            
            current_cursor = page_info.get('endCursor') if direction == 'next' else page_info.get('startCursor')

            # Extract variant IDs
            variant_edges = []
            for node in nodes:
                image_url = node['images']['edges'][0]['node']['url'] if node['images']['edges'] else False
                for edge in node.get('variants', {}).get('edges', []):
                    variant_edges.append((node['id'], node['title'], image_url, edge['node']))

            shopify_var_ids = [v[3]['id'] for v in variant_edges]
            shopify_var_skus = [v[3]['sku'] for v in variant_edges if v[3].get('sku')]
            shopify_prod_ids = [v[0] for v in variant_edges]
            
            # Find matching synced variants in the platform by shopify_variant_id OR SKU fallback
            context = {}
            if self.location_id:
                context['location'] = self.location_id.id
            elif self.warehouse_id:
                context['warehouse'] = self.warehouse_id.id
                
            odoo_variants = self.env['product.product'].with_context(**context).search([
                '|',
                ('shopify_variant_id', 'in', shopify_var_ids),
                '&', ('default_code', 'in', shopify_var_skus), ('default_code', '!=', False)
            ])
            
            odoo_var_map = {}
            for v in odoo_variants:
                if v.shopify_variant_id:
                    odoo_var_map[v.shopify_variant_id] = v
                if v.default_code:
                    odoo_var_map[v.default_code] = v

            odoo_templates = self.env['product.template'].search([('shopify_product_id', 'in', shopify_prod_ids)])
            odoo_tmpl_map = {t.shopify_product_id: t for t in odoo_templates}

            for prod_id, parent_title, image_url, var_node in variant_edges:
                var_id = var_node['id']
                var_sku = var_node.get('sku')
                odoo_var = odoo_var_map.get(var_id)
                if not odoo_var and var_sku:
                    odoo_var = odoo_var_map.get(var_sku)
                if not odoo_var:
                    template = odoo_tmpl_map.get(prod_id)
                    if template and len(template.product_variant_ids) == 1:
                        odoo_var = template.product_variant_ids[0]
                        
                if odoo_var and not odoo_var.shopify_variant_id:
                    # Automatically write shopify_variant_id to map it permanently!
                    odoo_var.sudo().write({'shopify_variant_id': var_id})
                    odoo_var_map[var_id] = odoo_var
                
                # Check sync status
                is_synced = odoo_var is not None
                if sync_status == 'synced' and not is_synced: continue
                if sync_status == 'not_synced' and is_synced: continue

                odoo_stock = float(odoo_var.virtual_available) if odoo_var else 0.0
                odoo_onhand = float(odoo_var.qty_available) if odoo_var else 0.0
                available_qty = 0.0
                on_hand_qty = 0.0
                inv_item = var_node.get('inventoryItem')
                if inv_item:
                    levels = inv_item.get('inventoryLevels', {}).get('nodes', [])
                    for level in levels:
                        for qty_item in level.get('quantities', []):
                            if qty_item['name'] == 'available':
                                available_qty += float(qty_item['quantity'] or 0)
                            elif qty_item['name'] == 'on_hand':
                                on_hand_qty += float(qty_item['quantity'] or 0)
                                
                if available_qty == 0.0 and on_hand_qty == 0.0:
                    available_qty = float(var_node.get('inventoryQuantity') or 0.0)
                    on_hand_qty = float(var_node.get('inventoryQuantity') or 0.0)

                shopify_stock = available_qty
                shopify_onhand = on_hand_qty

                # Determine if stocks match
                stocks_match = (odoo_stock == shopify_stock) if is_synced else False

                title = f"{parent_title} - {var_node['title']}" if var_node['title'] != 'Default Title' else parent_title

                inventory.append({
                    'id': var_id,
                    'title': title,
                    'sku': var_node.get('sku') or 'N/A',
                    'image_url': image_url,
                    'odoo_stock': odoo_stock,
                    'odoo_onhand': odoo_onhand,
                    'shopify_stock': shopify_stock,
                    'shopify_onhand': shopify_onhand,
                    'master_inventory': self.master_inventory or 'shopify',
                    'is_synced': stocks_match
                })
                if len(inventory) == limit: break
            if not nodes: break

        return {
            'status': 'success',
            'inventory': inventory,
            'totalCount': total_count,
            'pageInfo': {
                'hasNextPage': has_next_page,
                'endCursor': page_info.get('endCursor'),
                'hasPreviousPage': has_previous_page,
                'startCursor': page_info.get('startCursor')
            }
        }

    def sync_selected_inventory(self, shopify_ids):
        """ Sync stock level for selected variants based on master inventory setting """
        self.ensure_one()
        count = 0
        if self.master_inventory == 'shopify':
            # Shopify to the platform: Query variants from Shopify and update the platform
            query = """
            query GetVariants($ids: [ID!]!) {
              nodes(ids: $ids) {
                ... on ProductVariant {
                  id
                  title
                  sku
                  inventoryQuantity
                  product {
                    id
                  }
                }
              }
            }
            """
            data = self.shopify_graphql_query(query, {'ids': shopify_ids})
            if 'error' in data: return {'status': 'error', 'message': str(data['error'])}
            nodes = data.get('nodes', [])
            for node in nodes:
                if not node: continue
                try:
                    # Find variant in the platform by shopify_variant_id or SKU fallback
                    variant = self.env['product.product'].search([
                        ('shopify_variant_id', '=', node['id'])
                    ], limit=1)
                    if not variant and node.get('sku'):
                        variant = self.env['product.product'].search([
                            ('default_code', '=', node['sku'])
                        ], limit=1)
                    if not variant and node.get('product', {}).get('id'):
                        template = self.env['product.template'].search([('shopify_product_id', '=', node['product']['id'])], limit=1)
                        if template and len(template.product_variant_ids) == 1:
                            variant = template.product_variant_ids[0]
                            
                    if variant:
                        if not variant.shopify_variant_id:
                            variant.write({'shopify_variant_id': node['id']})
                            
                    if variant:
                        self._update_odoo_inventory(variant, node.get('inventoryQuantity', 0))
                        # Create Success Log
                        self.env['shopify.sync.log'].log(
                            self.id, variant.name, 'inventory', 'success', 
                            f"Synced stock level from Shopify to the platform: {node.get('inventoryQuantity', 0)}",
                            shopify_id=node.get('id'), res_model='product.product', res_id=variant.id,
                            payload=node
                        )
                        count += 1
                except Exception as e:
                    _logger.error(f"Failed to sync the platform stock for Shopify variant {node.get('sku')}: {str(e)}")
                    self.env['shopify.sync.log'].log(
                        self.id, node.get('sku', 'Unknown'), 'inventory', 'error', 
                        f"Failed Shopify->the platform stock sync: {str(e)}", shopify_id=node.get('id')
                    )
        else:
            # the platform to Shopify: Get stock from the platform and update Shopify
            context = {}
            if self.location_id:
                context['location'] = self.location_id.id
            elif self.warehouse_id:
                context['warehouse'] = self.warehouse_id.id
            
            # Find matching by shopify_variant_id first
            variants = self.env['product.product'].with_context(**context).search([
                ('shopify_variant_id', 'in', shopify_ids)
            ])
            # For shopify_ids that aren't mapped, try SKU matching
            mapped_ids = variants.mapped('shopify_variant_id')
            unmapped_ids = list(set(shopify_ids) - set(mapped_ids))
            if unmapped_ids:
                # We need to query Shopify to get their SKUs so we can match
                query = """
                query GetVariants($ids: [ID!]!) {
                  nodes(ids: $ids) {
                    ... on ProductVariant {
                      id
                      sku
                      product {
                        id
                      }
                    }
                  }
                }
                """
                data = self.shopify_graphql_query(query, {'ids': unmapped_ids})
                if 'error' not in data:
                    for node in data.get('nodes', []):
                        if node:
                            v = self.env['product.product'].with_context(**context).search([
                                ('shopify_variant_id', '=', node['id'])
                            ], limit=1)
                            if not v and node.get('sku'):
                                v = self.env['product.product'].with_context(**context).search([
                                    ('default_code', '=', node['sku'])
                                ], limit=1)
                            if not v and node.get('product', {}).get('id'):
                                template = self.env['product.template'].search([('shopify_product_id', '=', node['product']['id'])], limit=1)
                                if template and len(template.product_variant_ids) == 1:
                                    v = template.product_variant_ids[0]
                            if v:
                                if not v.shopify_variant_id:
                                    v.write({'shopify_variant_id': node['id']})
                                variants |= v

            for variant in variants:
                try:
                    qty = variant.virtual_available
                    success = self._update_shopify_inventory(variant, qty)
                    if success:
                        payload = {
                            'shopify_variant_id': variant.shopify_variant_id,
                            'sku': variant.default_code,
                            'qty_synced': qty,
                            'direction': 'the platform to Shopify'
                        }
                        # Create Success Log
                        self.env['shopify.sync.log'].log(
                            self.id, variant.name, 'inventory', 'success', 
                            f"Synced stock level from the platform to Shopify: {qty}",
                            shopify_id=variant.shopify_variant_id, res_model='product.product', res_id=variant.id,
                            payload=payload
                        )
                        count += 1
                except Exception as e:
                    _logger.error(f"Failed to sync Shopify stock for the platform variant {variant.default_code}: {str(e)}")
                    self.env['shopify.sync.log'].log(
                        self.id, variant.default_code or 'Unknown', 'inventory', 'error', 
                        f"Failed the platform->Shopify stock sync: {str(e)}", shopify_id=variant.shopify_variant_id
                    )

        return {'status': 'success', 'synced_count': count}


