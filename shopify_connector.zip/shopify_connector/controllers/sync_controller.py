from odoo import http, _
from odoo.http import request
import logging

_logger = logging.getLogger(__name__)

class ShopifySyncController(http.Controller):

    @http.route('/shopify/sync/products', type='jsonrpc', auth='user')
    def sync_shopify_products(self, instance_id=None, cursor=None, limit=10):
        """
        Batch-wise product synchronization via GraphQL
        """
        if not instance_id:
            return {'status': 'error', 'message': _("No instance specified.")}
        try:
            instance = request.env['shopify.instance'].browse(int(instance_id))
        except (ValueError, TypeError):
            return {'status': 'error', 'message': _("Invalid instance ID.")}
        if not instance.exists():
            return {'status': 'error', 'message': _("Instance not found.")}
            
        try:
            result = instance.sync_products_graphql(cursor=cursor, limit=limit)
            
            # Fetch latest logs for this instance to show in the UI
            logs = request.env['shopify.sync.log'].search_read(
                [('instance_id', '=', instance.id)], 
                ['name', 'sync_type', 'state', 'message', 'create_date', 'payload'],
                limit=10, order='create_date desc'
            )
            
            result['logs'] = logs
            return result
        except Exception as e:
            _logger.exception("Error during Shopify sync controller call")
            return {'status': 'error', 'message': str(e)}

    @http.route('/shopify/sync/logs', type='jsonrpc', auth='user')
    def get_sync_logs(self, instance_id=None, limit=20, search=None, status=None, sync_type=None, from_date=None,
                      to_date=None):
        if not instance_id:
            return []
        try:
            instance_id = int(instance_id)
        except (ValueError, TypeError):
            return []

        domain = [('instance_id', '=', instance_id)]
        if search:
            domain += ['|', ('name', 'ilike', search), ('message', 'ilike', search)]
        if status:
            domain += [('state', '=', status)]
        if sync_type:
            domain += [('sync_type', '=', sync_type)]
        if from_date:
            domain += [('create_date', '>=', from_date)]
        if to_date:
            domain += [('create_date', '<=', to_date)]

        logs = request.env['shopify.sync.log'].search_read(
            domain,
            ['name', 'sync_type', 'state', 'message', 'payload', 'create_date'],
            limit=int(limit or 50), order='create_date desc'
        )
        return logs

    @http.route('/shopify/get/products', type='jsonrpc', auth='user')
    def get_shopify_products(self, instance_id=None, cursor=None, limit=20, search=None, status=None, sync_status=None, from_date=None, to_date=None, direction='next'):
        if not instance_id:
            return {'status': 'error', 'message': _("No instance specified.")}
        try:
            instance = request.env['shopify.instance'].browse(int(instance_id))
        except (ValueError, TypeError):
            return {'status': 'error', 'message': _("Invalid instance ID.")}
        return instance.get_shopify_products_paged(cursor=cursor, limit=int(limit or 20), search=search, status=status, sync_status=sync_status, from_date=from_date, to_date=to_date, direction=direction)

    @http.route('/shopify/get/customers', type='jsonrpc', auth='user')
    def get_shopify_customers(self, instance_id=None, cursor=None, limit=20, search=None, status=None, sync_status=None, from_date=None, to_date=None, direction='next'):
        if not instance_id:
            return {'status': 'error', 'message': _("No instance specified.")}
        try:
            instance = request.env['shopify.instance'].browse(int(instance_id))
        except (ValueError, TypeError):
            return {'status': 'error', 'message': _("Invalid instance ID.")}
        return instance.get_shopify_customers_paged(cursor=cursor, limit=int(limit or 20), search=search, status=status, sync_status=sync_status, from_date=from_date, to_date=to_date, direction=direction)

    @http.route('/shopify/get/orders', type='jsonrpc', auth='user')
    def get_shopify_orders(self, instance_id=None, cursor=None, limit=20, search=None, status=None, sync_status=None, from_date=None, to_date=None, direction='next'):
        if not instance_id:
            return {'status': 'error', 'message': _("No instance specified.")}
        try:
            instance = request.env['shopify.instance'].browse(int(instance_id))
        except (ValueError, TypeError):
            return {'status': 'error', 'message': _("Invalid instance ID.")}
        # All statuses go through draftOrders API:
        # 'all' → no filter (all draft orders)
        # 'draft' → OPEN/pending draft orders
        # 'completed' → COMPLETED draft orders
        draft_status = None if not status or status == 'all' else status
        return instance.get_shopify_draft_orders_paged(
            cursor=cursor, limit=int(limit or 20), search=search,
            status=draft_status, sync_status=sync_status,
            from_date=from_date, to_date=to_date, direction=direction
        )
    @http.route('/shopify/get/inventory', type='jsonrpc', auth='user')
    def get_shopify_inventory(self, instance_id=None, cursor=None, limit=20, search=None, status=None, sync_status=None, from_date=None, to_date=None, direction='next'):
        if not instance_id:
            return {'status': 'error', 'message': _("No instance specified.")}
        try:
            instance = request.env['shopify.instance'].browse(int(instance_id))
        except (ValueError, TypeError):
            return {'status': 'error', 'message': _("Invalid instance ID.")}
        return instance.get_shopify_inventory_paged(cursor=cursor, limit=int(limit or 20), search=search, status=status, sync_status=sync_status, from_date=from_date, to_date=to_date, direction=direction)

    @http.route('/shopify/sync/selected', type='jsonrpc', auth='user')
    def sync_selected(self, instance_id=None, shopify_ids=None, entity_type='product'):
        if not instance_id:
            return {'status': 'error', 'message': _("No instance specified.")}
        try:
            instance = request.env['shopify.instance'].browse(int(instance_id))
        except (ValueError, TypeError):
            return {'status': 'error', 'message': _("Invalid instance ID.")}
        if entity_type == 'customer':
            return instance.sync_selected_customers(shopify_ids)
        elif entity_type == 'order':
            return instance.sync_selected_orders(shopify_ids)
        elif entity_type == 'draft_order':
            return instance.sync_selected_draft_orders(shopify_ids)
        elif entity_type == 'inventory':
            return instance.sync_selected_inventory(shopify_ids)
        return instance.sync_selected_products(shopify_ids)

    @http.route('/shopify/get/config', type='jsonrpc', auth='user')
    def get_instance_config(self, instance_id=None):
        if not instance_id:
            return {}
        try:
            instance = request.env['shopify.instance'].browse(int(instance_id))
            if not instance.exists():
                return {}
            return {
                'csv_import_enabled': instance.csv_import_enabled,
                'name': instance.name,
                'state': instance.state,
                'pricelist': instance.pricelist_id.name if instance.pricelist_id else 'None'
            }
        except Exception:
            return {}
