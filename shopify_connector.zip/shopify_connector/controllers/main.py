from odoo import http, _
from odoo.http import request
import requests
import logging

_logger = logging.getLogger(__name__)

class ShopifyAuthController(http.Controller):

    @http.route('/auth', type='http', auth='public', csrf=False)
    def shopify_auth(self, **kwargs):
        _logger.info("Shopify Auth Redirect received with params: %s", kwargs)
        code = kwargs.get('code')
        state = kwargs.get('state') 
        shop = kwargs.get('shop')
        
        if not code:
            return _("Error: No code received from Shopify.")
            
        instance = False
        if state:
            try:
                instance = request.env['shopify.instance'].sudo().browse(int(state))
            except:
                pass
        
        if not instance and shop:
            shop_clean = shop.replace('https://', '').replace('http://', '').strip('/')
            instance = request.env['shopify.instance'].sudo().search([
                '|', ('shop_url', 'ilike', shop_clean), ('shop_url', 'ilike', shop)
            ], limit=1)
            
        if not instance:
            return _("Error: No Shopify Instance found for shop %s.", shop)

        # Get Global Configs
        # third_party_url = request.env['ir.config_parameter'].sudo().get_param('shopify_connector.shopify_third_party_url')
        # client_id = request.env['ir.config_parameter'].sudo().get_param('shopify_connector.shopify_client_id')
        # client_secret = request.env['ir.config_parameter'].sudo().get_param('shopify_connector.shopify_client_secret')
        #config = request.env['ir.config_parameter'].sudo()
        third_party_url = instance.shopify_third_party_uri
        # 🔥 PRIORITY: Instance → Fallback: Global
        client_id = instance.shopify_client_id 
        client_secret = instance.shopify_client_secret 
        
        if third_party_url:
            # Exchange code via Third Party
            try:
                _logger.info("Sending code to third party for exchange: %s", third_party_url)
                response = requests.post(f"{third_party_url.strip('/')}/exchange", json={
                    'code': code,
                    'shop': shop,
                    'client_id': client_id,
                    'client_secret': client_secret
                }, timeout=15)
                
                if response.status_code == 200:
                    # Trigger token fetch to confirm connection
                    instance.get_access_token()
                    instance.write({'state': 'connected'})
                    base_url = request.env['ir.config_parameter'].sudo().get_param('web.base.url')
                    return request.redirect(f"{base_url}/odoo/shopify.instance/{instance.id}")
                else:
                    return _("Third party exchange failed: %s", response.text)
            except Exception as e:
                return _("Error during third party exchange: %s", str(e))
        else:
            # Direct exchange (Legacy / Fallback)
            token_url = f"https://{shop}/admin/oauth/access_token"
            payload = {
                'client_id': client_id,
                'client_secret': client_secret,
                'code': code
            }
            try:
                response = requests.post(token_url, data=payload, timeout=15)
                if response.status_code == 200:
                    data = response.json()
                    instance.write({
                        'shopify_access_token': data.get('access_token'),
                        'state': 'connected'
                    })
                    base_url = request.env['ir.config_parameter'].sudo().get_param('web.base.url')
                    return request.redirect(f"{base_url}/odoo/shopify.instance/{instance.id}")
                else:
                    return _("Direct exchange failed: %s", response.text)
            except Exception as e:
                return _("Error during direct exchange: %s", str(e))

    @http.route('/shopify/auth_callback', type='http', auth='public', csrf=False)
    def shopify_auth_callback(self, **kwargs):
        """ 
        Endpoint called by the PHP Bridge after a successful token storage.
        It triggers the platform to fetch the token and finalize connection.
        """
        instance_id = kwargs.get('instance_id')
        if not instance_id:
            return _("Error: Missing instance_id in callback.")
            
        instance = request.env['shopify.instance'].sudo().browse(int(instance_id))
        if not instance.exists():
            return _("Error: Shopify Instance not found.")

        _logger.info("Handling Shopify Auth Callback for instance %s", instance.name)
        
        try:
            # 1. Fetch token from bridge
            token = instance.get_access_token()
            if not token:
                return _("Error: Could not fetch access token from bridge. Please check your PHP bridge logs.")
            
            # 2. Test connection and update state
            instance.test_connection()
            
            # 3. Redirect back to the instance form view
            base_url = request.env['ir.config_parameter'].sudo().get_param('web.base.url')
            # In the platform+, the URL usually follows this pattern
            return request.redirect(f"{base_url}/odoo/action-shopify_connector.action_shopify_instance/{instance.id}")
        except Exception as e:
            _logger.exception("Error in auth_callback")
            return _("Error during callback processing: %s", str(e))
