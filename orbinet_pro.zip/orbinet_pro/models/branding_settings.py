# -*- coding: utf-8 -*-
import base64

from odoo import api, fields, models
from odoo.exceptions import ValidationError


class ResCompany(models.Model):
    _inherit = "res.company"

    # These fields are deliberately non-stored. The uploaded files are persisted
    # in ir.attachment, avoiding missing-column failures while the module is being
    # installed or upgraded and the registry already contains this Python code.
    web_enterprise_logo = fields.Image(
        string="Enterprise Logo",
        compute="_compute_web_enterprise_brand_images",
        inverse="_inverse_web_enterprise_logo",
        store=False,
        max_width=2048,
        max_height=2048,
        help="Upload a PNG, JPEG, GIF, or WebP logo. The file is stored securely as an the platform attachment.",
    )
    web_enterprise_icon = fields.Image(
        string="Enterprise App Icon",
        compute="_compute_web_enterprise_brand_images",
        inverse="_inverse_web_enterprise_icon",
        store=False,
        max_width=512,
        max_height=512,
        help="Upload a square PNG, JPEG, GIF, or WebP icon. PNG or WebP is recommended.",
    )

    def _brand_attachment(self, field_name):
        self.ensure_one()
        return self.env["ir.attachment"].sudo().search(
            [
                ("res_model", "=", "res.company"),
                ("res_id", "=", self.id),
                ("res_field", "=", field_name),
            ],
            limit=1,
        )

    @api.depends_context("company")
    def _compute_web_enterprise_brand_images(self):
        Attachment = self.env["ir.attachment"].sudo()
        attachments = Attachment.search(
            [
                ("res_model", "=", "res.company"),
                ("res_id", "in", self.ids),
                ("res_field", "in", ["web_enterprise_logo", "web_enterprise_icon"]),
            ]
        ) if self.ids else Attachment
        mapped = {(att.res_id, att.res_field): att.datas for att in attachments}
        for company in self:
            company.web_enterprise_logo = mapped.get((company.id, "web_enterprise_logo"), False)
            company.web_enterprise_icon = mapped.get((company.id, "web_enterprise_icon"), False)

    @staticmethod
    def _detect_image_type(encoded_value):
        if not encoded_value:
            return None
        try:
            raw = base64.b64decode(encoded_value)
        except Exception as exc:
            raise ValidationError("The uploaded branding file is not a valid image.") from exc
        if raw.startswith(b"\x89PNG\r\n\x1a\n"):
            return "png", "image/png"
        if raw.startswith(b"\xff\xd8\xff"):
            return "jpg", "image/jpeg"
        if raw.startswith((b"GIF87a", b"GIF89a")):
            return "gif", "image/gif"
        if len(raw) >= 12 and raw[:4] == b"RIFF" and raw[8:12] == b"WEBP":
            return "webp", "image/webp"
        raise ValidationError("Unsupported image format. Upload PNG, JPG/JPEG, GIF, or WebP.")

    def _save_brand_attachment(self, field_name, value, label):
        for company in self:
            attachment = company._brand_attachment(field_name)
            if not value:
                attachment.unlink()
                continue
            extension, mimetype = company._detect_image_type(value)
            values = {
                "name": "%s.%s" % (label, extension),
                "type": "binary",
                "datas": value,
                "mimetype": mimetype,
                "res_model": "res.company",
                "res_id": company.id,
                "res_field": field_name,
            }
            if attachment:
                attachment.write(values)
            else:
                self.env["ir.attachment"].sudo().create(values)

    def _inverse_web_enterprise_logo(self):
        for company in self:
            company._save_brand_attachment("web_enterprise_logo", company.web_enterprise_logo, "organisation_logo")

    def _inverse_web_enterprise_icon(self):
        for company in self:
            company._save_brand_attachment("web_enterprise_icon", company.web_enterprise_icon, "app_icon")


class ResConfigSettings(models.TransientModel):
    _inherit = "res.config.settings"
    orbinet_disable_chatter = fields.Boolean(string="Disable chatter system-wide", config_parameter="web_enterprise.disable_chatter", default=False, help="Hide chatter on all backend form pages for every user. Existing messages and activities remain stored.")
    orbinet_branding_enabled = fields.Boolean(string="Enable Orbinet branding", config_parameter="web_enterprise.branding_enabled", default=True, help="Master switch for organisation-owned browser, logo, URL, portal, website, and mail branding.")
    orbinet_branding_portal = fields.Boolean(string="Portal debranding", config_parameter="web_enterprise.branding_portal", default=True, help="Replace promotional wording and links in portal pages.")
    orbinet_branding_sale_portal = fields.Boolean(string="Sale portal debranding", config_parameter="web_enterprise.branding_sale_portal", default=True, help="Replace sale portal promotional wording with organisation branding.")
    orbinet_branding_website = fields.Boolean(string="Website debranding", config_parameter="web_enterprise.branding_website", default=True, help="Apply organisation identity to website and public pages.")
    orbinet_branding_mail = fields.Boolean(string="Mail debranding", config_parameter="web_enterprise.branding_mail", default=True, help="Clean promotional links and wording from outgoing emails.")
    orbinet_branding_backend_menu = fields.Boolean(string="Backend user menu debranding", config_parameter="web_enterprise.branding_backend_menu", default=True, help="Hide Documentation, Support, and publisher account entries from the backend user menu.")
    orbinet_branding_logo_icon = fields.Boolean(string="Browser title, logo and icon", config_parameter="web_enterprise.branding_logo_icon", default=True, help="Use the uploaded organisation logo and app icon across the backend, browser, loading screens, and POS.")
    orbinet_branding_backend_url = fields.Boolean(string="Backend URL alias /admin", config_parameter="web_enterprise.branding_backend_url", default=True, help="Provide /admin as a branded alias for the backend while preserving native routing.")
    orbinet_branding_online = fields.Boolean(string="Disable online publisher notices", config_parameter="web_enterprise.branding_online", default=True, help="Disable online publisher notification calls in Community Edition.")
    orbinet_branding_url_prefix = fields.Char(string="Backend branded URL prefix", config_parameter="web_enterprise.branding_url_prefix", default="/admin")
    orbinet_screen_lock_enabled = fields.Boolean(string="Enable screen lock", config_parameter="web_enterprise.screen_lock_enabled", default=True, help="Show the screen lock in the backend systray and allow users to set or change their local PIN.")
    orbinet_screen_lock_timeout = fields.Integer(string="Auto-lock after (seconds)", config_parameter="web_enterprise.screen_lock_timeout", default=0, help="Automatically lock the screen after this many seconds of inactivity. Set to 0 to disable auto-lock.")
    orbinet_browser_title = fields.Char(string="Browser title", config_parameter="web_enterprise.browser_title", default="Orbinet ERP")
    orbinet_company_website = fields.Char(string="Company website", config_parameter="web_enterprise.company_website", default="https://www.ultrademark.com")
    orbinet_brand_display_name = fields.Char(string="Brand display name", config_parameter="web_enterprise.brand_display_name", default="Ultra Demark Technologies Ltd.", help="Name used when replacing powered-by labels and promotional references.")
    orbinet_powered_by_label = fields.Char(string="Powered by label", config_parameter="web_enterprise.powered_by_label", default="Powered by Ultra Demark Technologies Ltd.")
    orbinet_powered_by_url = fields.Char(string="Powered by URL", config_parameter="web_enterprise.powered_by_url", default="https://www.ultrademark.com")
    orbinet_promotional_label = fields.Char(string="Promotional link label", config_parameter="web_enterprise.promotional_label", default="Ultra Demark Technologies Ltd.", help="Anchor text used when promotional links are rewritten.")
    orbinet_promotional_url = fields.Char(string="Promotional link URL", config_parameter="web_enterprise.promotional_url", default="https://www.ultrademark.com")
    orbinet_communication_footer_label = fields.Char(string="Communication footer label", config_parameter="web_enterprise.communication_footer_label", default="Ultra Demark Technologies Ltd.", help="Label used in outgoing email and footer branding.")
    orbinet_communication_footer_url = fields.Char(string="Communication footer URL", config_parameter="web_enterprise.communication_footer_url", default="https://www.ultrademark.com")


    web_enterprise_logo = fields.Image(related="company_id.web_enterprise_logo", readonly=False)
    web_enterprise_icon = fields.Image(related="company_id.web_enterprise_icon", readonly=False)
