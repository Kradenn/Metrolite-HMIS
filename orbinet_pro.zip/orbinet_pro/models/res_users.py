# Part of the platform. See LICENSE file for full copyright and licensing details.

from odoo import fields, models


class ResUsers(models.Model):
    _inherit = "res.users"

    color_scheme = fields.Selection(related="res_users_settings_id.color_scheme", readonly=False)
    obs_interface_theme = fields.Selection(related="res_users_settings_id.obs_interface_theme", readonly=False)
    obs_theme_preset = fields.Selection(related="res_users_settings_id.obs_theme_preset", readonly=False)
    obs_home_bg_color = fields.Char(related="res_users_settings_id.obs_home_bg_color", readonly=False)
    obs_home_bg_gradient = fields.Char(related="res_users_settings_id.obs_home_bg_gradient", readonly=False)
    obs_icon_gradient_start = fields.Char(related="res_users_settings_id.obs_icon_gradient_start", readonly=False)
    obs_icon_gradient_end = fields.Char(related="res_users_settings_id.obs_icon_gradient_end", readonly=False)
    obs_topnav_bg_color = fields.Char(related="res_users_settings_id.obs_topnav_bg_color", readonly=False)
    obs_topnav_text_color = fields.Char(related="res_users_settings_id.obs_topnav_text_color", readonly=False)
    obs_topnav_hover_color = fields.Char(related="res_users_settings_id.obs_topnav_hover_color", readonly=False)
    obs_topnav_border_color = fields.Char(related="res_users_settings_id.obs_topnav_border_color", readonly=False)

    @property
    def SELF_READABLE_FIELDS(self):
        return super().SELF_READABLE_FIELDS + [
            "color_scheme", "obs_interface_theme", "obs_theme_preset", "obs_home_bg_color", "obs_home_bg_gradient",
            "obs_icon_gradient_start", "obs_icon_gradient_end", "obs_topnav_bg_color",
            "obs_topnav_text_color", "obs_topnav_hover_color", "obs_topnav_border_color",
        ]

    @property
    def SELF_WRITEABLE_FIELDS(self):
        return super().SELF_WRITEABLE_FIELDS + [
            "color_scheme", "obs_interface_theme", "obs_theme_preset", "obs_home_bg_color", "obs_home_bg_gradient",
            "obs_icon_gradient_start", "obs_icon_gradient_end", "obs_topnav_bg_color",
            "obs_topnav_text_color", "obs_topnav_hover_color", "obs_topnav_border_color",
        ]
