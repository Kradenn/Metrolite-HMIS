# -*- coding: utf-8 -*-
"""Enterprise theme profiles with reversible, company-aware activation."""
from odoo import api, fields, models, _
from odoo.exceptions import ValidationError


_HEX = r"^#[0-9A-Fa-f]{6}$"


class WebEnterpriseThemeProfile(models.Model):
    _name = "web.enterprise.theme.profile"
    _description = "Enterprise Theme Profile"
    _order = "active_theme desc, sequence, name, id"

    name = fields.Char(required=True, translate=True)
    sequence = fields.Integer(default=10)
    active = fields.Boolean(default=True)
    active_theme = fields.Boolean(string="Currently Applied", default=False, readonly=True, copy=False)
    company_id = fields.Many2one("res.company", default=lambda self: self.env.company, index=True, required=True)
    description = fields.Text(translate=True)
    primary_color = fields.Char(default="#008A94", required=True)
    secondary_color = fields.Char(default="#263238", required=True)
    accent_color = fields.Char(default="#F39C12", required=True)
    surface_color = fields.Char(default="#FFFFFF", required=True)
    text_color = fields.Char(default="#263238", required=True)
    muted_color = fields.Char(default="#6B7280", required=True)
    navbar_color = fields.Char(default="#263238", required=True)
    sidebar_color = fields.Char(default="#FFFFFF", required=True)
    font_family = fields.Selection([
        ("system", "System UI"), ("inter", "Inter / Sans Serif"),
        ("serif", "Professional Serif"), ("mono", "Monospace"),
    ], default="system", required=True)
    density = fields.Selection([("comfortable", "Comfortable"), ("compact", "Compact")], default="comfortable", required=True)
    border_radius = fields.Selection([("0", "Square"), ("4", "Subtle"), ("8", "Rounded")], default="0", required=True)
    sidebar_width = fields.Integer(default=240)
    custom_css = fields.Text(help="Optional advanced CSS. Use only trusted administrator-authored styles.")
    generated_css = fields.Text(compute="_compute_generated_css")

    @api.constrains("primary_color", "secondary_color", "accent_color", "surface_color", "text_color", "muted_color", "navbar_color", "sidebar_color")
    def _check_colors(self):
        import re
        for record in self:
            for field_name in ("primary_color", "secondary_color", "accent_color", "surface_color", "text_color", "muted_color", "navbar_color", "sidebar_color"):
                if not re.match(_HEX, record[field_name] or ""):
                    raise ValidationError(_("%s must be a six-digit hexadecimal colour such as #008A94.") % record._fields[field_name].string)

    @api.constrains("sidebar_width")
    def _check_sidebar_width(self):
        for record in self:
            if not 180 <= record.sidebar_width <= 420:
                raise ValidationError(_("Sidebar width must be between 180 and 420 pixels."))

    @api.depends("primary_color", "secondary_color", "accent_color", "surface_color", "text_color", "muted_color", "navbar_color", "sidebar_color", "font_family", "density", "border_radius", "sidebar_width", "custom_css")
    def _compute_generated_css(self):
        fonts = {
            "system": "-apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
            "inter": "Inter, 'Segoe UI', Arial, sans-serif",
            "serif": "Georgia, 'Times New Roman', serif",
            "mono": "Consolas, 'Liberation Mono', monospace",
        }
        for record in self:
            compact = "0.75rem" if record.density == "compact" else "1rem"
            record.generated_css = """:root {
 --we-primary: %s; --we-secondary: %s; --we-accent: %s;
 --we-surface: %s; --we-text: %s; --we-muted: %s;
 --we-navbar: %s; --we-sidebar: %s; --we-radius: %spx;
 --we-sidebar-width: %spx; --we-density-space: %s;
 --we-font-family: %s;
}
body.o_web_client { font-family: var(--we-font-family); color: var(--we-text); }
.o_main_navbar { background: var(--we-navbar) !important; }
.o_web_client .o_action_manager { background-color: var(--we-surface); }
.o_web_client .btn-primary { background-color: var(--we-primary); border-color: var(--we-primary); }
.o_web_client .o_apps_sidebar { width: var(--we-sidebar-width); background: var(--we-sidebar); }
.o_web_client .card, .o_web_client .btn, .o_web_client .form-control { border-radius: var(--we-radius); }
%s
""" % (record.primary_color, record.secondary_color, record.accent_color, record.surface_color,
       record.text_color, record.muted_color, record.navbar_color, record.sidebar_color,
       record.border_radius, record.sidebar_width, compact, fonts[record.font_family], record.custom_css or "")

    def action_apply_theme(self):
        for record in self:
            others = self.search([("company_id", "=", record.company_id.id), ("id", "!=", record.id), ("active_theme", "=", True)])
            others.write({"active_theme": False})
            record.active_theme = True
        return {"type": "ir.actions.client", "tag": "reload"}

    def action_deactivate_theme(self):
        self.write({"active_theme": False})
        return {"type": "ir.actions.client", "tag": "reload"}
