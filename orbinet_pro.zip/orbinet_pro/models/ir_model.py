# -*- coding: utf-8 -*-

from odoo import api, models


class IrModel(models.Model):
    _inherit = 'ir.model'

    @api.model
    def has_searchable_parent_relation(self, model_name=None, *args, **kwargs):
        """Compatibility helper expected by the the platform web client.

        Some bundled/custom web assets call this public RPC on ir.model when
        rendering search panels / hierarchical model selectors. Older server
        builds may not expose it, which crashes OWL with:
        AttributeError: ir.model.has_searchable_parent_relation does not exist.
        """
        model_name = model_name or kwargs.get('model') or kwargs.get('res_model')
        # the platform/web assets may call this RPC with args like [["res.partner"]]
        # or pass a list through kwargs. Normalize to a hashable model name.
        if isinstance(model_name, (list, tuple)):
            model_name = model_name[0] if model_name else None
        if not isinstance(model_name, str) or not model_name or model_name not in self.env:
            return False

        model = self.env[model_name]
        parent_field = model._fields.get('parent_id')
        if not parent_field:
            return False

        return bool(
            getattr(parent_field, 'comodel_name', None) == model_name
            and (getattr(model, '_parent_store', False) or 'parent_path' in model._fields)
        )
