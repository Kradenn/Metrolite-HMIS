# -*- coding: utf-8 -*-
# Part of the platform. See LICENSE file for full copyright and licensing details.

from odoo import fields, models


class ResUsersSettings(models.Model):
    _inherit = 'res.users.settings'

    homemenu_config = fields.Json(string="Home Menu Configuration", readonly=True)
    color_scheme = fields.Selection(
        [("system", "System"), ("light", "Light"), ("dark", "Dark")],
        default="system",
        required=True,
        string="Appearance",
    )


    obs_interface_theme = fields.Selection([('default', 'Default'), ('orthodox', 'Orthodox'), ('enterprise', 'Enterprise')], default='default', required=True, string='Interface Theme')

    obs_theme_preset = fields.Selection(
        [
            ("royal_purple", "Royal Purple"),
            ("emerald", "Emerald"),
            ("ocean", "Ocean"),
            ("sunset", "Sunset"),
            ("slate", "Slate"),
            ("custom", "Custom"),
        ],
        default="royal_purple",
        required=True,
        string="Theme Preset",
        help="Per-user theme preset. Choose Custom to manually set colors below.",
    )
    obs_home_bg_color = fields.Char(string="Home Screen Color", default="#55006B")
    obs_home_bg_gradient = fields.Char(string="Home Screen Gradient", default="linear-gradient(135deg, #55006B 0%, #650078 52%, #4A005F 100%)")
    obs_icon_gradient_start = fields.Char(string="Icon Background Start", default="#04965D")
    obs_icon_gradient_end = fields.Char(string="Icon Background End", default="#03445D")
    obs_topnav_bg_color = fields.Char(string="Top Navigation Background", default="#55006B")
    obs_topnav_text_color = fields.Char(string="Top Navigation Text", default="#FFFFFF")
    obs_topnav_hover_color = fields.Char(string="Top Navigation Hover", default="#6D0085")
    obs_topnav_border_color = fields.Char(string="Top Navigation Border", default="#55006B")

    def write(self, vals):
        if not vals.get("color_scheme", "system"):
            vals.pop("color_scheme")
        return super().write(vals)
