# -*- coding: utf-8 -*-
from odoo import models


class MailMail(models.Model):
    _inherit = "mail.mail"

    def _prepare_outgoing_body(self):
        body_html = super()._prepare_outgoing_body()
        return self.env["mail.render.mixin"].orbinet_remove_odoo_links(
            body_html or "", to_keep=self.body
        )
