# -*- coding: utf-8 -*-
"""Provider-neutral AI workspace configuration.

The framework intentionally does not hard-code a vendor. Installed applications
or connector modules register runtime providers through the frontend registry.
"""
import json

from odoo import api, fields, models, _
from odoo.exceptions import ValidationError


class WebEnterpriseAIProfile(models.Model):
    _name = "web.enterprise.ai.profile"
    _description = "Enterprise AI Workspace Profile"
    _order = "sequence, name, id"

    name = fields.Char(required=True, translate=True)
    sequence = fields.Integer(default=10)
    active = fields.Boolean(default=True)
    company_id = fields.Many2one("res.company", default=lambda self: self.env.company, index=True)
    group_ids = fields.Many2many("res.groups", string="Visible to Groups")
    icon = fields.Char(default="fa-magic")
    description = fields.Text(translate=True)
    provider_key = fields.Char(
        string="Provider Adapter Key",
        default="registry",
        required=True,
        help="Technical key of a provider registered by an installed connector. Web Enterprise itself remains vendor-neutral.",
    )
    model_name = fields.Char(string="Model / Engine Label")
    system_prompt = fields.Text(
        default="Assist the user with the current business task. Respect access rights, confidentiality, and the supplied context.",
        translate=True,
    )
    allow_record_context = fields.Boolean(default=True)
    allow_attachment_context = fields.Boolean(default=False)
    allow_write_actions = fields.Boolean(
        default=False,
        help="Provider connectors must still request explicit user confirmation before any write operation.",
    )
    prompt_ids = fields.One2many("web.enterprise.ai.prompt", "profile_id", string="Prompt Templates")
    prompt_count = fields.Integer(compute="_compute_prompt_count")

    @api.depends("prompt_ids")
    def _compute_prompt_count(self):
        for record in self:
            record.prompt_count = len(record.prompt_ids)

    @api.constrains("provider_key")
    def _check_provider_key(self):
        for record in self:
            key = (record.provider_key or "").strip()
            if not key or not all(char.isalnum() or char in "._-" for char in key):
                raise ValidationError(_("Provider adapter keys may contain only letters, numbers, dots, underscores and hyphens."))

    def action_open_workspace(self):
        self.ensure_one()
        return {
            "type": "ir.actions.client",
            "tag": "display_notification",
            "params": {
                "title": _("AI Workspace"),
                "message": _("Open the AI workspace from the navigation bar or press Ctrl+Shift+Space."),
                "type": "info",
                "sticky": False,
            },
        }

    def _is_available_for_user(self):
        self.ensure_one()
        return not self.group_ids or bool(self.group_ids & self.env.user.group_ids)

    def to_workspace_payload(self):
        self.ensure_one()
        if not self._is_available_for_user():
            return False
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description or "",
            "icon": self.icon or "fa-magic",
            "provider_key": self.provider_key,
            "model_name": self.model_name or "",
            "allow_record_context": self.allow_record_context,
            "allow_attachment_context": self.allow_attachment_context,
            "allow_write_actions": self.allow_write_actions,
            "system_prompt": self.system_prompt or "",
            "prompts": [prompt.to_workspace_payload() for prompt in self.prompt_ids.filtered("active")],
        }


class WebEnterpriseAIPrompt(models.Model):
    _name = "web.enterprise.ai.prompt"
    _description = "Enterprise AI Prompt Template"
    _order = "sequence, name, id"

    profile_id = fields.Many2one("web.enterprise.ai.profile", required=True, ondelete="cascade", index=True)
    sequence = fields.Integer(default=10)
    active = fields.Boolean(default=True)
    name = fields.Char(required=True, translate=True)
    code = fields.Char(required=True, copy=False)
    icon = fields.Char(default="fa-commenting-o")
    action_mode = fields.Selection([
        ("assist", "General Assistance"),
        ("summarize", "Summarize"),
        ("draft", "Draft Content"),
        ("analyse", "Analyse"),
        ("extract", "Extract Structured Information"),
        ("next_action", "Recommend Next Action"),
    ], default="assist", required=True)
    model_id = fields.Many2one("ir.model", string="Optional Business Object", ondelete="cascade")
    prompt_template = fields.Text(required=True, translate=True)
    context_schema = fields.Text(
        help="Optional JSON object documenting context values expected by the provider adapter.",
        default="{}",
    )

    _code_unique = models.Constraint(
        "unique(profile_id, code)",
        "Prompt template codes must be unique within each AI profile.",
    )

    @api.constrains("code")
    def _check_code(self):
        for record in self:
            code = (record.code or "").strip()
            if not code or not all(char.isalnum() or char in "._-" for char in code):
                raise ValidationError(_("Prompt codes may contain only letters, numbers, dots, underscores and hyphens."))

    @api.constrains("context_schema")
    def _check_context_schema(self):
        for record in self:
            try:
                value = json.loads(record.context_schema or "{}")
            except (TypeError, ValueError) as error:
                raise ValidationError(_("Context schema must be valid JSON.")) from error
            if not isinstance(value, dict):
                raise ValidationError(_("Context schema must be a JSON object."))

    def to_workspace_payload(self):
        self.ensure_one()
        return {
            "id": self.id,
            "name": self.name,
            "code": self.code,
            "icon": self.icon or "fa-commenting-o",
            "action_mode": self.action_mode,
            "model": self.model_id.model if self.model_id else False,
            "template": self.prompt_template or "",
        }
