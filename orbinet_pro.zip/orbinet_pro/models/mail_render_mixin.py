# -*- coding: utf-8 -*-
import re

from lxml import etree, html
from markupsafe import Markup

from odoo import api, models


def _safe_https_url(value, default="https://www.ultrademark.com"):
    value = (value or "").strip()
    return value if value.lower().startswith("https://") else default


class MailRenderMixin(models.AbstractModel):
    _inherit = "mail.render.mixin"

    def orbinet_remove_odoo_links(self, value, to_keep=None):
        """Remove the platform promotional links from rendered mail while preserving user content."""
        ICP = self.env["ir.config_parameter"].sudo()
        branding_enabled = str(ICP.get_param("web_enterprise.branding_enabled", "True")).lower() in ("1", "true", "yes", "on")
        mail_enabled = str(ICP.get_param("web_enterprise.branding_mail", "True")).lower() in ("1", "true", "yes", "on")
        if not (branding_enabled and mail_enabled):
            return value
        if not value or len(value) < 20:
            return value

        back_to_bytes = isinstance(value, bytes)
        back_to_markup = isinstance(value, Markup)

        if back_to_bytes:
            value = value.decode()

        has_dev_odoo_link = re.search(r"<a\s(.*)dev\.odoo\.com", value, flags=re.IGNORECASE)
        has_odoo_link = re.search(r"<a\s(.*)odoo\.com", value, flags=re.IGNORECASE)

        if has_odoo_link and not has_dev_odoo_link:
            label = ICP.get_param("web_enterprise.communication_footer_label", "Ultra Demark Technologies Ltd.") or "Ultra Demark Technologies Ltd."
            url = _safe_https_url(ICP.get_param("web_enterprise.communication_footer_url", "https://www.ultrademark.com"))
            promo_label = ICP.get_param("web_enterprise.promotional_label", label) or label
            if to_keep:
                value = value.replace(to_keep, "<orbinet_body_msg></orbinet_body_msg>")
            try:
                tree = html.fromstring(value)
                odoo_anchors = tree.xpath('//a[contains(translate(@href, "ODO", "odo"), "odoo.com")]')
                for elem in odoo_anchors:
                    elem.set("href", url)
                    elem.set("title", label)
                    current_label = "".join(elem.itertext()).strip()
                    if not current_label or "odoo" in current_label.lower():
                        elem.text = promo_label
                value = etree.tostring(tree, pretty_print=True, method="html", encoding="unicode")
            except (etree.ParserError, ValueError):
                value = re.sub(r'href=["\'][^"\']*odoo\.com[^"\']*["\']', 'href="%s"' % url, value, flags=re.IGNORECASE | re.DOTALL)
                value = re.sub(r">\s*the platform\s*<", ">%s<" % promo_label, value, flags=re.IGNORECASE)
            if to_keep:
                value = value.replace("<orbinet_body_msg></orbinet_body_msg>", to_keep)

        if back_to_bytes:
            return value.encode()
        if back_to_markup:
            return Markup(value)
        return value

    # Backward-compatible alias for code inherited from mail_debranding.
    def remove_href_odoo(self, value, to_keep=None):
        return self.orbinet_remove_odoo_links(value, to_keep=to_keep)

    @api.model
    def _render_template(
        self,
        template_src,
        model,
        res_ids,
        engine="inline_template",
        add_context=None,
        options=None,
    ):
        rendered = super()._render_template(
            template_src,
            model,
            res_ids,
            engine=engine,
            add_context=add_context,
            options=options,
        )
        for key in res_ids:
            rendered[key] = self.orbinet_remove_odoo_links(rendered[key])
        return rendered
