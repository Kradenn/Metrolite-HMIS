# -*- coding: utf-8 -*-
# Part of the platform. See LICENSE file for full copyright and licensing details.

from . import ir_http
from . import ir_model
# Load res.users.settings before res.users because res.users exposes related fields
# pointing to the custom theme fields defined on res.users.settings.
from . import res_users_settings
from . import res_users

from . import experience_settings
from . import branding_settings
from . import mail_mail
from . import mail_render_mixin
from . import publisher_warranty_contract


from . import res_config_settings_upgrade_cleanup


from . import layout_designer

from . import dashboard_designer

from . import theme_designer

from . import ai_workspace
from . import extension_manager
