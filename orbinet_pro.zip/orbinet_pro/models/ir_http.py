# -*- coding: utf-8 -*-

from markupsafe import Markup

from odoo import models
from odoo.http import request


def _orbinet_website_control_trackers(self, html):
    """Optional Website compatibility helper.

    Kept in web_enterprise without depending on website. If the Website app is
    installed and mixed the platform templates expect this helper, public pages keep
    rendering normally. If Website is not installed, nothing is loaded or forced.
    """
    return Markup(html or "")


def _orbinet_website_should_remove_trackers(self):
    return False


class IrHttp(models.AbstractModel):
    _inherit = 'ir.http'

    @classmethod
    def _orbinet_patch_optional_website_model(cls):
        """Patch Website helpers only when the optional website model exists.

        the platform calls ir.http._dispatch as a class-level routing hook. Keeping
        this helper class-level avoids breaking /web, /websocket and public
        routes while still avoiding a hard dependency on website.
        """
        try:
            env = request.env
            if not env or 'website' not in env.registry:
                return
            website_cls = type(env['website'])
            if not hasattr(website_cls, '_control_third_party_trackers_in_html'):
                setattr(website_cls, '_control_third_party_trackers_in_html', _orbinet_website_control_trackers)
            if not hasattr(website_cls, '_should_remove_third_party_trackers'):
                setattr(website_cls, '_should_remove_third_party_trackers', _orbinet_website_should_remove_trackers)
        except Exception:
            return

    @classmethod
    def _dispatch(cls, endpoint):
        cls._orbinet_patch_optional_website_model()
        return super()._dispatch(endpoint)

    @classmethod
    def _post_logout(cls):
        super()._post_logout()
        request.future_response.set_cookie('color_scheme', max_age=0)

    def color_scheme(self):
        cookie_scheme = request.httprequest.cookies.get('color_scheme')
        scheme = cookie_scheme if cookie_scheme else super().color_scheme()
        user = request.env.user
        if user and not user._is_public():
            user_scheme = user.res_users_settings_id.color_scheme
            if user_scheme in ('light', 'dark'):
                return user_scheme
        return scheme
