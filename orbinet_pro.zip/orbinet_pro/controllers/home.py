# -*- coding: utf-8 -*-
import json
import re
from html import escape
from odoo.addons.web.controllers import home as web_home
from odoo.http import Response, request, route
BRAND_TITLE = 'Orbinet ERP'
BRAND_COMPANY = 'Ultra Demark Technologies Ltd.'
BRAND_URL = 'https://www.ultrademark.com'
def _icp():
    return request.env['ir.config_parameter'].sudo()

def _param(key, default=''):
    try:
        return _icp().get_param('web_enterprise.' + key, default) or default
    except Exception:
        return default

def _brand_value(key, default=''):
    return _param(key, default)

def _bool_param(key, default=True):
    value = str(_param(key, 'True' if default else 'False')).lower()
    return value in ('1', 'true', 'yes', 'on')

def _branding_enabled(feature=None, default=True):
    if not _bool_param('branding_enabled', True):
        return False
    if feature:
        return _bool_param(feature, default)
    return True

def _safe_public_url(value, default=BRAND_URL, allow_relative=True):
    """Return only HTTPS or local relative URLs for browser-facing links."""
    value = (value or '').strip()
    if not value:
        return default
    lowered = value.lower()
    if lowered.startswith('https://'):
        return value
    if allow_relative and value.startswith('/') and (not value.startswith('//')):
        return value
    return default

def _brand_asset_urls():
    """Return company-owned attachment URLs; no copied external image URL is used."""
    company = request.env.company.sudo()
    stamp = str(company.write_date or "").replace(" ", "_").replace(":", "-")
    logo_field = "web_enterprise_logo" if company.web_enterprise_logo else "logo"
    icon_field = "web_enterprise_icon" if company.web_enterprise_icon else logo_field
    base = "/web/image/res.company/%s" % company.id
    return (
        "%s/%s?unique=%s" % (base, logo_field, stamp),
        "%s/%s?unique=%s" % (base, icon_field, stamp),
    )


def _inject_head_branding(html):
    """Ensure first-paint title and uploaded company assets before JS loads."""
    if not _branding_enabled('branding_logo_icon', True):
        return html
    brand_title = _brand_value('browser_title', BRAND_TITLE)
    safe_title = escape(brand_title, quote=True)
    logo_url, icon_url = _brand_asset_urls()
    if not re.search('<title[\\s>]', html, flags=re.I):
        html = re.sub('<head([^>]*)>', f'<head\\1><title>{safe_title}</title>', html, count=1, flags=re.I)
    html = re.sub('<title[^>]*>.*?</title>', f'<title>{safe_title}</title>', html, flags=re.I | re.S)
    html = re.sub('<meta([^>]+name=["\\\']application-name["\\\'][^>]*)>', '', html, flags=re.I)
    html = re.sub('<link[^>]+rel=["\\\'][^"\\\']*(?:shortcut\\s+icon|icon|apple-touch-icon)[^"\\\']*["\\\'][^>]*>', '', html, flags=re.I)
    config = {"title": brand_title, "logoUrl": logo_url, "iconUrl": icon_url}
    safe_config_json = json.dumps(config).replace('</', '<\\/')
    early_script = (
        "<script data-orbinet-early-branding=\"1\">"
        "(function(){try{var c=window.__webEnterpriseBrandConfig||{};"
        "document.title=c.title||document.title;var h=document.head;if(h){"
        "document.querySelectorAll('link[rel~=icon],link[rel=\"shortcut icon\"],link[rel=\"apple-touch-icon\"]').forEach(function(e){e.remove();});"
        "['icon','shortcut icon','apple-touch-icon'].forEach(function(r){var e=document.createElement('link');e.rel=r;e.href=c.iconUrl;h.appendChild(e);});"
        "var st=document.documentElement.style;st.setProperty('--web-enterprise-logo-url','url(\\\"'+c.logoUrl+'\\\")');"
        "st.setProperty('--web-enterprise-icon-url','url(\\\"'+c.iconUrl+'\\\")');"
        "}}catch(e){}})();</script>"
    )
    head_bits = (
        f'<meta name="application-name" content="{safe_title}">'
        f'<link rel="icon" href="{icon_url}">'
        f'<link rel="shortcut icon" href="{icon_url}">'
        f'<link rel="apple-touch-icon" href="{icon_url}">'
        '<link rel="stylesheet" href="/web_enterprise/theme.css" data-web-enterprise-theme="1">'
        f'<script data-web-enterprise-brand-config="1">window.__webEnterpriseBrandConfig={safe_config_json};window.__webEnterpriseBrandTitle=window.__webEnterpriseBrandConfig.title;</script>'
    )
    if 'data-orbinet-early-branding' not in html:
        head_bits += early_script
    html = re.sub('<head([^>]*)>', f'<head\\1>{head_bits}', html, count=1, flags=re.I)
    return html

def _render_response_now(response):
    """Materialize lazy QWeb responses so HTML can be branded before first byte."""
    try:
        if hasattr(response, 'flatten'):
            response.flatten()
    except Exception:
        pass
    return response

def _replace_html_branding(html):
    if not html:
        return html
    html = _inject_head_branding(html)
    if not _branding_enabled():
        return html
    path = getattr(getattr(request, 'httprequest', None), 'path', '') or ''
    is_login = '/web/login' in path or 'oe_login_form' in html or 'o_login_form' in html
    is_portal = '/my' in path or 'o_portal' in html
    is_website = not path.startswith(('/web', '/admin'))
    allow_login_branding = False
    allow_portal = is_portal and _branding_enabled('branding_portal', True)
    allow_website = is_website and _branding_enabled('branding_website', True)
    if not (allow_portal or allow_website):
        return html
    brand_title = _brand_value('browser_title', BRAND_TITLE)
    brand_name = _brand_value('brand_display_name', BRAND_COMPANY)
    company_url = _safe_public_url(_brand_value('company_website', BRAND_URL), BRAND_URL)
    powered_label = _brand_value('powered_by_label', 'Powered by %s' % brand_name)
    powered_url = _safe_public_url(_brand_value('powered_by_url', company_url), company_url)
    promo_label = _brand_value('promotional_label', brand_name)
    promo_url = _safe_public_url(_brand_value('promotional_url', company_url), company_url)
    html = re.sub('Powered\\s+by\\s*<a([^>]*?)href=[\\"\'][^\\"\']*[\\"\']([^>]*?)>\\s*the platform\\s*</a>', '<a href="%s" target="_blank" rel="noopener">%s</a>' % (powered_url, powered_label), html, flags=re.I | re.S)
    html = re.sub('>\\s*Powered\\s+by\\s+the platform\\s*<', '>%s<' % powered_label, html, flags=re.I)
    html = re.sub('href=["\\\'][^"\\\']*odoo\\.com[^"\\\']*["\\\']', 'href="%s"' % promo_url, html, flags=re.I)
    html = re.sub('\\bOdoo\\b', brand_title, html)
    return html

def _force_response_branding(response):
    """Brand HTML before it reaches the browser; leave non-HTML untouched."""
    try:
        _render_response_now(response)
        content_type = (response.headers.get('Content-Type') or '').lower()
        data = response.get_data(as_text=True) if hasattr(response, 'get_data') else ''
        if data and ('text/html' in content_type or '<html' in data[:500].lower() or '<title' in data[:500].lower()):
            response.set_data(_replace_html_branding(data))
    except Exception:
        return response
    return response

class Home(web_home.Home):

    @route()
    def web_login(self, redirect=None, **kw):
        return _force_response_branding(super().web_login(redirect=redirect, **kw))

    @route()
    def web_client(self, s_action=None, **kw):
        response = super().web_client(s_action, **kw)
        try:
            if response.status_code == 200:
                response.set_cookie('color_scheme', request.env['ir.http'].color_scheme())
        except Exception:
            pass
        return _force_response_branding(response)
