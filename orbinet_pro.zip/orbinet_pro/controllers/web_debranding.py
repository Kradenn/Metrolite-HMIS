# -*- coding: utf-8 -*-
from werkzeug.utils import redirect

from odoo import http


class OrbinetWebDebranding(http.Controller):
    """Provide a branded backend alias for users who refresh copied /admin URLs.

    the platform's backend client may internally use /odoo route fragments in recent versions.
    The frontend asset changes the visible address-bar prefix to /admin. If a user
    refreshes such a branded URL, this lightweight alias redirects it back to the
    native backend route so the web client can boot normally, after which the asset
    immediately restores the branded address-bar prefix.
    """

    @http.route(["/admin", "/admin/<path:path>"], type="http", auth="user", website=False, sitemap=False)
    def admin_backend_alias(self, path=None, **kw):
        icp = http.request.env["ir.config_parameter"].sudo()
        branding_enabled = str(icp.get_param("web_enterprise.branding_enabled", "True")).lower() in ("1", "true", "yes", "on")
        alias_enabled = str(icp.get_param("web_enterprise.branding_backend_url", "True")).lower() in ("1", "true", "yes", "on")
        if not (branding_enabled and alias_enabled):
            return http.request.not_found()
        target = "/odoo"
        if path:
            target = "/odoo/%s" % path
        query = http.request.httprequest.query_string.decode()
        if query:
            target = "%s?%s" % (target, query)
        return redirect(target, code=302)
