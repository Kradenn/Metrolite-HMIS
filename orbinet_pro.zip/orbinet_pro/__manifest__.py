# -*- coding: utf-8 -*-
# Ultra Demark Technologies Ltd — proprietary. Licensed under OPL-1.
{
    "name": "Orbinet Pro",
    "summary": "Unified interface framework with Orthodox and Community themes",
    "description": """

Orbinet Pro — Unified interface framework: themes, layouts, dashboards and assistive profiles.

The presentation and personalisation layer that gives every application a common look and a
consistent workspace. Themes, layouts, dashboard widgets and assistive profiles are defined once
and applied across the suite.

Principal records: web.enterprise.theme.profile, web.enterprise.ai.profile,
web.enterprise.extension, web.enterprise.layout.profile, web.enterprise.dashboard.widget,
web.enterprise.ai.prompt and 2 more. 3 guided wizards for bulk and multi-step tasks. Access is
governed by 8 access-control lines. 3 web routes, all authenticated.

Links to core platform records such as res.users.settings, res.users, res.company without
altering any standard application.
""",
    "version": "19.0.1.6",
    "category": "Hidden",
    "author": "Ultra Demark Technologies Ltd",
    "maintainer": "Ultra Demark Technologies Ltd",
    "website": "https://www.ultrademark.com",
    "support": "info@ultrademark.com",
    "license": "OPL-1",
    "depends": ["web", "base_setup", "mail"],
    "data": [
        "security/ir.model.access.csv",
        "data/branding_defaults.xml",
        "data/experience_defaults.xml",
        "views/webclient_templates.xml",
        "views/res_users_views.xml",
        "views/layout_designer_views.xml",
        "views/dashboard_designer_views.xml",
        "views/theme_designer_views.xml",
        "views/res_config_settings_views.xml",
        "views/experience_ai_extension_views.xml",
    ],
    "assets": {
        "web._assets_primary_variables": [
            ('after', 'web/static/src/scss/primary_variables.scss', 'orbinet_pro/static/src/**/*.variables.scss'),
            ('before', 'web/static/src/scss/primary_variables.scss', 'orbinet_pro/static/src/scss/primary_variables.scss'),
        ],
        "web._assets_secondary_variables": [
            ('before', 'web/static/src/scss/secondary_variables.scss', 'orbinet_pro/static/src/scss/secondary_variables.scss'),
        ],
        "web._assets_backend_helpers": [
            ('before', 'web/static/src/scss/bootstrap_overridden.scss', 'orbinet_pro/static/src/scss/bootstrap_overridden.scss'),
        ],
        "web.assets_frontend": [
            "orbinet_pro/static/src/website_debranding/css/website_debranding.css",
            "orbinet_pro/static/src/website_debranding/js/frontend_debranding.js",
        ],
        "web.assets_backend": [
            ('before', 'web/static/src/webclient/menus/menu_service.js', 'orbinet_pro/static/src/core/menu_cache_guard.js'),
            "orbinet_pro/static/src/experience/experience_service.js",
            "orbinet_pro/static/src/experience/experience.scss",
            "orbinet_pro/static/src/experience/dashboard_designer.scss",
            "orbinet_pro/static/src/experience/ai_workspace_service.js",
            "orbinet_pro/static/src/experience/ai_workspace.scss",
            "orbinet_pro/static/src/webclient/navbar/navbar.scss",
            "orbinet_pro/static/src/webclient/navbar/navbar.variables.scss",
            "orbinet_pro/static/src/webclient/home_menu/home_menu.scss",
            "orbinet_pro/static/src/webclient/home_menu/home_menu.variables.scss",
            "orbinet_pro/static/src/webclient/home_menu/home_menu_background.scss",
            "orbinet_pro/static/src/webclient/apps_sidebar/apps_sidebar.scss",
            "orbinet_pro/static/src/webclient/theme_options/theme_options.scss",
            "orbinet_pro/static/src/webclient/settings_form_view/orbinet_settings.scss",
            "orbinet_pro/static/src/scss/orbinet_layout_safety.scss",
            "orbinet_pro/static/src/scss/orbinet_selection_visibility.scss",
            "orbinet_pro/static/src/views/form/save_discard_buttons/save_discard_buttons.scss",
            "orbinet_pro/static/src/views/form/save_discard_buttons/save_discard_buttons.xml",
            "orbinet_pro/static/src/views/form/statusbar_current_stage.scss",
            "orbinet_pro/static/src/chatter_position/chatter_position.scss",
            "orbinet_pro/static/src/chatter_position/chatter_position.js",
            "orbinet_pro/static/src/chatter_position/chatter_cleaner.scss",
            "orbinet_pro/static/src/chatter_position/chatter_cleaner.js",
            "orbinet_pro/static/src/chatter_position/system_chatter.js",
            "orbinet_pro/static/src/core/enterprise_compat.js",
            "orbinet_pro/static/src/webclient/field_placeholders/field_placeholders.js",
            "orbinet_pro/static/src/webclient/**/*.js",
            "orbinet_pro/static/src/webclient/**/*.xml",
            "orbinet_pro/static/src/webclient/orbinet_sidebar_menu.js",
            "orbinet_pro/static/src/webclient/theme_options/orthodox_fonts.scss",
            "orbinet_pro/static/src/webclient/theme_options/orthodox_theme.scss",
            "orbinet_pro/static/src/webclient/theme_options/orthodox_theme_scoped.scss",
            "orbinet_pro/static/src/ui/scss/orbinet_owl.scss",
            "orbinet_pro/static/src/ui/core/utils/*.js",
            "orbinet_pro/static/src/ui/core/services/*.js",
            "orbinet_pro/static/src/ui/components/*/*.js",
            "orbinet_pro/static/src/ui/components/*/*.xml",
            "orbinet_pro/static/src/branding/js/title_guard.js",
            "orbinet_pro/static/src/branding/css/orbinet_brand_assets.css",
            "orbinet_pro/static/src/branding/js/powered_by_debranding.js",
            "orbinet_pro/static/src/branding/js/logo_icon_debranding.js",
            "orbinet_pro/static/src/branding/js/user_menu_items.js",
            "orbinet_pro/static/src/branding/js/backend_url_debranding.js",
            "orbinet_pro/static/src/screen_lock/js/screen_lock.js",
            "orbinet_pro/static/src/screen_lock/xml/screen_lock.xml",
            "orbinet_pro/static/src/screen_lock/css/screen_lock.css",
        ],
        "web.assets_backend_lazy": ["orbinet_pro/static/src/views/pivot/**"],
        "web.assets_backend_lazy_dark": [
            ('include', 'web.dark_mode_variables'),
            ('before', 'orbinet_pro/static/src/scss/bootstrap_overridden.scss', 'orbinet_pro/static/src/scss/bootstrap_overridden.dark.scss'),
            ('after', 'web/static/lib/bootstrap/scss/_functions.scss', 'orbinet_pro/static/src/scss/bs_functions_overridden.dark.scss'),
        ],
        "web.assets_web": [
            "orbinet_pro/static/src/branding/js/title_guard.js",
            ('replace', 'web/static/src/main.js', 'orbinet_pro/static/src/main.js'),
            "orbinet_pro/static/src/branding/css/orbinet_brand_assets.css",
            "orbinet_pro/static/src/branding/js/logo_icon_debranding.js",
            "orbinet_pro/static/src/branding/js/user_menu_items.js",
            "orbinet_pro/static/src/branding/js/backend_url_debranding.js",
        ],
        "web.dark_mode_variables": [
            ('before', 'orbinet_pro/static/src/scss/primary_variables.scss', 'orbinet_pro/static/src/scss/primary_variables.dark.scss'),
            ('before', 'orbinet_pro/static/src/**/*.variables.scss', 'orbinet_pro/static/src/**/*.variables.dark.scss'),
            ('before', 'orbinet_pro/static/src/scss/secondary_variables.scss', 'orbinet_pro/static/src/scss/secondary_variables.dark.scss'),
        ],
        "web.assets_web_dark": [
            ('include', 'web.dark_mode_variables'),
            "orbinet_pro/static/src/scss/orbinet_input_visibility.scss",
            "orbinet_pro/static/src/scss/orbinet_input_visibility.dark.scss",
            "orbinet_pro/static/src/scss/orbinet_enterprise_fields.dark.scss",
            ('before', 'orbinet_pro/static/src/scss/bootstrap_overridden.scss', 'orbinet_pro/static/src/scss/bootstrap_overridden.dark.scss'),
            ('after', 'web/static/lib/bootstrap/scss/_functions.scss', 'orbinet_pro/static/src/scss/bs_functions_overridden.dark.scss'),
            "orbinet_pro/static/src/**/*.dark.scss",
        ],
    },
    "images": ["static/description/banner.png"],
    "application": False,
    "installable": True,
    "auto_install": False,
    "pre_init_hook": "pre_init_hook",
    "post_init_hook": "post_init_hook",
    "uninstall_hook": "uninstall_hook",
}
