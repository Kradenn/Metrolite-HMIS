# -*- coding: utf-8 -*-

def migrate(cr, version):
    # Remove obsolete settings views that can retain references to deleted fields.
    cr.execute("""
        DELETE FROM ir_ui_view
         WHERE name IN (
            'res.config.settings.view.form.orbinet.212',
            'res.config.settings.view.form.orbinet.legacy'
         )
           AND id NOT IN (
               SELECT res_id FROM ir_model_data
                WHERE module = 'web_enterprise'
                  AND name = 'res_config_settings_view_form_orbinet'
           )
    """)
