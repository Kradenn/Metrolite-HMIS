/** @odoo-module **/

/*
 * Orbinet Apps Sidebar Cleanup
 *
 * On the Odoo Apps page the left search panel normally has two blocks:
 *   1. APPS       -> All / Official Apps / Industries
 *   2. CATEGORIES -> All / Sales / Website / ...
 *
 * This enhancement now removes the APPS block and keeps the CATEGORIES block.
 * Category links are sorted alphabetically with "All" always pinned at the top,
 * so newly added categories are placed correctly no matter when they are added.
 * It is intentionally DOM-observer based because the Apps search panel is owned
 * by Odoo's web client and is re-rendered after filters, upgrades, and module
 * updates.
 */

const APPS_HEADER = "APPS";
const CATEGORIES_HEADER = "CATEGORIES";
const ALL_LABEL = "ALL";

function cleanText(text) {
    return (text || "")
        .replace(/\s+/g, " ")
        .trim();
}

function itemLabel(el) {
    const clone = el.cloneNode(true);
    // Remove counters such as 87 / 45 so the sorting uses only the label.
    for (const node of clone.querySelectorAll(".o_search_panel_counter, .badge, .o_counter")) {
        node.remove();
    }
    return cleanText(clone.textContent).replace(/\s+\d+$/, "");
}

function sectionTitle(section) {
    const candidates = section.querySelectorAll(
        ".o_search_panel_section_header, .o_search_panel_category, .o_search_panel_label, .fw-bold, .text-uppercase, b, strong"
    );
    for (const candidate of candidates) {
        const text = cleanText(candidate.textContent).toUpperCase();
        if (text === APPS_HEADER || text === CATEGORIES_HEADER) {
            return text;
        }
    }
    const ownText = cleanText(section.firstElementChild?.textContent || "").toUpperCase();
    if (ownText.includes(APPS_HEADER)) {
        return APPS_HEADER;
    }
    if (ownText.includes(CATEGORIES_HEADER)) {
        return CATEGORIES_HEADER;
    }
    return "";
}

function searchPanelSections(root) {
    const sections = Array.from(root.querySelectorAll(".o_search_panel_section"));
    if (sections.length) {
        return sections;
    }
    // Fallback for slight class changes in future web versions.
    return Array.from(root.children).filter((child) => {
        const text = cleanText(child.textContent).toUpperCase();
        return text.includes(APPS_HEADER) || text.includes(CATEGORIES_HEADER);
    });
}

function selectableItems(section) {
    return Array.from(
        section.querySelectorAll(
            ".o_search_panel_filter_value, .o_search_panel_category_value, .o_search_panel_value, a, button, li"
        )
    ).filter((el) => {
        const label = itemLabel(el).toUpperCase();
        return label && label !== APPS_HEADER && label !== CATEGORIES_HEADER;
    });
}

function commonContainer(items, fallback) {
    if (!items.length) {
        return fallback;
    }
    const parents = items.map((item) => item.parentElement).filter(Boolean);
    return parents.find((parent) => parents.every((candidate) => candidate === parent)) || parents[0] || fallback;
}

function sortCategoryNodes(nodes) {
    return [...nodes].sort((a, b) => {
        const labelA = itemLabel(a);
        const labelB = itemLabel(b);
        const isAllA = labelA.toUpperCase() === ALL_LABEL;
        const isAllB = labelB.toUpperCase() === ALL_LABEL;
        if (isAllA && !isAllB) return -1;
        if (!isAllA && isAllB) return 1;
        return labelA.localeCompare(labelB, undefined, { sensitivity: "base", numeric: true });
    });
}

function applyAppsCategorySidebar() {
    const panel = document.querySelector(".o_search_panel");
    if (!panel || panel.dataset.orbinetAppsSidebarBusy === "1") {
        return;
    }

    const sections = searchPanelSections(panel);
    const appsSection = sections.find((section) => sectionTitle(section) === APPS_HEADER);
    const categoriesSection = sections.find((section) => sectionTitle(section) === CATEGORIES_HEADER);

    if (!categoriesSection) {
        return;
    }

    panel.dataset.orbinetAppsSidebarBusy = "1";
    try {
        if (appsSection) {
            appsSection.classList.add("o_orbinet_scrapped_apps_section", "d-none");
            appsSection.setAttribute("aria-hidden", "true");
        }

        const categoryItems = selectableItems(categoriesSection);
        const categoryContainer = commonContainer(categoryItems, categoriesSection);
        for (const item of sortCategoryNodes(categoryItems)) {
            categoryContainer.appendChild(item);
        }
        categoriesSection.classList.add("o_orbinet_categories_sorted");
    } finally {
        panel.dataset.orbinetAppsSidebarBusy = "0";
    }
}

function scheduleApply() {
    window.requestAnimationFrame(() => window.requestAnimationFrame(() => {
        applyAppsCategorySidebar();
        hideMobileAppsDropdownBlocks();
    }));
}


function hideMobileAppsDropdownBlocks() {
    if (!window.matchMedia || !window.matchMedia("(max-width: 991.98px)").matches) {
        return;
    }
    const blocks = Array.from(document.querySelectorAll(
        ".o_main_navbar .dropdown-menu, .o_main_navbar .o-dropdown--menu, .o_main_navbar .o_menu_sections, .o_main_navbar .dropdown, .o_action_manager .dropdown-menu"
    ));
    for (const block of blocks) {
        const text = cleanText(block.textContent);
        if (
            text === "Apps" ||
            (text.includes("Apps") && text.includes("Main Apps") && text.includes("Theme Store")) ||
            (text.includes("Main Apps") && text.includes("Third-Party Apps"))
        ) {
            block.classList.add("o_orbinet_mobile_apps_filter_hidden", "d-none");
            block.setAttribute("aria-hidden", "true");
        }
        for (const item of block.querySelectorAll("a, button, li, .dropdown-item, .o-dropdown-item")) {
            const label = cleanText(item.textContent);
            if (["Apps", "Main Apps", "Theme Store", "Third-Party Apps"].includes(label)) {
                item.classList.add("o_orbinet_mobile_apps_filter_hidden", "d-none");
                item.setAttribute("aria-hidden", "true");
            }
        }
    }
}



const observer = new MutationObserver(scheduleApply);

function start() {
    scheduleApply();
    observer.observe(document.body, { childList: true, subtree: true });
}

if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", start, { once: true });
} else {
    start();
}
