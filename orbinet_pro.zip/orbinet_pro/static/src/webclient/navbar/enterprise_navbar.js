/** @odoo-module **/
export { EnterpriseNavBar } from './navbar';
