/** @odoo-module **/

// Orbinet calm field hints: add soft placeholders to empty standard fields.
// This is intentionally DOM-level and conservative so it works across Odoo and third-party forms
// without patching field widgets or touching search bars/buttons/chatter inputs.

const EXCLUDED_SELECTOR = [
    ".o_searchview",
    ".o_cp_searchview",
    ".o_search_panel",
    ".o_control_panel",
    ".o-mail-Composer",
    ".o_Chatter",
    ".note-editor",
    ".o_field_html",
    ".o_field_binary_file",
    ".o_field_image",
    ".input-group",
].join(",");

const FIELD_SELECTOR = [
    ".o_form_view input.o_input:not(.form-control):not([type='checkbox']):not([type='radio']):not([type='button']):not([type='submit']):not([type='reset']):not(.o_searchview_input):not(.o-autocomplete--input):not(.o_tags_input)",
    ".o_form_view textarea.o_input:not(.form-control):not(.o_searchview_input)",
    ".modal input.o_input:not(.form-control):not([type='checkbox']):not([type='radio']):not([type='button']):not([type='submit']):not([type='reset']):not(.o_searchview_input):not(.o-autocomplete--input):not(.o_tags_input)",
    ".modal textarea.o_input:not(.form-control):not(.o_searchview_input)",
].join(",");

const NAME_HINTS = [
    [/email|mail/i, "name@example.com"],
    [/phone|mobile|tel/i, "e.g. +254 712 345 678"],
    [/url|website|link/i, "https://example.com"],
    [/date/i, "Select a date"],
    [/time/i, "Select time"],
    [/amount|price|cost|total|balance|debit|credit|rate|salary|wage/i, "0.00"],
    [/qty|quantity|units?/i, "Enter quantity"],
    [/percent|percentage/i, "0%"],
    [/pin|kra/i, "Enter PIN"],
    [/name|title/i, "Enter name"],
    [/address|street|location/i, "Enter address"],
    [/description|note|memo|comment/i, "Type details here"],
];

function cleanText(value) {
    return (value || "").replace(/[*:]/g, "").replace(/\s+/g, " ").trim();
}

function findLabel(input) {
    const field = input.closest(".o_field_widget");
    if (field) {
        const id = field.getAttribute("id");
        if (id) {
            const explicit = document.querySelector(`label[for='${CSS.escape(id)}']`);
            if (explicit) return cleanText(explicit.textContent);
        }
        const row = field.closest("tr");
        const rowLabel = row?.querySelector("td.o_td_label label, .o_form_label");
        if (rowLabel) return cleanText(rowLabel.textContent);
        const previous = field.previousElementSibling;
        if (previous?.matches?.("label, .o_form_label")) return cleanText(previous.textContent);
    }
    return cleanText(input.getAttribute("aria-label") || input.getAttribute("name") || input.dataset.name || "");
}

function defaultPlaceholder(input, label) {
    const type = (input.getAttribute("type") || "").toLowerCase();
    if (type === "email") return "name@example.com";
    if (type === "tel") return "e.g. +254 712 345 678";
    if (type === "url") return "https://example.com";
    if (type === "number") return "0";

    const key = `${label} ${input.getAttribute("name") || ""} ${input.dataset.name || ""}`;
    for (const [pattern, hint] of NAME_HINTS) {
        if (pattern.test(key)) return hint;
    }
    return label ? `Enter ${label.toLowerCase()}` : "Enter value";
}

function enhancePlaceholders(root = document) {
    for (const input of root.querySelectorAll?.(FIELD_SELECTOR) || []) {
        if (input.closest(EXCLUDED_SELECTOR)) continue;
        if (input.hasAttribute("placeholder") && input.getAttribute("placeholder")) continue;
        if (input.dataset.orbinetPlaceholderApplied) continue;
        const label = findLabel(input);
        input.setAttribute("placeholder", defaultPlaceholder(input, label));
        input.dataset.orbinetPlaceholderApplied = "1";
    }
}

function start() {
    enhancePlaceholders();
    const observer = new MutationObserver((mutations) => {
        for (const mutation of mutations) {
            for (const node of mutation.addedNodes) {
                if (node.nodeType === 1) {
                    enhancePlaceholders(node);
                }
            }
        }
    });
    observer.observe(document.body, { childList: true, subtree: true });
}

if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", start, { once: true });
} else {
    start();
}
