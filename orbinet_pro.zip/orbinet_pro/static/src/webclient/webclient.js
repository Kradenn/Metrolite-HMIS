import "./orbinet_sidebar_menu";
import { WebClient } from "@web/webclient/webclient";
import { user } from "@web/core/user";
import { useService } from "@web/core/utils/hooks";
import { EnterpriseNavBar } from "./navbar/navbar";

export class WebClientEnterprise extends WebClient {
    static template = "orbinet_pro.ThemeSwitchWebClient";
    static components = {
        ...WebClient.components,
        NavBar: ["default", "community"].includes(user.settings?.obs_interface_theme || "default") ? WebClient.components.NavBar : EnterpriseNavBar,
    };
    setup() {
        super.setup();
        this.hm = useService("home_menu");
    }
    _loadDefaultApp() {
        return this.hm.toggle(true);
    }
}
