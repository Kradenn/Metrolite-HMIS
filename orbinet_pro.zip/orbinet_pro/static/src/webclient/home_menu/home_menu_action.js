/** @odoo-module **/
export { HomeMenu } from './home_menu';
export { homeMenuService } from './home_menu_service';
