/** @odoo-module **/
export { WebClientEnterprise } from './webclient';
