/** @odoo-module **/

import { registry } from "@web/core/registry";
import { _t } from "@web/core/l10n/translation";

const STORAGE_KEY = "web_enterprise_chatter_activities_visible";

// Activities are intentionally OFF on first use. A user choice is then
// remembered locally without changing server data or access rights.
let activitiesVisible = localStorage.getItem(STORAGE_KEY) === "true";

function applyActivitiesState() {
    if (!document.body) {
        return;
    }
    document.body.classList.toggle("o-we-chatter-activities-hidden", !activitiesVisible);
    document.body.classList.toggle("o-we-chatter-activities-visible", activitiesVisible);
    updateEyeButtons();
}

function updateEyeButtons() {
    document.querySelectorAll(".o-we-chatter-activities-toggle").forEach((button) => {
        const icon = button.querySelector("i");
        if (icon) {
            icon.className = activitiesVisible ? "fa fa-eye" : "fa fa-eye-slash";
        }
        const label = activitiesVisible
            ? _t("Hide chatter activities")
            : _t("Show chatter activities");
        button.title = label;
        button.setAttribute("aria-label", label);
        button.setAttribute("aria-pressed", activitiesVisible ? "true" : "false");
    });
}

function toggleActivities() {
    activitiesVisible = !activitiesVisible;
    localStorage.setItem(STORAGE_KEY, activitiesVisible ? "true" : "false");
    applyActivitiesState();
    window.dispatchEvent(new Event("resize"));
}

function injectEyeToggle(topbar) {
    if (topbar.querySelector(".o-we-chatter-activities-toggle")) {
        return;
    }

    const searchButton = Array.from(topbar.querySelectorAll("button")).find((button) =>
        button.querySelector("i.oi-search")
    );
    if (!searchButton || !searchButton.parentNode) {
        return;
    }

    const button = document.createElement("button");
    button.type = "button";
    button.className = "o-we-chatter-activities-toggle btn btn-link text-action px-1";

    const icon = document.createElement("i");
    icon.setAttribute("role", "img");
    button.appendChild(icon);

    button.addEventListener("click", (event) => {
        event.preventDefault();
        event.stopPropagation();
        toggleActivities();
    });

    searchButton.parentNode.insertBefore(button, searchButton);
    updateEyeButtons();
}

function cleanChatterDOM() {
    document.querySelectorAll(".o-mail-Chatter-topbar").forEach(injectEyeToggle);

    // Mark empty activity containers only; populated activity records remain
    // available whenever the eye toggle is switched on.
    document.querySelectorAll(
        ".o-mail-ActivityList, .o-mail-Chatter-activities, .o-mail-ActivityListContainer"
    ).forEach((container) => {
        const hasActivity = Boolean(
            container.querySelector(
                ".o-mail-Activity, .o-mail-ActivityList-item, [data-activity-id], .o_activity"
            )
        );
        container.classList.toggle("o-we-empty-activity-container", !hasActivity);
    });
}

if (document.body) {
    applyActivitiesState();
} else {
    document.addEventListener("DOMContentLoaded", applyActivitiesState, { once: true });
}

const observer = new MutationObserver(() => {
    cleanChatterDOM();
    applyActivitiesState();
});

function startObserver() {
    cleanChatterDOM();
    observer.observe(document.body, { childList: true, subtree: true });
}

if (document.body) {
    startObserver();
} else {
    document.addEventListener("DOMContentLoaded", startObserver, { once: true });
}

registry.category("services").add("webEnterpriseChatterCleaner", {
    dependencies: [],
    start() {
        return {
            areActivitiesVisible: () => activitiesVisible,
            setActivitiesVisible(visible) {
                activitiesVisible = Boolean(visible);
                localStorage.setItem(STORAGE_KEY, activitiesVisible ? "true" : "false");
                applyActivitiesState();
            },
            toggleActivities,
        };
    },
});
