/** @odoo-module **/
async function applySystemChatterSetting() {
    try {
        const response = await fetch("/web_enterprise/chatter/config", { credentials: "same-origin" });
        if (response.ok) document.body.classList.toggle("o-we-system-chatter-disabled", Boolean((await response.json()).disabled));
    } catch (_error) {}
}
if (document.body) applySystemChatterSetting();
else document.addEventListener("DOMContentLoaded", applySystemChatterSetting, { once: true });
