/** @odoo-module **/

import { Component } from "@odoo/owl";
import { cn } from "@orbinet_pro/ui/core/utils/cn";

export class Label extends Component {
    static template = "orbinet_owl.Label";
    static props = {
        className: { type: String, optional: true },
        forId: { type: String, optional: true },
        slots: { type: Object, optional: true },
        text: { type: String, optional: true },
    };
    static defaultProps = {
        className: "",
        text: "",
    };

    get classes() {
        return cn("orbinet-label", this.props.className);
    }
}
