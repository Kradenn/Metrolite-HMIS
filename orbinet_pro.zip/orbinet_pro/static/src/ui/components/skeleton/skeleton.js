/** @odoo-module **/

import { Component } from "@odoo/owl";
import { cn } from "@orbinet_pro/ui/core/utils/cn";

export class Skeleton extends Component {
    static template = "orbinet_owl.Skeleton";
    static props = {
        attrs: { type: Object, optional: true },
        className: { type: String, optional: true },
        tag: { type: String, optional: true },
    };
    static defaultProps = {
        attrs: {},
        className: "",
        tag: "div",
    };

    get classes() {
        return cn("orbinet-skeleton", this.props.className);
    }
}
