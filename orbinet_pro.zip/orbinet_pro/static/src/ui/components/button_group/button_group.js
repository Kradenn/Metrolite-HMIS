/** @odoo-module **/

import { Component } from "@odoo/owl";
import { Separator } from "@orbinet_pro/ui/components/separator/separator";
import { cn } from "@orbinet_pro/ui/core/utils/cn";
import { cva } from "@orbinet_pro/ui/core/utils/variants";

export const buttonGroupVariants = cva("orbinet-button-group", {
    variants: {
        orientation: {
            horizontal: "orbinet-button-group--horizontal",
            vertical: "orbinet-button-group--vertical",
        },
    },
    defaultVariants: {
        orientation: "horizontal",
    },
});

class ButtonGroupBase extends Component {
    get classes() {
        return cn(this.baseClass, this.props.className);
    }
}

export class ButtonGroup extends Component {
    static template = "orbinet_owl.ButtonGroup";
    static props = {
        className: { type: String, optional: true },
        orientation: { type: String, optional: true },
        slots: { type: Object, optional: true },
        tag: { type: String, optional: true },
    };
    static defaultProps = {
        className: "",
        orientation: "horizontal",
        tag: "div",
    };

    get classes() {
        return buttonGroupVariants({
            orientation: this.props.orientation,
            className: this.props.className,
        });
    }
}

export class ButtonGroupText extends ButtonGroupBase {
    static template = "orbinet_owl.ButtonGroupText";
    static props = {
        className: { type: String, optional: true },
        slots: { type: Object, optional: true },
        tag: { type: String, optional: true },
        text: { type: String, optional: true },
    };
    static defaultProps = {
        className: "",
        tag: "div",
        text: "",
    };
    baseClass = "orbinet-button-group__text";
}

export class ButtonGroupSeparator extends Component {
    static template = "orbinet_owl.ButtonGroupSeparator";
    static components = {
        Separator,
    };
    static props = {
        className: { type: String, optional: true },
        decorative: { type: Boolean, optional: true },
        orientation: { type: String, optional: true },
    };
    static defaultProps = {
        className: "",
        decorative: true,
        orientation: "vertical",
    };

    get classes() {
        return cn("orbinet-button-group__separator", this.props.className);
    }
}
