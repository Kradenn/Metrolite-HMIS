/** @odoo-module **/

import { Component } from "@odoo/owl";
import { cn } from "@orbinet_pro/ui/core/utils/cn";

export class Spinner extends Component {
    static template = "orbinet_owl.Spinner";
    static props = {
        ariaLabel: { type: String, optional: true },
        className: { type: String, optional: true },
        size: { type: String, optional: true },
        title: { type: String, optional: true },
    };
    static defaultProps = {
        ariaLabel: "Loading",
        className: "",
        size: "default",
        title: "",
    };

    get classes() {
        return cn("orbinet-spinner", `orbinet-spinner--${this.props.size}`, this.props.className);
    }
}
