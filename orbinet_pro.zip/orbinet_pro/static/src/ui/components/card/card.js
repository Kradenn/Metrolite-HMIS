/** @odoo-module **/

import { Component } from "@odoo/owl";
import { cn } from "@orbinet_pro/ui/core/utils/cn";

class CardBase extends Component {
    get classes() {
        return cn(this.baseClass, this.props.className);
    }
}

export class Card extends CardBase {
    static template = "orbinet_owl.Card";
    static props = {
        className: { type: String, optional: true },
        slots: { type: Object, optional: true },
        tag: { type: String, optional: true },
    };
    static defaultProps = {
        className: "",
        tag: "section",
    };
    baseClass = "orbinet-card";
}

export class CardHeader extends CardBase {
    static template = "orbinet_owl.CardHeader";
    static props = Card.props;
    static defaultProps = {
        className: "",
        tag: "div",
    };
    baseClass = "orbinet-card__header";
}

export class CardTitle extends CardBase {
    static template = "orbinet_owl.CardTitle";
    static props = Card.props;
    static defaultProps = {
        className: "",
        tag: "h3",
    };
    baseClass = "orbinet-card__title";
}

export class CardDescription extends CardBase {
    static template = "orbinet_owl.CardDescription";
    static props = Card.props;
    static defaultProps = {
        className: "",
        tag: "p",
    };
    baseClass = "orbinet-card__description";
}

export class CardContent extends CardBase {
    static template = "orbinet_owl.CardContent";
    static props = Card.props;
    static defaultProps = {
        className: "",
        tag: "div",
    };
    baseClass = "orbinet-card__content";
}

export class CardFooter extends CardBase {
    static template = "orbinet_owl.CardFooter";
    static props = Card.props;
    static defaultProps = {
        className: "",
        tag: "div",
    };
    baseClass = "orbinet-card__footer";
}
