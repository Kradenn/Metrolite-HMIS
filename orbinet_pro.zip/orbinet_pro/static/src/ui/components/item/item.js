/** @odoo-module **/

import { Component } from "@odoo/owl";
import { cn } from "@orbinet_pro/ui/core/utils/cn";
import { cva } from "@orbinet_pro/ui/core/utils/variants";

export const itemVariants = cva("orbinet-item", {
    variants: {
        size: {
            default: "orbinet-item--size-default",
            sm: "orbinet-item--size-sm",
        },
        variant: {
            default: "orbinet-item--default",
            outline: "orbinet-item--outline",
            muted: "orbinet-item--muted",
        },
    },
    defaultVariants: {
        size: "default",
        variant: "default",
    },
});

export const itemMediaVariants = cva("orbinet-item__media", {
    variants: {
        variant: {
            default: "orbinet-item__media--default",
            icon: "orbinet-item__media--icon",
            image: "orbinet-item__media--image",
        },
    },
    defaultVariants: {
        variant: "default",
    },
});

class ItemBase extends Component {
    get classes() {
        return cn(this.baseClass, this.props.className);
    }
}

export class ItemGroup extends ItemBase {
    static template = "orbinet_owl.ItemGroup";
    static props = {
        className: { type: String, optional: true },
        slots: { type: Object, optional: true },
        tag: { type: String, optional: true },
    };
    static defaultProps = {
        className: "",
        tag: "div",
    };
    baseClass = "orbinet-item-group";
}

export class ItemSeparator extends ItemBase {
    static template = "orbinet_owl.ItemSeparator";
    static props = {
        className: { type: String, optional: true },
    };
    static defaultProps = {
        className: "",
    };
    baseClass = "orbinet-item-separator";
}

export class Item extends Component {
    static template = "orbinet_owl.Item";
    static props = {
        className: { type: String, optional: true },
        size: { type: String, optional: true },
        slots: { type: Object, optional: true },
        tag: { type: String, optional: true },
        tabindex: { type: Number, optional: true },
        variant: { type: String, optional: true },
    };
    static defaultProps = {
        className: "",
        size: "default",
        tag: "div",
        variant: "default",
    };

    get classes() {
        return itemVariants({
            size: this.props.size,
            variant: this.props.variant,
            className: this.props.className,
        });
    }
}

export class ItemMedia extends Component {
    static template = "orbinet_owl.ItemMedia";
    static props = {
        className: { type: String, optional: true },
        slots: { type: Object, optional: true },
        tag: { type: String, optional: true },
        variant: { type: String, optional: true },
    };
    static defaultProps = {
        className: "",
        tag: "div",
        variant: "default",
    };

    get classes() {
        return itemMediaVariants({
            variant: this.props.variant,
            className: this.props.className,
        });
    }
}

export class ItemContent extends ItemBase {
    static template = "orbinet_owl.ItemContent";
    static props = {
        className: { type: String, optional: true },
        slots: { type: Object, optional: true },
        tag: { type: String, optional: true },
    };
    static defaultProps = {
        className: "",
        tag: "div",
    };
    baseClass = "orbinet-item__content";
}

export class ItemTitle extends ItemBase {
    static template = "orbinet_owl.ItemTitle";
    static props = {
        className: { type: String, optional: true },
        slots: { type: Object, optional: true },
        tag: { type: String, optional: true },
        text: { type: String, optional: true },
    };
    static defaultProps = {
        className: "",
        tag: "div",
        text: "",
    };
    baseClass = "orbinet-item__title";
}

export class ItemDescription extends ItemBase {
    static template = "orbinet_owl.ItemDescription";
    static props = {
        className: { type: String, optional: true },
        slots: { type: Object, optional: true },
        tag: { type: String, optional: true },
        text: { type: String, optional: true },
    };
    static defaultProps = {
        className: "",
        tag: "p",
        text: "",
    };
    baseClass = "orbinet-item__description";
}

export class ItemActions extends ItemBase {
    static template = "orbinet_owl.ItemActions";
    static props = {
        className: { type: String, optional: true },
        slots: { type: Object, optional: true },
        tag: { type: String, optional: true },
    };
    static defaultProps = {
        className: "",
        tag: "div",
    };
    baseClass = "orbinet-item__actions";
}

export class ItemHeader extends ItemActions {
    static template = "orbinet_owl.ItemHeader";
    baseClass = "orbinet-item__header";
}

export class ItemFooter extends ItemActions {
    static template = "orbinet_owl.ItemFooter";
    baseClass = "orbinet-item__footer";
}
