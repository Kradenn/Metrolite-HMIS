/** @odoo-module **/

import { Component, onWillUpdateProps, useChildSubEnv, useState } from "@odoo/owl";
import { cn } from "@orbinet_pro/ui/core/utils/cn";
import { nextId } from "@orbinet_pro/ui/core/utils/ids";

export class Collapsible extends Component {
    static template = "orbinet_owl.Collapsible";
    static props = {
        className: { type: String, optional: true },
        defaultOpen: { type: Boolean, optional: true },
        disabled: { type: Boolean, optional: true },
        onOpenChange: { type: Function, optional: true },
        open: { type: Boolean, optional: true },
        slots: { type: Object, optional: true },
        tag: { type: String, optional: true },
    };
    static defaultProps = {
        className: "",
        defaultOpen: false,
        disabled: false,
        tag: "div",
    };

    setup() {
        const self = this;
        this.state = useState({
            baseId: nextId("orbinet-collapsible"),
            open: this.props.open ?? this.props.defaultOpen,
        });

        useChildSubEnv({
            orbinetCollapsible: {
                get contentId() {
                    return `${self.state.baseId}-content`;
                },
                get disabled() {
                    return self.props.disabled;
                },
                get isOpen() {
                    return self.isOpen;
                },
                get triggerId() {
                    return `${self.state.baseId}-trigger`;
                },
                setOpen: (open) => self.setOpen(open),
                toggle: () => self.toggle(),
            },
        });

        onWillUpdateProps((nextProps) => {
            if (nextProps.open !== undefined) {
                this.state.open = nextProps.open;
            }
        });
    }

    get classes() {
        return cn("orbinet-collapsible", this.props.className);
    }

    get isOpen() {
        return this.props.open ?? this.state.open;
    }

    setOpen(open) {
        if (this.props.disabled) {
            return;
        }
        if (this.props.open === undefined) {
            this.state.open = open;
        }
        this.props.onOpenChange?.(open);
    }

    toggle() {
        this.setOpen(!this.isOpen);
    }
}

export class CollapsibleTrigger extends Component {
    static template = "orbinet_owl.CollapsibleTrigger";
    static props = {
        ariaLabel: { type: String, optional: true },
        attrs: { type: Object, optional: true },
        className: { type: String, optional: true },
        disabled: { type: Boolean, optional: true },
        label: { type: String, optional: true },
        slots: { type: Object, optional: true },
        tag: { type: String, optional: true },
        type: { type: String, optional: true },
    };
    static defaultProps = {
        attrs: {},
        className: "",
        disabled: false,
        label: "",
        tag: "button",
        type: "button",
    };

    get classes() {
        return cn(
            "orbinet-collapsible__trigger",
            {
                "orbinet-collapsible__trigger--open": this.isOpen,
            },
            this.props.className
        );
    }

    get isDisabled() {
        return this.props.disabled || this.env.orbinetCollapsible.disabled;
    }

    get isOpen() {
        return this.env.orbinetCollapsible.isOpen;
    }

    toggle(ev) {
        if (this.isDisabled) {
            ev.preventDefault();
            return;
        }
        this.env.orbinetCollapsible.toggle();
    }
}

export class CollapsibleContent extends Component {
    static template = "orbinet_owl.CollapsibleContent";
    static props = {
        className: { type: String, optional: true },
        forceMount: { type: Boolean, optional: true },
        slots: { type: Object, optional: true },
        tag: { type: String, optional: true },
    };
    static defaultProps = {
        className: "",
        forceMount: false,
        tag: "div",
    };

    get classes() {
        return cn(
            "orbinet-collapsible__content",
            {
                "orbinet-collapsible__content--open": this.isOpen,
            },
            this.props.className
        );
    }

    get isOpen() {
        return this.env.orbinetCollapsible.isOpen;
    }

    get shouldRender() {
        return this.props.forceMount || this.isOpen;
    }
}
