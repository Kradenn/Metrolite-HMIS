/** @odoo-module **/

import { Component } from "@odoo/owl";
import { cn } from "@orbinet_pro/ui/core/utils/cn";

export class Separator extends Component {
    static template = "orbinet_owl.Separator";
    static props = {
        className: { type: String, optional: true },
        decorative: { type: Boolean, optional: true },
        orientation: { type: String, optional: true },
    };
    static defaultProps = {
        className: "",
        decorative: true,
        orientation: "horizontal",
    };

    get classes() {
        return cn(
            "orbinet-separator",
            {
                "orbinet-separator--vertical": this.props.orientation === "vertical",
                "orbinet-separator--horizontal": this.props.orientation !== "vertical",
            },
            this.props.className
        );
    }
}
