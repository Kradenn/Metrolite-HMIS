/** @odoo-module **/

import { Component } from "@odoo/owl";
import { cva } from "@orbinet_pro/ui/core/utils/variants";

export const badgeVariants = cva("orbinet-badge", {
    variants: {
        variant: {
            default: "orbinet-badge--default",
            secondary: "orbinet-badge--secondary",
            outline: "orbinet-badge--outline",
            destructive: "orbinet-badge--destructive",
        },
    },
    defaultVariants: {
        variant: "default",
    },
});

export class Badge extends Component {
    static template = "orbinet_owl.Badge";
    static props = {
        className: { type: String, optional: true },
        label: { type: String, optional: true },
        slots: { type: Object, optional: true },
        variant: { type: String, optional: true },
    };
    static defaultProps = {
        className: "",
        variant: "default",
    };

    get classes() {
        return badgeVariants({
            variant: this.props.variant,
            className: this.props.className,
        });
    }
}
