/** @odoo-module **/

import { Component } from "@odoo/owl";
import { cn } from "@orbinet_pro/ui/core/utils/cn";
import { cva } from "@orbinet_pro/ui/core/utils/variants";

export const alertVariants = cva("orbinet-alert", {
    variants: {
        variant: {
            default: "orbinet-alert--default",
            destructive: "orbinet-alert--destructive",
        },
    },
    defaultVariants: {
        variant: "default",
    },
});

export class Alert extends Component {
    static template = "orbinet_owl.Alert";
    static props = {
        className: { type: String, optional: true },
        slots: { type: Object, optional: true },
        variant: { type: String, optional: true },
    };
    static defaultProps = {
        className: "",
        variant: "default",
    };

    get classes() {
        return alertVariants({
            variant: this.props.variant,
            className: this.props.className,
        });
    }
}

export class AlertTitle extends Component {
    static template = "orbinet_owl.AlertTitle";
    static props = {
        className: { type: String, optional: true },
        slots: { type: Object, optional: true },
    };
    static defaultProps = {
        className: "",
    };

    get classes() {
        return cn("orbinet-alert__title", this.props.className);
    }
}

export class AlertDescription extends Component {
    static template = "orbinet_owl.AlertDescription";
    static props = {
        className: { type: String, optional: true },
        slots: { type: Object, optional: true },
    };
    static defaultProps = {
        className: "",
    };

    get classes() {
        return cn("orbinet-alert__description", this.props.className);
    }
}
