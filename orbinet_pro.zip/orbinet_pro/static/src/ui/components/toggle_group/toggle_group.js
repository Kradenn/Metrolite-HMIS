/** @odoo-module **/

import {
    Component,
    onMounted,
    onWillDestroy,
    onWillUpdateProps,
    useChildSubEnv,
    useState,
} from "@odoo/owl";
import { cn } from "@orbinet_pro/ui/core/utils/cn";
import { isSameCollectionValue } from "@orbinet_pro/ui/core/utils/collection";
import { nextId, sanitizeIdFragment } from "@orbinet_pro/ui/core/utils/ids";
import { toggleVariants } from "@orbinet_pro/ui/components/toggle/toggle";
import { isRtlDirection, resolveDirection } from "@orbinet_pro/ui/core/utils/direction";

function normalizeValues(value, type) {
    if (value === undefined || value === null || value === "") {
        return [];
    }
    if (Array.isArray(value)) {
        return value;
    }
    return type === "multiple" ? [value] : [value];
}

function sortRegisteredItems(items = []) {
    return [...items].sort((left, right) => left.order - right.order);
}

export class ToggleGroup extends Component {
    static template = "orbinet_owl.ToggleGroup";
    static props = {
        className: { type: String, optional: true },
        defaultValue: { optional: true, validate: () => true },
        disabled: { type: Boolean, optional: true },
        dir: { type: String, optional: true },
        loop: { type: Boolean, optional: true },
        onValueChange: { type: Function, optional: true },
        orientation: { type: String, optional: true },
        size: { type: String, optional: true },
        slots: { type: Object, optional: true },
        spacing: { type: Number, optional: true },
        type: { type: String, optional: true },
        value: { optional: true, validate: () => true },
        variant: { type: String, optional: true },
    };
    static defaultProps = {
        className: "",
        disabled: false,
        loop: true,
        orientation: "horizontal",
        size: "default",
        spacing: 0,
        type: "single",
        variant: "default",
    };

    setup() {
        const self = this;
        this.state = useState({
            baseId: nextId("orbinet-toggle-group"),
            tabStopValue: null,
            registeredItems: [],
            registryOrder: 0,
            values: normalizeValues(this.props.value ?? this.props.defaultValue, this.props.type),
        });

        useChildSubEnv({
            orbinetToggleGroup: {
                get disabled() {
                    return self.props.disabled;
                },
                get dir() {
                    return self.direction;
                },
                get size() {
                    return self.props.size;
                },
                get spacing() {
                    return self.props.spacing;
                },
                get type() {
                    return self.props.type;
                },
                get values() {
                    return self.currentValues;
                },
                get variant() {
                    return self.props.variant;
                },
                getTabIndex: (value) => self.getTabIndex(value),
                getItemId: (value) =>
                    `${self.state.baseId}-item-${sanitizeIdFragment(value)}`,
                isPressed: (value) =>
                    self.currentValues.some((item) => isSameCollectionValue(item, value)),
                registerItem: (token, item) => self.registerItem(token, item),
                setTabStop: (value) => self.setTabStop(value),
                toggleValue: (value) => self.toggleValue(value),
                unregisterItem: (token) => self.unregisterItem(token),
            },
        });

        onMounted(() => {
            this.syncTabStop(true);
        });

        onWillUpdateProps((nextProps) => {
            if (nextProps.value !== undefined) {
                this.state.values = normalizeValues(nextProps.value, nextProps.type ?? this.props.type);
            }
            this.syncTabStop(nextProps.value !== undefined);
        });
    }

    get currentValues() {
        return normalizeValues(this.props.value ?? this.state.values, this.props.type);
    }

    get direction() {
        return resolveDirection(this.props.dir);
    }

    get registeredItems() {
        return sortRegisteredItems(this.state.registeredItems);
    }

    get enabledItems() {
        return this.registeredItems.filter((item) => !item.disabled);
    }

    get defaultTabStopValue() {
        const pressedItem = this.enabledItems.find((item) =>
            this.currentValues.some((value) => isSameCollectionValue(value, item.value))
        );
        return pressedItem?.value ?? this.enabledItems[0]?.value ?? null;
    }

    get classes() {
        return cn(
            "orbinet-toggle-group",
            {
                "orbinet-toggle-group--vertical": this.props.orientation === "vertical",
                "orbinet-toggle-group--horizontal": this.props.orientation !== "vertical",
                "orbinet-toggle-group--spaced": this.props.spacing > 0,
            },
            this.props.className
        );
    }

    get style() {
        return `--orbinet-toggle-group-gap: ${this.props.spacing}px;`;
    }

    registerItem(token, item) {
        const existingIndex = this.state.registeredItems.findIndex((entry) => entry.token === token);
        const existingItem = existingIndex === -1 ? null : this.state.registeredItems[existingIndex];
        const nextItem = {
            ...item,
            order:
                existingIndex === -1
                    ? this.state.registryOrder++
                    : existingItem.order,
            token,
        };
        if (
            existingItem &&
            existingItem.disabled === nextItem.disabled &&
            existingItem.id === nextItem.id &&
            isSameCollectionValue(existingItem.value, nextItem.value)
        ) {
            return;
        }
        if (existingIndex === -1) {
            this.state.registeredItems.push(nextItem);
        } else {
            this.state.registeredItems.splice(existingIndex, 1, nextItem);
        }
        this.syncTabStop();
    }

    unregisterItem(token) {
        const existingIndex = this.state.registeredItems.findIndex((entry) => entry.token === token);
        if (existingIndex !== -1) {
            this.state.registeredItems.splice(existingIndex, 1);
        }
        this.syncTabStop();
    }

    syncTabStop(preferSelection = false) {
        const enabledItems = this.enabledItems;
        if (!enabledItems.length) {
            this.state.tabStopValue = null;
            return;
        }
        const currentTabStop = enabledItems.find((item) =>
            isSameCollectionValue(item.value, this.state.tabStopValue)
        );
        if (currentTabStop && !preferSelection) {
            return;
        }
        this.state.tabStopValue = this.defaultTabStopValue;
    }

    setTabStop(value) {
        if (this.enabledItems.some((item) => isSameCollectionValue(item.value, value))) {
            this.state.tabStopValue = value;
        }
    }

    getTabIndex(value) {
        if (this.props.disabled) {
            return -1;
        }
        return isSameCollectionValue(value, this.state.tabStopValue ?? this.defaultTabStopValue)
            ? 0
            : -1;
    }

    toggleValue(value) {
        if (this.props.disabled) {
            return;
        }
        const current = this.currentValues;
        const exists = current.some((item) => isSameCollectionValue(item, value));
        let nextValues;
        if (this.props.type === "multiple") {
            nextValues = exists
                ? current.filter((item) => !isSameCollectionValue(item, value))
                : [...current, value];
        } else {
            nextValues = exists ? [] : [value];
        }
        if (this.props.value === undefined) {
            this.state.values = nextValues;
        }
        this.setTabStop(value);
        this.props.onValueChange?.(
            this.props.type === "multiple" ? nextValues : nextValues[0] ?? null
        );
    }

    onKeydown(ev) {
        const vertical = this.props.orientation === "vertical";
        const validKeys = vertical
            ? ["ArrowDown", "ArrowUp", "Home", "End"]
            : ["ArrowRight", "ArrowLeft", "Home", "End"];
        if (!validKeys.includes(ev.key)) {
            return;
        }
        const items = [...ev.currentTarget.querySelectorAll('[data-orbinet-toggle-group-item]:not([disabled])')];
        if (!items.length) {
            return;
        }
        let currentIndex = items.indexOf(document.activeElement);
        if (currentIndex === -1) {
            currentIndex = items.findIndex((item) =>
                isSameCollectionValue(item.dataset.value, this.state.tabStopValue)
            );
        }
        if (currentIndex === -1) {
            currentIndex = 0;
        }
        ev.preventDefault();
        if (ev.key === "Home") {
            items[0].focus();
            return;
        }
        if (ev.key === "End") {
            items[items.length - 1].focus();
            return;
        }
        const isRtl = !vertical && isRtlDirection(this.direction);
        const direction =
            ev.key === "ArrowDown"
                ? 1
                : ev.key === "ArrowUp"
                  ? -1
                  : ev.key === "ArrowRight"
                    ? isRtl
                        ? -1
                        : 1
                    : isRtl
                      ? 1
                      : -1;
        let nextIndex = currentIndex + direction;
        if (this.props.loop) {
            nextIndex = (nextIndex + items.length) % items.length;
        } else {
            nextIndex = Math.max(0, Math.min(items.length - 1, nextIndex));
        }
        items[nextIndex].focus();
    }
}

export class ToggleGroupItem extends Component {
    static template = "orbinet_owl.ToggleGroupItem";
    static props = {
        ariaLabel: { type: String, optional: true },
        className: { type: String, optional: true },
        disabled: { type: Boolean, optional: true },
        id: { type: String, optional: true },
        size: { type: String, optional: true },
        slots: { type: Object, optional: true },
        value: { validate: () => true },
        variant: { type: String, optional: true },
    };
    static defaultProps = {
        className: "",
        disabled: false,
    };

    setup() {
        this.token = nextId("orbinet-toggle-group-item");

        onMounted(() => {
            this.register(this.props);
        });

        onWillUpdateProps((nextProps) => {
            this.register(nextProps);
        });

        onWillDestroy(() => {
            this.env.orbinetToggleGroup.unregisterItem(this.token);
        });
    }

    get isPressed() {
        return this.env.orbinetToggleGroup.isPressed(this.props.value);
    }

    get isDisabled() {
        return this.props.disabled || this.env.orbinetToggleGroup.disabled;
    }

    get classes() {
        return toggleVariants({
            variant: this.props.variant ?? this.env.orbinetToggleGroup.variant,
            size: this.props.size ?? this.env.orbinetToggleGroup.size,
            className: cn(
                "orbinet-toggle-group__item",
                {
                    "orbinet-toggle-group__item--pressed": this.isPressed,
                    "orbinet-toggle-group__item--joined": !this.env.orbinetToggleGroup.spacing,
                },
                this.props.className
            ),
        });
    }

    get itemId() {
        return this.props.id || this.env.orbinetToggleGroup.getItemId(this.props.value);
    }

    get tabIndex() {
        return this.isDisabled ? -1 : this.env.orbinetToggleGroup.getTabIndex(this.props.value);
    }

    toggle(ev) {
        if (this.isDisabled) {
            ev.preventDefault();
            return;
        }
        this.env.orbinetToggleGroup.toggleValue(this.props.value);
    }

    register(props = this.props) {
        this.env.orbinetToggleGroup.registerItem(this.token, {
            disabled: Boolean(props.disabled),
            id: props.id,
            value: props.value,
        });
    }

    onFocus() {
        if (!this.isDisabled) {
            this.env.orbinetToggleGroup.setTabStop(this.props.value);
        }
    }
}
