ODX UI components and theme assets

This directory contains source files derived from the ODX OWL UI Kit and ODX Community Theme (Odoo 19, version 19.0.1.0.0), authored by Bashir Hassan / ODX Builder. The upstream manifests identify these addons as LGPL-3. The copied source components and theme assets remain subject to their upstream LGPL-3 licensing terms. They are included here so Orbinet Pro can provide the ODX interface without installing a separate ODX theme addon.
