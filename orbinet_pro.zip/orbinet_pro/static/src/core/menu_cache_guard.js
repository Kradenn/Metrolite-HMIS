import { browser } from "@web/core/browser/browser";

/**
 * Odoo keeps the complete menu tree in localStorage as a startup optimization.
 * Large installations can exceed the browser's per-origin storage quota. The
 * menu service already has the data in memory after its RPC, so caching an
 * oversized tree is optional; skip that write and let the normal RPC path run.
 */
const MENU_CACHE_KEY = "webclient_menus";
const MENU_CACHE_VERSION_KEY = "webclient_menus_version";
const isMenuCacheKey = (key) => key === MENU_CACHE_KEY || key === MENU_CACHE_VERSION_KEY;
// localStorage stores strings as UTF-16. This cap leaves room for other keys
// and avoids pushing an unusually large menu tree into a typical 5 MiB quota.
const MAX_MENU_CACHE_CHARACTERS = 1_000_000;

const storage = browser.localStorage;
if (storage) {
    try {
        const cachedMenus = storage.getItem(MENU_CACHE_KEY);
        if (cachedMenus && cachedMenus.length > MAX_MENU_CACHE_CHARACTERS) {
            storage.removeItem(MENU_CACHE_KEY);
            storage.removeItem(MENU_CACHE_VERSION_KEY);
        }
    } catch {
        // Storage can be disabled by browser privacy settings; menu loading uses RPC.
    }

    const nativeSetItem = storage.setItem.bind(storage);
    storage.setItem = (key, value) => {
        if (key === MENU_CACHE_KEY && String(value).length > MAX_MENU_CACHE_CHARACTERS) {
            try {
                storage.removeItem(MENU_CACHE_KEY);
                storage.removeItem(MENU_CACHE_VERSION_KEY);
            } catch {
                // The cache is optional; do not interrupt web client startup.
            }
            return;
        }
        try {
            return nativeSetItem(key, value);
        } catch (error) {
            const isQuotaError =
                error?.name === "QuotaExceededError" || error?.code === 22 || error?.code === 1014;
            if (isMenuCacheKey(key) && isQuotaError) {
                try {
                    storage.removeItem(MENU_CACHE_KEY);
                    storage.removeItem(MENU_CACHE_VERSION_KEY);
                } catch {
                    // The failed cache write must not block the in-memory menu tree.
                }
                return;
            }
            throw error;
        }
    };
}
