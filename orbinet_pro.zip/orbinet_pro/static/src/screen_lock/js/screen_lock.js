/** @odoo-module **/

import { Component, useState, useRef, onMounted, onWillUnmount } from "@odoo/owl";
import { registry } from "@web/core/registry";
import { _t } from "@web/core/l10n/translation";
import { Dropdown } from "@web/core/dropdown/dropdown";
import { DropdownItem } from "@web/core/dropdown/dropdown_item";
import { useService } from "@web/core/utils/hooks";

const STORAGE_KEY = "orbinet_screen_lock_pin";
const LOCKED_KEY = "orbinet_screen_locked";

// ── Helpers ──────────────────────────────────────────────────────────────────

async function hashPin(pin) {
    const data = new TextEncoder().encode(pin);
    const buf = await crypto.subtle.digest("SHA-256", data);
    return Array.from(new Uint8Array(buf)).map((b) => b.toString(16).padStart(2, "0")).join("");
}

function getStoredHash() {
    return localStorage.getItem(STORAGE_KEY) || "";
}

function storeHash(hash) {
    localStorage.setItem(STORAGE_KEY, hash);
}

function hasPinSet() {
    return !!getStoredHash();
}

// ── Lock Screen Component ────────────────────────────────────────────────────

export class LockScreen extends Component {
    static template = "web_enterprise.LockScreen";
    static components = { Dropdown, DropdownItem };
    static props = {};

    setup() {
        this.state = useState({
            locked: false,
            enabled: true,
            mode: "idle", // idle | set_pin | change_pin | unlock
            error: "",
            shake: false,
        });

        // PIN digit arrays
        this.pinDigits = useState({ d0: "", d1: "", d2: "", d3: "" });
        this.confirmDigits = useState({ d0: "", d1: "", d2: "", d3: "" });
        this.oldPinDigits = useState({ d0: "", d1: "", d2: "", d3: "" });

        // Refs for the overlay
        this.overlayRef = useRef("overlay");

        // ORM service for fetching settings
        this.orm = useService("orm");

        // Inactivity timer
        this._autoLockTimeout = 0; // seconds, 0 = disabled
        this._inactivityTimer = null;
        this._onActivity = this._resetInactivityTimer.bind(this);

        onMounted(async () => {
            // Block keyboard shortcuts when locked
            document.addEventListener("keydown", this._blockWhenLocked.bind(this), true);

            // Restore locked state after page reload
            if (localStorage.getItem(LOCKED_KEY) === "1" && hasPinSet()) {
                this._lockScreen();
            }

            // Fetch auto-lock timeout from settings and start timer
            await this._fetchScreenLockSettings();
            this._startInactivityListeners();
        });

        onWillUnmount(() => {
            this._stopInactivityListeners();
        });
    }

    _blockWhenLocked(ev) {
        if (!this.state.locked) return;
        // Allow typing in PIN inputs
        if (ev.target && ev.target.classList.contains("pin-digit-input")) return;
        ev.stopPropagation();
        ev.preventDefault();
    }

    // ── Actions from dropdown ────────────────────────────────────────────

    onLockClick() {
        if (!this.state.enabled) { return; }
        if (!this.state.enabled) { return; }
        if (!hasPinSet()) {
            this._openSetPin();
        } else {
            this._lockScreen();
        }
    }

    onChangePinClick() {
        if (!hasPinSet()) {
            this._openSetPin();
        } else {
            this._resetDigits(this.oldPinDigits);
            this._resetDigits(this.pinDigits);
            this._resetDigits(this.confirmDigits);
            this.state.error = "";
            this.state.mode = "change_pin";
            this._focusFirstDigit("old");
        }
    }

    // ── Set PIN flow ─────────────────────────────────────────────────────

    _openSetPin() {
        this._resetDigits(this.pinDigits);
        this._resetDigits(this.confirmDigits);
        this.state.error = "";
        this.state.mode = "set_pin";
        this._focusFirstDigit("new");
    }

    async onSetPinSubmit() {
        const pin = this._getPin(this.pinDigits);
        const confirm = this._getPin(this.confirmDigits);

        if (pin.length !== 4) {
            this.state.error = _t("Please enter a 4-digit PIN.");
            return;
        }
        if (pin !== confirm) {
            this.state.error = _t("PINs do not match.");
            this._resetDigits(this.confirmDigits);
            this._focusFirstDigit("confirm");
            return;
        }

        const hash = await hashPin(pin);
        storeHash(hash);
        this.state.mode = "idle";
        this.state.error = "";
        this._lockScreen();
    }

    onSetPinCancel() {
        this.state.mode = "idle";
        this.state.error = "";
    }

    // ── Change PIN flow ──────────────────────────────────────────────────

    async onChangePinSubmit() {
        const oldPin = this._getPin(this.oldPinDigits);
        const newPin = this._getPin(this.pinDigits);
        const confirm = this._getPin(this.confirmDigits);

        if (oldPin.length !== 4) {
            this.state.error = _t("Please enter your current 4-digit PIN.");
            return;
        }

        const oldHash = await hashPin(oldPin);
        if (oldHash !== getStoredHash()) {
            this.state.error = _t("Current PIN is incorrect.");
            this._resetDigits(this.oldPinDigits);
            this._focusFirstDigit("old");
            return;
        }

        if (newPin.length !== 4) {
            this.state.error = _t("Please enter a new 4-digit PIN.");
            return;
        }
        if (newPin !== confirm) {
            this.state.error = _t("New PINs do not match.");
            this._resetDigits(this.confirmDigits);
            this._focusFirstDigit("confirm");
            return;
        }

        const hash = await hashPin(newPin);
        storeHash(hash);
        this.state.mode = "idle";
        this.state.error = "";
        this.env.services.notification.add(_t("PIN changed successfully."), { type: "success" });
    }

    onChangePinCancel() {
        this.state.mode = "idle";
        this.state.error = "";
    }

    // ── Lock / Unlock ────────────────────────────────────────────────────

    _lockScreen() {
        this._resetDigits(this.pinDigits);
        this.state.error = "";
        this.state.shake = false;
        this.state.locked = true;
        this.state.mode = "unlock";
        localStorage.setItem(LOCKED_KEY, "1");
        this._focusFirstDigit("unlock");
    }

    async _tryUnlock() {
        const pin = this._getPin(this.pinDigits);
        if (pin.length !== 4) return;

        const hash = await hashPin(pin);
        if (hash === getStoredHash()) {
            this.state.locked = false;
            this.state.mode = "idle";
            this.state.error = "";
            localStorage.removeItem(LOCKED_KEY);
            this._resetInactivityTimer();
        } else {
            this.state.error = _t("Incorrect PIN");
            this.state.shake = true;
            setTimeout(() => {
                this.state.shake = false;
                this._resetDigits(this.pinDigits);
                this._focusFirstDigit("unlock");
            }, 500);
        }
    }

    // ── PIN digit input handling ─────────────────────────────────────────

    onDigitInput(ev, digits, index, group) {
        const val = ev.target.value.replace(/\D/g, "");
        digits[`d${index}`] = val.slice(-1);
        ev.target.value = digits[`d${index}`];

        if (digits[`d${index}`] && index < 3) {
            this._focusDigit(group, index + 1);
        }

        // Auto-submit on unlock when all 4 digits are entered
        if (group === "unlock" && this._getPin(digits).length === 4) {
            this._tryUnlock();
        }
    }

    onDigitKeydown(ev, digits, index, group) {
        if (ev.key === "Backspace" && !digits[`d${index}`] && index > 0) {
            this._focusDigit(group, index - 1);
            ev.preventDefault();
        }
        if (ev.key === "Enter") {
            if (this.state.mode === "set_pin") {
                this.onSetPinSubmit();
            } else if (this.state.mode === "change_pin") {
                this.onChangePinSubmit();
            } else if (this.state.mode === "unlock") {
                this._tryUnlock();
            }
        }
    }

    // ── Utilities ────────────────────────────────────────────────────────

    _getPin(digits) {
        return `${digits.d0}${digits.d1}${digits.d2}${digits.d3}`;
    }

    _resetDigits(digits) {
        digits.d0 = "";
        digits.d1 = "";
        digits.d2 = "";
        digits.d3 = "";
    }

    _focusFirstDigit(group) {
        setTimeout(() => this._focusDigit(group, 0), 50);
    }

    _focusDigit(group, index) {
        const el = document.querySelector(`.pin-group-${group} .pin-digit-input[data-index="${index}"]`);
        if (el) el.focus();
    }

    // ── Auto-lock inactivity timer ───────────────────────────────────────

    async _fetchScreenLockSettings() {
        try {
            const enabled = await this.orm.call(
                "ir.config_parameter",
                "get_param",
                ["web_enterprise.screen_lock_enabled", "True"],
            );
            const timeout = await this.orm.call(
                "ir.config_parameter",
                "get_param",
                ["web_enterprise.screen_lock_timeout", "0"],
            );
            this.state.enabled = !["false", "False", "0", ""].includes(String(enabled));
            this._autoLockTimeout = parseInt(timeout, 10) || 0;
        } catch (_e) {
            this.state.enabled = true;
            this._autoLockTimeout = 0;
        }
    }

    _startInactivityListeners() {
        const events = ["mousemove", "mousedown", "keydown", "scroll", "touchstart", "click"];
        for (const evt of events) {
            document.addEventListener(evt, this._onActivity, { passive: true });
        }
        this._resetInactivityTimer();
    }

    _stopInactivityListeners() {
        clearTimeout(this._inactivityTimer);
        const events = ["mousemove", "mousedown", "keydown", "scroll", "touchstart", "click"];
        for (const evt of events) {
            document.removeEventListener(evt, this._onActivity);
        }
    }

    _resetInactivityTimer() {
        clearTimeout(this._inactivityTimer);
        if (this._autoLockTimeout > 0 && hasPinSet() && !this.state.locked) {
            this._inactivityTimer = setTimeout(() => {
                if (hasPinSet() && !this.state.locked) {
                    this._lockScreen();
                }
            }, this._autoLockTimeout * 1000);
        }
    }
}

// ── Systray Registration ─────────────────────────────────────────────────────

registry.category("systray").add(
    "web_enterprise.screen_lock",
    { Component: LockScreen },
    { sequence: 99 }
);
