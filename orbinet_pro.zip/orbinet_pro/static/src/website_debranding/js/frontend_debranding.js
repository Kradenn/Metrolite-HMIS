/** @odoo-module **/

(function () {
    "use strict";

    if (window.__orbinetFrontendDebrandingLoaded) {
        return;
    }
    window.__orbinetFrontendDebrandingLoaded = true;

    const COMPANY = "Ultra Demark Technologies Ltd.";
    const COMPANY_URL = "https://www.ultrademark.com";

    const BRANDING_ROOT_SELECTOR = [
        "footer",
        ".o_footer_copyright",
        ".o_footer_copyright_name",
        ".o_brand_promotion",
        ".o_website_brand_promotion",
        ".o_powered_by",
    ].join(",");

    const BRANDING_LINK_SELECTOR = [
        "footer a[href*='odoo.com']",
        ".o_footer_copyright a[href*='odoo.com']",
        ".o_brand_promotion a[href*='odoo.com']",
        ".o_website_brand_promotion a[href*='odoo.com']",
        ".o_powered_by a[href*='odoo.com']",
    ].join(",");

    function editorIsActive() {
        return Boolean(
            document.body?.classList.contains("editor_enable") ||
            document.body?.classList.contains("o_is_editable") ||
            document.querySelector(".o_we_ui_container")
        );
    }


    const FRONTEND_ADMIN_BAR_SELECTOR = [
        ".o_frontend_to_backend_navbar",
        "nav.o_frontend_to_backend_navbar",
        ".o_website_navbar_container > .o_main_navbar",
        "body > .o_main_navbar",
        "body > header.o_main_navbar",
    ].join(",");

    function editorRequestedByUrl() {
        const params = new URLSearchParams(window.location.search);
        return ["enable_editor", "edit", "website_editor"].some((key) => {
            const value = params.get(key);
            return value === "1" || value === "true" || value === "yes";
        });
    }

    function syncFrontendAdminBar() {
        const active = editorRequestedByUrl() || editorIsActive();
        document.documentElement.classList.toggle("o_we_editor_active", active);
        document.querySelectorAll(FRONTEND_ADMIN_BAR_SELECTOR).forEach((navbar) => {
            if (!(navbar instanceof HTMLElement)) {
                return;
            }
            if (active) {
                navbar.removeAttribute("hidden");
                navbar.removeAttribute("aria-hidden");
                navbar.style.removeProperty("display");
                navbar.style.removeProperty("visibility");
            } else {
                navbar.hidden = true;
                navbar.setAttribute("aria-hidden", "true");
                navbar.style.setProperty("display", "none", "important");
                navbar.style.setProperty("visibility", "hidden", "important");
            }
        });
    }

    function updateLink(link) {
        if (!(link instanceof HTMLAnchorElement) || !link.isConnected) {
            return;
        }
        const href = link.getAttribute("href") || "";
        if (!/odoo\.com/i.test(href)) {
            return;
        }

        link.setAttribute("href", COMPANY_URL);
        link.setAttribute("target", "_blank");
        link.setAttribute("rel", "noopener noreferrer");

        const label = (link.textContent || "").replace(/\s+/g, " ").trim();
        const container = link.closest(BRANDING_ROOT_SELECTOR);
        const containerText = (container?.textContent || "").replace(/\s+/g, " ").trim();
        if (/^(odoo|odoo\.com)$/i.test(label) || /powered\s+by/i.test(containerText)) {
            if (link.childElementCount === 0 && link.textContent !== COMPANY) {
                link.textContent = COMPANY;
            }
        }
    }

    function hidePromotion(element) {
        if (!(element instanceof HTMLElement) || !element.isConnected) {
            return;
        }
        const text = (element.textContent || "").replace(/\s+/g, " ").trim();
        if (/^(the\s*)?#1\s*open\s*source\s*ecommerce$/i.test(text)) {
            element.hidden = true;
            element.setAttribute("aria-hidden", "true");
        }
    }

    function apply(root = document) {
        syncFrontendAdminBar();
        if (editorIsActive() || !root?.querySelectorAll) {
            return;
        }

        if (root.matches?.(BRANDING_LINK_SELECTOR)) {
            updateLink(root);
        }
        root.querySelectorAll(BRANDING_LINK_SELECTOR).forEach(updateLink);

        const roots = [];
        if (root.matches?.(BRANDING_ROOT_SELECTOR)) {
            roots.push(root);
        }
        roots.push(...root.querySelectorAll(BRANDING_ROOT_SELECTOR));
        roots.forEach(hidePromotion);
    }

    function schedule(root = document) {
        window.requestAnimationFrame(() => apply(root));
    }

    function start() {
        syncFrontendAdminBar();
        schedule(document);

        if (!window.MutationObserver) {
            return;
        }

        const observer = new MutationObserver((mutations) => {
            syncFrontendAdminBar();
            for (const mutation of mutations) {
                for (const node of mutation.addedNodes) {
                    if (node.nodeType === Node.ELEMENT_NODE) {
                        schedule(node);
                    }
                }
            }
        });

        observer.observe(document.documentElement, {
            childList: true,
            subtree: true,
            attributes: true,
            attributeFilter: ["class"],
        });
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", start, { once: true });
    } else {
        start();
    }
})();
