# -*- coding: utf-8 -*-
# Ultra Demark Technologies Ltd — proprietary. Licensed under OPL-1.
{
    "name": "WooCommerce",
    "summary": "Product, order, customer, tax and stock synchronisation with WooCommerce storefronts",
    "description": """

WooCommerce — Product, order, customer, tax and stock synchronisation with WooCommerce
storefronts.

Links one or many WooCommerce stores to a single operational back office. Product and variant
mapping is explicit, order stages and payment modes are translated into internal equivalents,
and stock is reconciled continuously so the shop cannot sell what the warehouse does not have.

Principal records: wc.store, wc.product.link, wc.order, wc.template.link, wc.order.stage,
wc.payment.mode and 8 more. 2 guided wizards for bulk and multi-step tasks. Ships with 9
scheduled jobs. Access is governed by 31 access-control lines.

Extends the standard Accounting, Delivery, Products, Sales applications across 6 existing
records.
""",
    "version": "1.5",
    "category": "Connector",
    "author": "Ultra Demark Technologies Ltd",
    "maintainer": "Ultra Demark Technologies Ltd",
    "website": "https://www.ultrademark.com",
    "support": "info@ultrademark.com",
    "license": "OPL-1",
    "depends": ["mail", "contacts", "sale_management", "delivery", "stock", "account"],
    "external_dependencies": {
        "python": ["woocommerce", "requests"],
    },
    "data": [
        "security/ir.model.access.csv",
        "data/order_stage_data.xml",
        "data/ir_cron_data.xml",
        "wizard/wc_sync_wizard_view.xml",
        "views/order_stage_views.xml",
        "views/payment_views.xml",
        "views/shipping_views.xml",
        "views/tax_views.xml",
        "views/category_views.xml",
        "views/tag_views.xml",
        "views/attribute_views.xml",
        "views/product_link_views.xml",
        "views/customer_views.xml",
        "views/order_views.xml",
        "views/wc_store_views.xml",
        "views/dashboard_views.xml",
        "views/menu.xml",
    ],
    "demo": ["demo/wc_demo_data.xml"],
    "assets": {
        "web.assets_backend": [
            "woocomerce_connector/static/src/css/wc_dashboard.css",
            "woocomerce_connector/static/src/js/wc_dashboard.js",
            "woocomerce_connector/static/src/xml/wc_dashboard.xml",
        ],
    },
    "images": ["static/description/banner.png"],
    "application": True,
    "installable": True,
    "auto_install": False,
}
