from odoo import api, fields, models, _
from odoo.exceptions import ValidationError

class WooOrderStatus(models.Model):

    _name = "wc.order.stage"
    _description = "WooCommerce Order Status"
    _order = "sequence, name"

    name = fields.Char(string="Status Label", required=True, translate=True)
    code = fields.Char(
        string="Status Code",
        required=True,
        help="The slug used by WooCommerce, e.g. 'processing', 'completed'.",
    )
    sequence = fields.Integer(default=10)
    is_terminal = fields.Boolean(
        string="Terminal State",
        help="When enabled, orders in this status will not be re-exported.",
    )
    color = fields.Integer(string="Color Index")
    active = fields.Boolean(default=True)

    @api.constrains("code")
    def _check_unique_status_code(self):
        for rec in self.filtered("code"):
            duplicate = self.search([
                ("id", "!=", rec.id),
                ("code", "=", rec.code),
            ], limit=1)
            if duplicate:
                raise ValidationError(_("Status code must be unique."))

